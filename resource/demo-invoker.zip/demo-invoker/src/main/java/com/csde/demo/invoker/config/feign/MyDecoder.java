package com.csde.demo.invoker.config.feign;



import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.fasterxml.jackson.databind.ObjectMapper;

import com.google.gson.Gson;
import feign.FeignException;
import feign.Response;
import feign.Util;
import feign.codec.DecodeException;
import feign.codec.Decoder;
import java.lang.reflect.Method;
import java.nio.charset.Charset;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.openfeign.support.SpringDecoder;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.lang.reflect.Type;
import sun.reflect.generics.reflectiveObjects.TypeVariableImpl;

/**
 * @author 小石潭记
 * @date 2020/6/23 21:09
 * @Description: 自定义feign的正常返回结果
 */
@Component
@Slf4j
public class MyDecoder implements Decoder {

    @Autowired
    private ObjectMapper mapper;
//https://www.jianshu.com/p/a4b771e49d52

//https://www.jianshu.com/p/a4b771e49d52
    /**
     * 这里统一处理，根据状态码判断返回正常还是异常的， 200返回正常的，其他状态码直接抛出异常
     */
    @Override
    public Object decode(Response response, Type type) throws IOException, DecodeException, FeignException {
        SpringDecoder springDecoder;

        Charset charset=Charset.forName("UTF-8");
        String result = Util.toString(response.body().asReader(charset));

        /*if(true){
           return new Gson().fromJson(result,type);
        }*/
        String id=JSONObject.parseObject(result).getString("id");
        log.info("result:{},type:{},type is Class:{},id:{}",result,type.getTypeName(),type instanceof Class,id);
        //Class returnType=((Method)((TypeVariableImpl)type).getGenericDeclaration()).getReturnType();
        result="["+result+",{\"id\":\"246\",\"status\":1,\"customer\":\"10000\"}]";
        if(true) {
            log.info(JSON.toJSONString(JSON.parseObject(result, type)));
            return JSON.parseObject(result, type);
        }
        String bodyStr = Util.toString(response.body().asReader(Util.UTF_8));
        //if (!(type instanceof Class) && !(type instanceof ParameterizedType) && !(type instanceof WildcardType))
        //log.info();
        throw new RuntimeException("decode error");

    }
}

