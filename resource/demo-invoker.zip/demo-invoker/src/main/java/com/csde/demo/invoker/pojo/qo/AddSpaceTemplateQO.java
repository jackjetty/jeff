package com.csde.demo.invoker.pojo.qo;

import lombok.Data;

/**
 * @author huangjianfeng
 * @version 1.0
 * @ClassName AddSpaceTemplateQO
 * @Desciption []
 * @date 2020/9/4
 */
@Data
public class AddSpaceTemplateQO {

    private String name;
}
