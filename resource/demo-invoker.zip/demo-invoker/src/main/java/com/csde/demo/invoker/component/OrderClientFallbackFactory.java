package com.csde.demo.invoker.component;

import com.csde.demo.invoker.feign.OrderFeignClient;
import com.csde.demo.invoker.pojo.vo.OrderVo;
import com.google.common.collect.Lists;
import feign.hystrix.FallbackFactory;
import java.util.List;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.PathVariable;

@Component
@Slf4j
public class OrderClientFallbackFactory implements FallbackFactory<OrderFeignClient> {

    @Override
    public OrderFeignClient create(Throwable throwable) {
        return new OrderFeignClient(){
            @Override
            public List<OrderVo> getOrder(@PathVariable("id") String id) {
                log.info("message:{}",throwable.getMessage());
                OrderVo orderVo=new OrderVo();
                orderVo.setId("");
                orderVo.setStatus(0);
                orderVo.setCustomer("fail error");
                return Lists.newArrayList(orderVo);
            };
        };
    }
}