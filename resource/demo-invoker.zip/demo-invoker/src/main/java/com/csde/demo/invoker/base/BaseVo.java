package com.csde.demo.invoker.base;
import java.io.Serializable;

public class BaseVo implements Serializable{

    private static final long serialVersionUID = -3042496627856530664L;
}