package com.justbon.jeff.service;

import com.justbon.jeff.entity.EcmUser;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 用户表 服务类
 * </p>
 *
 * @author jeff
 * @since 2021-01-25
 */
public interface IEcmUserService extends IService<EcmUser> {

}
