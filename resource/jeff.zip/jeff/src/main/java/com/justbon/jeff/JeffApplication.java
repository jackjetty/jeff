package com.justbon.jeff;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JeffApplication {

	public static void main(String[] args) {
		SpringApplication.run(JeffApplication.class, args);
	}

}
