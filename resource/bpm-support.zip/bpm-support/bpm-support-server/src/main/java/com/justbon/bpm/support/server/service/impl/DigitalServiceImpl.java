package com.justbon.bpm.support.server.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.justbon.bpm.support.model.digital.dto.ProductDto;
import com.justbon.bpm.support.model.digital.qo.EditProductsVersionQo;
import com.justbon.bpm.support.server.entity.DigitalProduct;
import com.justbon.bpm.support.server.mapper.DigitalProductMapper;
import com.justbon.bpm.support.server.service.IDigitalService;
import java.util.Calendar;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class DigitalServiceImpl implements IDigitalService{

    @Autowired
    private DigitalProductMapper digitalProductMapper;

    @Override
    public List<ProductDto> getProducts() {

        LambdaQueryWrapper<DigitalProduct> queryWrapper = Wrappers.<DigitalProduct>query().lambda()
                .eq(DigitalProduct::getStatus,DigitalProduct.STATUS_ENABLE)
                .orderByAsc(DigitalProduct::getName);
        List<DigitalProduct> digitalProducts=digitalProductMapper.selectList(queryWrapper);
        return  Optional.ofNullable(digitalProducts)
                .orElseGet(Collections::emptyList).stream()
                .map(digitalProduct->{
                    ProductDto productDto =new ProductDto();
                    productDto.setId(digitalProduct.getId());
                    productDto.setName(digitalProduct.getName());
                    productDto.setCode(digitalProduct.getCode());
                    productDto.setVersion(digitalProduct.getVersion());
                    return productDto;
                }).collect(Collectors.toList());
    }

    @Override
    @Transactional
    public boolean editProductsVersion(EditProductsVersionQo editProductsVersionQo) {

        Calendar calendar = Calendar.getInstance();
        String folio=editProductsVersionQo.getFolio();
        Optional.ofNullable(editProductsVersionQo.getEditProducts())
                .orElseGet(Collections::emptyList).stream()
                .forEach(editProduct -> {

                    LambdaUpdateWrapper<DigitalProduct> updateWrapper = Wrappers.<DigitalProduct>update().lambda()
                            .eq(DigitalProduct::getId,editProduct.getId());
                    DigitalProduct digitalProduct=new DigitalProduct();
                    digitalProduct.setVersion(editProduct.getVersion());
                    digitalProduct.setFolio(folio);
                    digitalProduct.setUpdateTime(calendar.getTime());
                    digitalProduct.setIsDeleted(DigitalProduct.DB_NOT_DELETED);
                    digitalProductMapper.update(digitalProduct,updateWrapper);
                });

        return true;
    }
}