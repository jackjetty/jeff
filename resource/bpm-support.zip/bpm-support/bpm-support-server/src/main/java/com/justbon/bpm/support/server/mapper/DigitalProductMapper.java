package com.justbon.bpm.support.server.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.justbon.bpm.support.server.entity.DigitalProduct;
import java.util.Date;
import java.util.List;
import org.apache.ibatis.annotations.Param;


public interface DigitalProductMapper extends BaseMapper<DigitalProduct> {



}