package com.justbon.bpm.support.server.base;

import com.justbon.bpm.support.model.base.R;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

/**
 * Blade控制器封装类
 *
 * @author Chill
 */
public class BaseController {

    /**
     * ============================     REQUEST    =================================================
     */

    @Autowired
    private HttpServletRequest request;

    /**
     * 获取request
     *
     * @return HttpServletRequest
     */
    public HttpServletRequest getRequest() {
        return this.request;
    }



    /** ============================     API_RESULT    =================================================  */

    /**
     * 返回ApiResult
     *
     * @param data 数据
     * @param <T>  T 泛型标记
     * @return R
     */
    public <T> R<T> data(T data) {
        return R.data(data);
    }

    /**
     * 返回ApiResult
     *
     * @param data 数据
     * @param msg  消息
     * @param <T>  T 泛型标记
     * @return R
     */
    public <T> R<T> data(T data, String msg) {
        return R.data(data, msg);
    }

    /**
     * 返回ApiResult
     *
     * @param data 数据
     * @param msg  消息
     * @param code 状态码
     * @param <T>  T 泛型标记
     * @return R
     */
    public <T> R<T> data(T data, String msg, int code) {
        return R.data(code, data, msg);
    }

    /**
     * 返回ApiResult
     *
     * @param msg 消息
     * @return R
     */
    public R success(String msg) {
        return R.success(msg);
    }

    /**
     * 返回ApiResult
     *
     * @param msg 消息
     * @return R
     */
    public R fail(String msg) {
        return R.fail(msg);
    }

    /**
     * 返回ApiResult
     *
     * @param flag 是否成功
     * @return R
     */
    public R status(boolean flag) {
        return R.status(flag);
    }





}
