package com.justbon.bpm.support.server.constant;
/**
 * Token配置常量.
 *
 * @author Chill
 */
public interface TokenConstant {

}