package com.justbon.bpm.support.server.util;

/**
 * 生成的随机数类型
 *
 * @author L.cm
 */
public enum RandomType {
    /**
     * INT STRING ALL
     */
    INT, STRING, ALL
}
