package com.justbon.bpm.support.server;
import com.justbon.bpm.support.server.listener.ApplicationEventListener;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.scheduling.annotation.EnableScheduling;


@SpringBootApplication
@EnableFeignClients("com.justbon")
@ComponentScan(basePackages = {"com.justbon"})
@Slf4j
public class BpmSupportApplication {

    public static void main(String[] args) {

        String name = args != null && args.length > 0 ? args[0] : "process";
        ApplicationEventListener listener = new ApplicationEventListener(BpmSupportApplication.class, name);
        SpringApplication springApplication = new SpringApplication(BpmSupportApplication.class);
        springApplication.addListeners(listener);
        springApplication.run(args);

    }

}
