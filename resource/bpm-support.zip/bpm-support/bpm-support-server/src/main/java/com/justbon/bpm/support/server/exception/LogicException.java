package com.justbon.bpm.support.server.exception;


import com.justbon.bpm.support.model.enums.HttpStatus;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class LogicException extends RuntimeException {


    private static final long serialVersionUID = -1684991431327045000L;

    private int code;
    public LogicException(int code, String message) {
        super(message);
        this.code = code;
    }

    public LogicException(String message) {
        super(message);
        this.code = HttpStatus.BAD_REQUEST.value();
    }

    public LogicException(int code, Throwable cause) {
        super(cause);
        this.code = code;
    }
}