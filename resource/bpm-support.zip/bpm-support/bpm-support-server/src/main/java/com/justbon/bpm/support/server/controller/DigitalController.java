package com.justbon.bpm.support.server.controller;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.justbon.bpm.support.model.base.R;
import com.justbon.bpm.support.model.digital.dto.ProductDto;
import com.justbon.bpm.support.model.digital.qo.EditProductsVersionQo;
import com.justbon.bpm.support.server.base.BaseController;
import com.justbon.bpm.support.server.entity.DigitalProduct;
import com.justbon.bpm.support.server.service.IDigitalService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiOperationSupport;
import io.swagger.annotations.ApiParam;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 *  数科管理控制器
 *
 * @author Chill
 */
@RestController
@RequestMapping("/digital")
@Api(value = "数科部门support", tags = "数科部门support接口")
public class DigitalController extends BaseController {

    @Autowired
    private IDigitalService digitalService;


    @GetMapping(value="/products", produces = MediaType.APPLICATION_JSON_VALUE)
    @ApiOperationSupport(order = 1)
    @ApiOperation(value = "查询有效的products", notes = "查询数科全部的products")
    public R<List<ProductDto>> getProducts(HttpServletRequest request,
            HttpServletResponse response) {

        List<ProductDto> productDtos = digitalService.getProducts();
        return R.data(productDtos);
    }


    @PutMapping(value="/products/version", produces = MediaType.APPLICATION_JSON_VALUE)
    @ApiOperationSupport(order = 2)
    @ApiOperation(value = "更新products 版本信息", notes = "批量更新prodcts 版本")
    public R editProductsVersion(HttpServletRequest request,
            HttpServletResponse response,
            @RequestBody EditProductsVersionQo editProductsVersionQo) {

        boolean status=digitalService.editProductsVersion(editProductsVersionQo);
        return R.data(status);
    }



}