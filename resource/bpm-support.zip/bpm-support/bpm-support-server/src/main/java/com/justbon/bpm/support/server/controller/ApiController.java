package com.justbon.bpm.support.server.controller;

import com.justbon.bpm.support.model.base.R;
import com.justbon.bpm.support.server.base.BaseController;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiOperationSupport;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import springfox.documentation.annotations.ApiIgnore;

/**
 * 数科管理控制器
 *
 * @author Chill
 */
@RestController
@ApiIgnore
public class ApiController extends BaseController {

    @GetMapping(value = "/api/ping")
    @ApiOperationSupport(order = 1)
    @ApiOperation(value = "检查服务状态", notes = "ping 服务")
    public R publish(HttpServletRequest request, HttpServletResponse response) {
        return R.status(true);
    }
}