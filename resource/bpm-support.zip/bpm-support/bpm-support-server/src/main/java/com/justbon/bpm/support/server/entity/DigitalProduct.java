package com.justbon.bpm.support.server.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.justbon.bpm.support.server.base.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;
import java.util.List;

@Data
@TableName("sp_digital_product")
@EqualsAndHashCode(callSuper = true)
@ApiModel(value = "网关实例对象", description = "网关实例对象")
public class DigitalProduct extends BaseEntity {


    private static final long serialVersionUID = 8856696762744514001L;

    @TableId(value = "id", type = IdType.ID_WORKER_STR)
    @ApiModelProperty(value = "主键/唯一标记")
    private String id;

    @ApiModelProperty(value = "名称")
    private String name;

    @ApiModelProperty(value = "编码")
    private String code;

    @ApiModelProperty(value = "软件版本")
    private String version;

    @ApiModelProperty(value = "申请单号")
    private String folio;


}