package com.justbon.bpm.support.server.constant;

public interface AppConstant{

    /**
     * 应用版本
     */
    String APPLICATION_VERSION = "0.0.1";

    /**
     * 基础包
     */
    String BASE_PACKAGES = "com.justbon";


    /**
     * 开发环境
     */
    String DEV_CODE = "dev";
    /**
     * 生产环境
     */
    String PROD_CODE = "prod";
    /**
     * 测试环境
     */
    String TEST_CODE = "test";
}