package com.justbon.bpm.support.server.service;

import com.justbon.bpm.support.model.digital.dto.ProductDto;
import com.justbon.bpm.support.model.digital.qo.EditProductsVersionQo;
import java.util.List;

public  interface IDigitalService{

    List<ProductDto> getProducts();

    boolean editProductsVersion(EditProductsVersionQo editProductsVersionQo);
}
