package com.justbon.bpm.support.server.listener;

import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.context.event.ApplicationEnvironmentPreparedEvent;
import org.springframework.boot.context.event.ApplicationPreparedEvent;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.ApplicationEvent;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextClosedEvent;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.context.event.ContextStartedEvent;
import org.springframework.context.event.ContextStoppedEvent;

import java.io.File;
import java.io.IOException;
import java.lang.management.ManagementFactory;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;



@Slf4j
public class ApplicationEventListener implements ApplicationListener {
    private String appName;
    private String mainPath = "";
    public static ApplicationEventListener listener = null;

    public static String getMainPath() {
        assert listener != null;

        return listener.mainPath;
    }

    public ApplicationEventListener(Class mainClass, String appName) {
        this.appName = appName;
        String osName = System.getProperty("os.name").toLowerCase();
        String url = mainClass.getProtectionDomain().getCodeSource().getLocation().toString();
        Path dir;
        Path parentDir;
        if (osName.contains("windows")) {
            url = url.replace("file:/", "");
            dir = Paths.get(url);
            parentDir = dir.getParent();
            this.mainPath = parentDir.getParent().toString();
        } else {
            dir = Paths.get(url);
            parentDir = dir.getParent();
            if (!parentDir.endsWith("target")) {
                this.mainPath = parentDir.getParent().getParent().getParent().toString();
                this.mainPath = this.mainPath.substring(9);
            } else {
                this.mainPath = parentDir.getParent().toString();
                this.mainPath = this.mainPath.substring(5);
            }
        }

        log.info("class路径:" + url);
        log.info("mainPath:" + this.mainPath);
        if (listener == null) {
            listener = this;
        }
    }

    @Override
    public void onApplicationEvent(ApplicationEvent event) {
        // 在这里可以监听到Spring Boot的生命周期
        if (event instanceof ApplicationEnvironmentPreparedEvent) {
            log.info("初始化环境变量完成");
        } else if (event instanceof ApplicationPreparedEvent) {
            log.info("初始化完成");
        } else if (event instanceof ContextRefreshedEvent) {
            log.info("应用刷新完成");
        } else if (event instanceof ApplicationReadyEvent) {
            doCreatePidFile();
        } else if (event instanceof ContextStartedEvent) {
            log.info("应用启动完成，需要在代码动态添加监听器才可捕获");
        } else if (event instanceof ContextStoppedEvent) {
            log.info("应用停止完成");
        } else if (event instanceof ContextClosedEvent) {
            log.info("应用关闭完成");
        }
    }

    public void doCreatePidFile() {
        String pidFile = this.getPidFileFullPath();
        String pid = this.CreatePidFile(pidFile);
        log.info("应用启动完成，写进程id文件:" + pidFile + " 进程id:" + pid);
    }

    private String getPidFileFullPath() {
        return mainPath + File.separator + appName + ".pid";
    }

    private String CreatePidFile(String pidFileFullPath) {
        String name = ManagementFactory.getRuntimeMXBean().getName();
        String pid = name.split("@")[0];
        Path path = Paths.get(pidFileFullPath);
        try {
            Files.write(path, pid.getBytes());
            return pid;
        } catch (Exception e) {
            log.info(e.toString());
            return "";
        }
    }

    private void deletePidFile() {
        String pidFile = getPidFileFullPath();
        Path filePath = Paths.get(pidFile);
        try {
            Files.deleteIfExists(filePath);
        } catch (IOException e) {
            log.info(e.toString());
        }
    }

    public boolean isRunning() {
        String pidFile = getPidFileFullPath();
        Path filePath = Paths.get(pidFile);
        return Files.exists(filePath);
    }
}