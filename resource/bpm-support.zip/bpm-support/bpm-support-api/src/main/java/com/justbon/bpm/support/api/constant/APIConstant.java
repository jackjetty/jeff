package com.justbon.bpm.support.api.constant;
public interface APIConstant{

    String SERVER_NAME="bpm-support-server";

    String CONTEXT_PATH="/bpm-support";

}