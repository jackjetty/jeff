package com.justbon.bpm.support.api.client;

import com.justbon.bpm.support.model.base.R;
import com.justbon.bpm.support.model.digital.dto.ProductDto;
import com.justbon.bpm.support.model.digital.qo.EditProductsVersionQo;
import java.util.List;
import org.springframework.stereotype.Component;

@Component
public class DigitalClientFallback implements IDigitalClient {


    @Override
    public R<List<ProductDto>> getProducts() {
        return R.fail("获取数据失败");
    }

    @Override
    public R editProductsVersion(EditProductsVersionQo editProductsVersionQo) {
        return R.fail("获取数据失败");
    }
}