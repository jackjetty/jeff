package com.justbon.bpm.support.api.client;
import com.justbon.bpm.support.api.constant.APIConstant;
import com.justbon.bpm.support.model.base.R;
import com.justbon.bpm.support.model.digital.dto.ProductDto;
import com.justbon.bpm.support.model.digital.qo.EditProductsVersionQo;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.List;

@FeignClient(
        value = APIConstant.SERVER_NAME,
        fallback =  DigitalClientFallback.class,
        path = APIConstant.CONTEXT_PATH
)
public interface IDigitalClient {

    @GetMapping(value="/products", produces = MediaType.APPLICATION_JSON_VALUE)
    R<List<ProductDto>> getProducts() ;


    @PutMapping(value="/products/version", produces = MediaType.APPLICATION_JSON_VALUE)
    R editProductsVersion(@RequestBody EditProductsVersionQo editProductsVersionQo) ;

}