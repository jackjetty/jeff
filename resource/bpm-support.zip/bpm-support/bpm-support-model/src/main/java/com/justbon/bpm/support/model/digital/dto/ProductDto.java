package com.justbon.bpm.support.model.digital.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.io.Serializable;
import java.util.Date;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

@Data
@ApiModel(value = "数科产品列表元素对象", description = "数科产品列表元素对象")
public class ProductDto implements Serializable {

	private static final long serialVersionUID = -1522946253567421143L;

	@ApiModelProperty(value = "唯一标识")
	private String id;

	@ApiModelProperty(value = "名称")
	private String name;

	@ApiModelProperty(value = "编号")
	private String code;

	@ApiModelProperty(value = "版本号")
	private String version;
}