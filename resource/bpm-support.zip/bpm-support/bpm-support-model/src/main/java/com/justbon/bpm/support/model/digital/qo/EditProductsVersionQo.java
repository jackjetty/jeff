package com.justbon.bpm.support.model.digital.qo;

import io.swagger.annotations.ApiModelProperty;
import java.io.Serializable;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
@Setter
@Getter
public class EditProductsVersionQo implements Serializable{

    private static final long serialVersionUID = -787278939503337283L;
    @ApiModelProperty(value = "申请单号")
    private String  folio;
    @ApiModelProperty(value = "产品信息集合")
    private List<EditProduct> editProducts;

    @Setter
    @Getter
    public static class EditProduct{

        @ApiModelProperty(value = "产品id")
        private String id;
        @ApiModelProperty(value = "产品version")
        private String version;


    }
}