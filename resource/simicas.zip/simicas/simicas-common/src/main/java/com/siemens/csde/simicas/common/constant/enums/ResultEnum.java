package com.siemens.csde.simicas.common.constant.enums;



public enum ResultEnum {

    SUCCESS(1, "success"),
    ERROR(0, "error"),

    INVALID_TOKEN(455,"invalid token");

    ResultEnum(int resultCode, String resultInfo) {
        this.code = resultCode;
        this.info = resultInfo;
    }

    private int code;
    private String info;

    public String getInfo() {
        return this.info;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public void setInfo(String info) {
        this.info = info;
    }

    public static ResultEnum getByCode(int code) {
        for (ResultEnum responseCode : ResultEnum.values()) {
            if (responseCode.getCode() == code) {
                return responseCode;
            }
        }
        return null;
    }
}
