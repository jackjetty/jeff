package com.siemens.csde.simicas.common.constant;

/**
 * EffErrorConstant  eff 错误code常量
 *
 * @author z004267r
 * @version 1.0-SNAPSHOT
 * @date 8/23/2019 2:27 PM
 **/
public class EffErrorConstant {

    //正常
    public static final Integer NORMAL = 0;

    //ict缺少
    public static final Integer MISSING_ICT = -1;

    //change over
    public static final Integer CHANGE_OVER = -2;
}
