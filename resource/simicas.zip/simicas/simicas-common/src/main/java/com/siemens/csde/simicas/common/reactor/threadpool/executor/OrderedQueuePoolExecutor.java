package com.siemens.csde.simicas.common.reactor.threadpool.executor;

import com.siemens.csde.simicas.common.reactor.threadpool.ThreadNameFactory;
import com.siemens.csde.simicas.common.reactor.threadpool.worker.AbstractWork;
import com.siemens.csde.simicas.common.reactor.threadpool.worker.OrderedQueuePool;
import com.siemens.csde.simicas.common.reactor.threadpool.worker.TasksQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import lombok.extern.slf4j.Slf4j;

/**
 * OrderedQueuePoolExecutor 有序执行线程池
 * @author z004267r
 * @version 1.0-SNAPSHOT
 * @date 8/23/2019 3:14 PM
 **/
@Slf4j
public class OrderedQueuePoolExecutor extends ThreadPoolExecutor {

    private OrderedQueuePool<String, AbstractWork> pool;

    private int maxQueueSize;

    private ThreadNameFactory threadNameFactory;

    public OrderedQueuePoolExecutor(String name, int corePoolSize, int maxQueueSize) {
        super(corePoolSize, 2 * corePoolSize, 30L,
                TimeUnit.SECONDS, new LinkedBlockingQueue(), new ThreadNameFactory(name));
        this.pool = new OrderedQueuePool();
        this.maxQueueSize = maxQueueSize;
        this.threadNameFactory = (ThreadNameFactory)this.getThreadFactory();
    }

    /**
     * 添加work
     * @author z004267r
     * @param key  key
     * @param task  task
     * @return boolean
     * @date 8/23/2019 3:15 PM
     */
    public boolean addTask(String key, AbstractWork task) {
        TasksQueue<AbstractWork> queue = this.pool.getTasksQueue(key);
        boolean run = false;
        boolean result = false;
        synchronized(queue) {
            if (this.maxQueueSize > 0 && queue.size() > this.maxQueueSize ) {
                log.error("Queue" + this.threadNameFactory.getNamePrefix() + "(" + key + ")Exceeds the maximum queue size setting!");
            }
            result = queue.add(task);
            if (result) {
                task.setTasksQueue(queue);
                if (queue.isProcessingCompleted()) {
                    queue.setProcessingCompleted(false);
                    run = true;
                }
            } else {
                log.error("Queue add task failed");
            }
        }

        if (run) {
            try {
                this.execute(queue.poll());
            }catch (Exception e){
                log.error("execute task error: {}",e);
                afterExecute(queue.poll(),e);
            }
        }
        return result;
    }

    public int get(String key) {
       return this.pool.getTasksQueue(key).size();
    }

    /**
     * 执行后队列设置
     * @author z004267r
     * @param r  r
     * @param t  t
     * @return void
     * @date 8/23/2019 3:15 PM
     */
    protected void afterExecute(Runnable r, Throwable t) {
        super.afterExecute(r, t);
        AbstractWork work = (AbstractWork)r;
        TasksQueue<AbstractWork> queue = work.getTasksQueue();
        if (queue != null) {
            AbstractWork afterWork = null;
            synchronized(queue) {
                afterWork = queue.poll();
                if (afterWork == null) {
                    queue.setProcessingCompleted(true);
                }
            }

            if (afterWork != null) {
                this.execute(afterWork);
            }
        } else {
            log.error("Queue add task failed");
        }

    }
}
