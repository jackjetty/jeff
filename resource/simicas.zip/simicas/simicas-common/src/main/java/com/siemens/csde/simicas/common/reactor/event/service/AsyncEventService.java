package com.siemens.csde.simicas.common.reactor.event.service;


import com.siemens.csde.simicas.common.reactor.event.EventBus;
import com.siemens.csde.simicas.common.reactor.event.impl.event.SingleEvent;
import com.siemens.csde.simicas.common.reactor.threadpool.ThreadNameFactory;
import com.siemens.csde.simicas.common.reactor.threadpool.executor.NonOrderedQueuePoolExecutor;
import com.siemens.csde.simicas.common.reactor.threadpool.executor.OrderedQueuePoolExecutor;
import com.siemens.csde.simicas.common.reactor.util.CommonErrorInfo;
import com.siemens.csde.simicas.common.reactor.util.ErrorsUtil;
import com.siemens.csde.simicas.common.reactor.util.ExecutorUtil;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import lombok.extern.slf4j.Slf4j;

/**
 * AsyncEventService 异步事件服务
 *
 * @author z004267r
 * @version 1.0-SNAPSHOT
 * @date 8/23/2019 3:01 PM
 **/
@Slf4j
public class AsyncEventService {

    private EventBus eventBus;

    private BlockingQueue<SingleEvent> queue;

    private OrderedQueuePoolExecutor orderedQueuePoolExecutor;

    private NonOrderedQueuePoolExecutor nonOrderedQueuePoolExecutor;

    // 处理的消息总数
    public long statisticsMessageCount = 0;

    //work线程池大小
    private int workSize;

    //事件异步处理线程池大小
    private int handlerSize;

    //执行线程池名字
    private String threadFactoryName;

    //顺序执行线程池队列大小
    private int orderQueueMaxSize;

    //消息处理线程池
    private volatile ExecutorService executorService;

    //work线程池名字
    private String workThreadFactoryName;

    //是否顺序执行
    private boolean isOrder;

    /**
     * 构造方法
     *
     * @param eventBus 事件总线
     * @param queueSize 生产者队列大小
     * @param workSize 消费者工作线程
     * @param workThreadFactoryName work线程池名字
     * @param handlerSize 事件异步处理线程池大小
     * @param threadFactoryName 执行线程池名字
     * @param orderQueueMaxSize 顺序执行线程池队列大小
     */
    public AsyncEventService(EventBus eventBus, int queueSize, int workSize, String workThreadFactoryName,
            int handlerSize, String threadFactoryName, int orderQueueMaxSize) {
        this.eventBus = eventBus;
        queue = new ArrayBlockingQueue<SingleEvent>(queueSize);
        this.workSize = workSize;
        this.workThreadFactoryName = workThreadFactoryName;
        this.handlerSize = handlerSize;
        this.threadFactoryName = threadFactoryName;
        this.orderQueueMaxSize = orderQueueMaxSize;
        this.isOrder = true;
    }

    /**
     * 异步事件服务启动
     *
     * @param isOrder isOrder
     * @return void
     * @author z004267r
     * @date 8/23/2019 3:02 PM
     */
    public void startUp(boolean isOrder) {
        this.isOrder = isOrder;
        try {
            if (isOrder) {
                if (orderedQueuePoolExecutor != null) {
                    throw new IllegalStateException(
                            "AsyncEventService The executorSerive has not been stopped.");
                }
                orderedQueuePoolExecutor = new OrderedQueuePoolExecutor(threadFactoryName, handlerSize, orderQueueMaxSize);
            } else {
                if (nonOrderedQueuePoolExecutor != null) {
                    throw new IllegalStateException(
                            "AsyncEventService The executorSerive has not been stopped.");
                }
                nonOrderedQueuePoolExecutor = new NonOrderedQueuePoolExecutor(threadFactoryName, handlerSize);
            }

            ThreadNameFactory factory = new ThreadNameFactory(workThreadFactoryName);
            executorService = Executors.newFixedThreadPool(this.workSize, factory);

            for (int i = 0; i < this.workSize; i++) {
                executorService.execute(new Worker());
            }

        } catch (Exception e) {
            log.error(" AsyncEventService startUp error", e);
        }

    }

    /**
     * 异步事件服务关闭
     *
     * @param * @return void
     * @author z004267r
     * @date 8/23/2019 3:02 PM
     */
    public void shutDown() {

        log.info("AsyncEventService eventbus" + this + " stopping ...");
        eventBus.clear();
        log.info("AsyncEventService worker" + this + " stopping ...");
        if (executorService != null) {
            ExecutorUtil.shutdownAndAwaitTermination(executorService, 60,
                    TimeUnit.MILLISECONDS);
            executorService = null;
        }

        log.info("AsyncEventService order handle thread" + this + " stopping ...");
        if (orderedQueuePoolExecutor != null) {
            ExecutorUtil.shutdownAndAwaitTermination(orderedQueuePoolExecutor, 60,
                    TimeUnit.MILLISECONDS);
            orderedQueuePoolExecutor = null;
        }

        log.info("AsyncEventService noOrder handle thread" + this + " stopping ...");
        if (nonOrderedQueuePoolExecutor != null) {
            ExecutorUtil.shutdownAndAwaitTermination(nonOrderedQueuePoolExecutor, 60,
                    TimeUnit.MILLISECONDS);
            nonOrderedQueuePoolExecutor = null;
        }

        log.info("AsyncEventService" + this + " stopped");
    }

    /**
     * 添加具体事件到队列中
     *
     * @param event event
     * @return void
     * @author z004267r
     * @date 8/23/2019 3:03 PM
     */
    public void put(SingleEvent event) {
        try {
            queue.put(event);
        } catch (InterruptedException e) {
            log.error(CommonErrorInfo.THRAD_ERR_INTERRUPTED, e);
        }
    }

    /**
     * 处理具体的事件
     *
     * @param event event
     * @return void
     * @author z004267r
     * @date 8/23/2019 3:03 PM
     */
    public void process(SingleEvent event) {
        if (event == null) {
            return;
        }
        this.statisticsMessageCount++;
        try {
            if (isOrder) {
                if (orderedQueuePoolExecutor != null) {
                    orderedQueuePoolExecutor.addTask(event.getShardingId(), new SingleEventWork(eventBus, event));
                }
            } else {
                if (nonOrderedQueuePoolExecutor != null) {
                    nonOrderedQueuePoolExecutor.addTask(new SingleEventWork(eventBus, event));
                }
            }
        } catch (Exception e) {

            log.error(ErrorsUtil.error("Error",
                    "#.AsyncEventService.process", "param"), e);
        }
    }

    /**
     * Worker 处理线程类
     *
     * @author z004267r
     * @version 1.0-SNAPSHOT
     * @date 8/23/2019 3:04 PM
     **/
    private final class Worker implements Runnable {

        @Override
        public void run() {
            while (true) {
                try {
                    process(queue.take());
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    log.error("Thread.currentThread().interrupt()", e);
                    break;
                } catch (Exception e) {
                    log.error(CommonErrorInfo.EVENT_PRO_ERROR, e);
                }
            }
        }
    }
}
