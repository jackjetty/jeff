package com.siemens.csde.simicas.common.reactor.event.impl;


import com.siemens.csde.simicas.common.reactor.event.EventResult;
import com.siemens.csde.simicas.common.reactor.event.EventType;
import com.siemens.csde.simicas.common.reactor.event.IEvent;
import com.siemens.csde.simicas.common.reactor.event.IEventListener;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArraySet;

/**
 * AbstractEventListener 抽象事件监听器
 *
 * @author z004267r
 * @version 1.0-SNAPSHOT
 * @date 8/23/2019 3:00 PM
 **/
public abstract class AbstractEventListener<T> implements IEventListener {

    private Set<EventType> eventTypes;

    public AbstractEventListener() {
        this.eventTypes = new CopyOnWriteArraySet<EventType>();
        initEventType();
    }

    public abstract void initEventType();

    public void register(EventType eventType) {
        this.eventTypes.add(eventType);
    }

    public void unRegister(EventType eventType) {
        this.eventTypes.remove(eventType);
    }

    public boolean containEventType(EventType eventType) {
        return eventTypes.contains(eventType);
    }

    public EventResult fireEvent(IEvent event) {
        return event.call();
    }

    public Set<EventType> getSet() {
        return eventTypes;
    }

}
