package com.siemens.csde.simicas.common.reactor.event;


import com.siemens.csde.simicas.common.reactor.event.impl.AbstractEventListener;

/**
 * IEventBus 事件总线接口
 *
 * @author z004267r
 * @version 1.0-SNAPSHOT
 * @date 8/23/2019 3:09 PM
 **/
@SuppressWarnings("unused")
public interface IEventBus {

    /**
     * 添加事件监听器
     *
     * @param listener listener
     * @return void
     * @author z004267r
     * @date 8/23/2019 3:09 PM
     */
    void addEventListener(AbstractEventListener listener);

    /**
     * 删除事件监听器
     *
     * @param listener listener
     * @return void
     * @author z004267r
     * @date 8/23/2019 3:09 PM
     */
    void removeEventListener(AbstractEventListener listener);

    /**
     * 清除所有事件监听器
     *
     * @author z004267r
     * @date 8/23/2019 3:09 PM
     */
    void clearEventListener();

    /**
     * 添加事件
     *
     * @param event event
     * @return void
     * @author z004267r
     * @date 8/23/2019 3:09 PM
     */
    void addEvent(IEvent event);

    /**
     * 驱动事件
     *
     * @author z004267r
     * @date 8/23/2019 3:09 PM
     */
    void handleEvent();

    /**
     * 循环驱动事件
     *
     * @param event event
     * @author z004267r
     * @date 8/23/2019 3:10 PM
     */
    void handleSingleEvent(IEvent event) throws Exception;

    /**
     * 清除所有事件
     *
     * @return void
     * @author z004267r
     * @date 8/23/2019 3:10 PM
     */
    void clearEvent();

    /**
     * 清除事件监听器及事件
     *
     * @author z004267r
     * @date 8/23/2019 3:10 PM
     */
    void clear();
}
