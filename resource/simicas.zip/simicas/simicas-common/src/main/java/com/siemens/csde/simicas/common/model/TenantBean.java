package com.siemens.csde.simicas.common.model;

import com.google.gson.annotations.SerializedName;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TenantBean {

    @SerializedName("ETag")
    private long eTag;

    private boolean allowedToCreateSubtenant;

    private String companyName;

    private String country;

    private String displayName;

    private String name;

    private String prefix;

    private String type;

}
