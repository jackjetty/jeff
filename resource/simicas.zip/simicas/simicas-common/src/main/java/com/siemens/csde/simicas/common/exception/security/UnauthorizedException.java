package com.siemens.csde.simicas.common.exception.security;

import org.springframework.http.HttpStatus;


public class UnauthorizedException extends Auth2Exception {

	public UnauthorizedException(String msg, Throwable t) {
		super(msg);
	}

	@Override
	public String getOAuth2ErrorCode() {
		return HttpStatus.UNAUTHORIZED.getReasonPhrase();
	}

	@Override
	public int getHttpErrorCode() {
		return HttpStatus.UNAUTHORIZED.value();
	}

}
