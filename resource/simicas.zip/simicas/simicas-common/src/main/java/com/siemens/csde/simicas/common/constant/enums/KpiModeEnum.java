package com.siemens.csde.simicas.common.constant.enums;

/**
 * KpiModeEnum
 *
 * @author z004267r
 * @version 1.0-SNAPSHOT
 * @date 3/18/2020 1:20 PM
 **/
public enum KpiModeEnum {

    DEFAULT(0, "DEFAULT"),
    CUSTOM(1, "CUSTOM");

    private int code;
    private String mode;

    KpiModeEnum(int code, String mode) {
        this.code = code;
        this.mode = mode;
    }

    public String getMode() {
        return this.mode;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public void setMode(String info) {
        this.mode = mode;
    }

    public static KpiModeEnum getByCode(int code) {
        for (KpiModeEnum kpiModeEnum : KpiModeEnum.values()) {
            if (kpiModeEnum.getCode() == code) {
                return kpiModeEnum;
            }
        }
        return null;
    }
}