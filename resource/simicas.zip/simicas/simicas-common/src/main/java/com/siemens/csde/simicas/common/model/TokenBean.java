package com.siemens.csde.simicas.common.model;

import com.google.gson.annotations.SerializedName;
import lombok.Getter;
import lombok.Setter;


@Getter
@Setter
public class TokenBean {

    @SerializedName("access_token")
    private String accessToken;

    @SerializedName("token_type")
    private String tokenType;

    @SerializedName("expires_in")
    private Integer expiresIn;

    private String scope;

    @SerializedName("jti")
    private String jti;

    public String getBearerToken() {
        return "Bearer " + accessToken;
    }

}
