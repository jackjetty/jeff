package com.siemens.csde.simicas.common.util;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.connection.DataType;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

/**
 * RedisUtil
 * @author z004267r
 * @version 1.0-SNAPSHOT
 * @date 3/28/2020 10:55 PM
 **/
@SuppressWarnings("unused")
@Component
@Slf4j
public class RedisUtil {

    @Autowired
    private RedisTemplate<String, Object> redisTemplate;

    /*============================key相关操作============================ */
    /**
     * 序列化key
     * @author z004267r
     * @param key  key
     * @return byte[]
     * @date 3/28/2020 10:55 PM
     */
    public byte[] dump(String key) {
        return redisTemplate.dump(key);
    }

    /**
     * 设置过期时间
     * @author z004267r
     * @param key  key
     * @param date  date
     * @return java.lang.Boolean
     * @date 3/28/2020 10:56 PM
     */
    public Boolean expireAt(String key, Date date) {
        return redisTemplate.expireAt(key, date);
    }

    /**
     * 查找匹配的key
     * @author z004267r
     * @param pattern  pattern
     * @return java.util.Set<java.lang.String>
     * @date 3/28/2020 10:56 PM
     */
    public Set<String> keys(String pattern) {
        return redisTemplate.keys(pattern);
    }

    /**
     * 从当前数据库中随机返回一个 key
     * @author z004267r
     * @param    * @return java.lang.String
     * @date 3/28/2020 10:56 PM
     */
    public String randomKey() {
        return redisTemplate.randomKey();
    }

    /**
     * 修改 key 的名称
     * @author z004267r
     * @param oldKey  oldKey
     * @param newKey  newKey
     * @return void
     * @date 3/28/2020 10:56 PM
     */
    public void rename(String oldKey, String newKey) {
        redisTemplate.rename(oldKey, newKey);
    }

    /**
     * 返回 key 所储存的值的类型
     * @author z004267r
     * @param key  key
     * @return org.springframework.data.redis.connection.DataType
     * @date 3/28/2020 10:57 PM
     */
    public DataType type(String key) {
        return redisTemplate.type(key);
    }

    /**
     * 指定缓存失效时间
     * @author z004267r
     * @param key  key
     * @param time  time
     * @return boolean
     * @date 3/28/2020 10:57 PM
     */
    public boolean expire(String key, long time) {
        try {
            if (time > 0) {
                redisTemplate.expire(key, time, TimeUnit.HOURS);
            }
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * 根据key 获取过期时间
     * @author z004267r
     * @param key  key
     * @return long
     * @date 3/28/2020 10:57 PM
     */
    public long getExpire(String key) {
        return redisTemplate.getExpire(key, TimeUnit.HOURS);
    }

    /**
     * 判断key是否存在
     * @author z004267r
     * @param key  key
     * @return boolean
     * @date 3/28/2020 10:57 PM
     */
    public boolean hasKey(String key) {
        try {
            return redisTemplate.hasKey(key);
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * 删除缓存
     * @author z004267r
     * @param key  key
     * @return void
     * @date 3/28/2020 10:58 PM
     */
    @SuppressWarnings("unchecked")
    public void del(String... key) {
        if (key != null && key.length > 0) {
            if (key.length == 1) {
                redisTemplate.delete(key[0]);
            } else {
                redisTemplate.delete(CollectionUtils.arrayToList(key));
            }
        }
    }

    /* ============================简单object============================= */
    /**
     * 普通缓存获取
     * @author z004267r
     * @param key  key
     * @return java.lang.Object
     * @date 3/28/2020 10:59 PM
     */
    public Object get(String key) {
        return redisTemplate.opsForValue().get(key);
    }

    /**
     * 普通缓存放入
     * @author z004267r
     * @param key  key
     * @param value  value
     * @return boolean
     * @date 3/28/2020 10:59 PM
     */
    public boolean set(String key, Object value) {
        try {
            redisTemplate.opsForValue().set(key, value);
            return true;
        } catch (Exception e) {
            log.error("set string error",e);
            return false;
        }

    }

    /**
     * 普通缓存放入并设置时间
     * @author z004267r
     * @param key  key
     * @param value  value
     * @param time  time (小时)
     * @return boolean
     * @date 3/28/2020 10:59 PM
     */
    public boolean set(String key, Object value, long time) {
        try {
            if (time > 0) {
                redisTemplate.opsForValue().set(key, value, time, TimeUnit.HOURS);
            } else {
                set(key, value);
            }
            return true;
        } catch (Exception e) {
            log.error("set string error",e);
            return false;
        }
    }

    /**
     * 递增
     * @author z004267r
     * @param key  key
     * @param delta  delta
     * @return long
     * @date 3/28/2020 11:00 PM
     */
    public long incr(String key, long delta) {
        if (delta < 0) {
            throw new RuntimeException("递增因子必须大于0");
        }
        return redisTemplate.opsForValue().increment(key, delta);
    }

    /**
     * 递减
     * @author z004267r
     * @param key  key
     * @param delta  delta
     * @return long
     * @date 3/28/2020 11:00 PM
     */
    public long decr(String key, long delta) {
        if (delta < 0) {
            throw new RuntimeException("递减因子必须大于0");
        }
        return redisTemplate.opsForValue().increment(key, -delta);
    }

    /* ================================Hash Map================================= */
    /**
     * HashGet
     * @author z004267r
     * @param key  key
     * @param item  item
     * @return java.lang.Object
     * @date 3/28/2020 11:00 PM
     */
    public Object hget(String key, String item) {
        return redisTemplate.opsForHash().get(key, item);
    }

    /**
     * 获取hashKey对应的所有键值
     * @author z004267r
     * @param key  key
     * @return java.util.Map<java.lang.Object,java.lang.Object>
     * @date 3/28/2020 11:02 PM
     */
    public Map<Object, Object> hmget(String key) {
        return redisTemplate.opsForHash().entries(key);
    }

    /**
     * HashSet
     * @author z004267r
     * @param key  key
     * @param map  map
     * @return boolean
     * @date 3/28/2020 11:03 PM
     */
    public boolean hmset(String key, Map<String, Object> map) {
        try {
            redisTemplate.opsForHash().putAll(key, map);
            return true;
        } catch (Exception e) {
            log.error("set map error",e);
            return false;
        }
    }

    /**
     * HashSet 并设置时间
     * @author z004267r
     * @param key  key
     * @param map  map
     * @param time  time
     * @return boolean
     * @date 3/28/2020 11:03 PM
     */
    public boolean hmset(String key, Map<String, Object> map, long time) {
        try {
            redisTemplate.opsForHash().putAll(key, map);
            if (time > 0) {
                expire(key, time);
            }
            return true;
        } catch (Exception e) {
            log.error("set map error",e);;
            return false;
        }
    }

    /**
     * 向一张hash表中放入数据,如果不存在将创建
     * @author z004267r
     * @param key  key
     * @param item  item
     * @param value  value
     * @return boolean
     * @date 3/28/2020 11:04 PM
     */
    public boolean hset(String key, String item, Object value) {
        try {
            redisTemplate.opsForHash().put(key, item, value);
            return true;
        } catch (Exception e) {
            log.error("set map error",e);;
            return false;
        }
    }

    /**
     * 向一张hash表中放入数据,如果不存在将创建
     * @author z004267r
     * @param key  key
     * @param item  item
     * @param value  value
     * @param time  time
     * @return boolean
     * @date 3/28/2020 11:05 PM
     */
    public boolean hset(String key, String item, Object value, long time) {
        try {
            redisTemplate.opsForHash().put(key, item, value);
            if (time > 0) {
                expire(key, time);
            }
            return true;
        } catch (Exception e) {
            log.error("set map error",e);;
            return false;
        }
    }

    /**
     * 删除hash表中的值
     * @author z004267r
     * @param key  key
     * @param item  item
     * @return void
     * @date 3/28/2020 11:05 PM
     */
    public void hdel(String key, String... item) {
        redisTemplate.opsForHash().delete(key, item);
    }

    /**
     * 判断hash表中是否有该项的值
     * @author z004267r
     * @param key  key
     * @param item  item
     * @return boolean
     * @date 3/28/2020 11:05 PM
     */
    public boolean hhasKey(String key, String item) {
        return redisTemplate.opsForHash().hasKey(key, item);
    }

    /**
     * hash递增 如果不存在,就会创建一个 并把新增后的值返回
     * @author z004267r
     * @param key  key
     * @param item  item
     * @param by  by
     * @return double
     * @date 3/28/2020 11:05 PM
     */
    public double hincr(String key, String item, double by) {
        return redisTemplate.opsForHash().increment(key, item, by);
    }

    /**
     * hash递减
     * @author z004267r
     * @param key  key
     * @param item  item
     * @param by  by
     * @return double
     * @date 3/28/2020 11:06 PM
     */
    public double hdecr(String key, String item, double by) {
        return redisTemplate.opsForHash().increment(key, item, -by);
    }

    /* ============================set============================= */
    /**
     * 根据key获取Set中的所有值
     * @author z004267r
     * @param key  key
     * @return java.util.Set<java.lang.Object>
     * @date 3/28/2020 11:06 PM
     */
    public Set<Object> sget(String key) {
        try {
            return redisTemplate.opsForSet().members(key);
        } catch (Exception e) {
            log.error("get set error",e);
            return null;
        }

    }

    /**
     * 根据value从一个set中查询,是否存在
     * @author z004267r
     * @param key  key
     * @param value  value
     * @return boolean
     * @date 3/28/2020 11:07 PM
     */
    public boolean shasKey(String key, Object value) {
        try {
            return redisTemplate.opsForSet().isMember(key, value);
        } catch (Exception e) {
            log.error("set set error",e);
            return false;
        }
    }

    /**
     * 将数据放入set缓存
     * @author z004267r
     * @param key  key
     * @param values  values
     * @return long
     * @date 3/28/2020 11:07 PM
     */
    public long sset(String key, Object... values) {
        try {
            return redisTemplate.opsForSet().add(key, values);
        } catch (Exception e) {
            log.error("set set error",e);
            return 0;
        }
    }

    /**
     * 将set数据放入缓存
     * @author z004267r
     * @param key  key
     * @param time  time
     * @param values  values
     * @return long
     * @date 3/28/2020 11:07 PM
     */
    public long sset(String key, long time, Object... values) {
        try {
            Long count = redisTemplate.opsForSet().add(key, values);
            if (time > 0) {
                expire(key, time);
            }
            return count;
        } catch (Exception e) {
            log.error("set set error",e);
            return 0;
        }
    }

    /**
     * 获取set缓存的长度
     * @author z004267r
     * @param key  key
     * @return long
     * @date 3/28/2020 11:09 PM
     */
    public long sgetSetSize(String key) {
        try {
            return redisTemplate.opsForSet().size(key);
        } catch (Exception e) {
            log.error("set set error",e);
            return 0;
        }
    }

    /**
     * 移除值为value的
     * @author z004267r
     * @param key  key
     * @param values  values
     * @return long
     * @date 3/28/2020 11:10 PM
     */
    public long sdel(String key, Object... values) {
        try {
            Long count = redisTemplate.opsForSet().remove(key, values);
            return count;
        } catch (Exception e) {
            log.error("remove set error",e);
            return 0;
        }
    }

    /* ===============================list================================= */
    /**
     * 获取list缓存的内容
     * @author z004267r
     * @param key  key
     * @param start  start
     * @param end  end
     * @return java.util.List<java.lang.Object>
     * @date 3/28/2020 11:11 PM
     */
    public List<Object> lget(String key, long start, long end) {
        try {
            return redisTemplate.opsForList().range(key, start, end);
        } catch (Exception e) {
            log.error("get list error",e);
            return null;
        }
    }

    /**
     * 获取list缓存的长度
     * @author z004267r
     * @param key  key
     * @return long
     * @date 3/28/2020 11:11 PM
     */
    public long lgetListSize(String key) {
        try {
            return redisTemplate.opsForList().size(key);
        } catch (Exception e) {
            log.error("get list size error",e);
            return 0;
        }
    }

    /**
     * 通过索引 获取list中的值
     * @author z004267r
     * @param key  key
     * @param index  index
     * @return java.lang.Object
     * @date 3/28/2020 11:11 PM
     */
    public Object lgetIndex(String key, long index) {
        try {
            return redisTemplate.opsForList().index(key, index);
        } catch (Exception e) {
            log.error("get list error",e);
            return null;
        }
    }

    /**
     * 将list放入缓存
     * @author z004267r
     * @param key  key
     * @param value  value
     * @return boolean
     * @date 3/28/2020 11:12 PM
     */
    public boolean lset(String key, Object value) {
        try {
            redisTemplate.opsForList().rightPush(key, value);
            return true;
        } catch (Exception e) {
            log.error("set list error",e);
            return false;
        }
    }

    /**
     * 将list放入缓存
     * @author z004267r
     * @param key  key
     * @param value  value
     * @param time  time
     * @return boolean
     * @date 3/28/2020 11:12 PM
     */
    public boolean lset(String key, Object value, long time) {
        try {
            redisTemplate.opsForList().rightPush(key, value);
            if (time > 0) {
                expire(key, time);
            }
            return true;
        } catch (Exception e) {
            log.error("set list error",e);
            return false;
        }
    }

    /**
     * 将list放入缓存
     * @author z004267r
     * @param key  key
     * @param value  value
     * @return boolean
     * @date 3/28/2020 11:12 PM
     */
    public boolean lset(String key, List<Object> value) {
        try {
            redisTemplate.opsForList().rightPushAll(key, value);
            return true;
        } catch (Exception e) {
            log.error("set list error",e);
            return false;
        }
    }

    /**
     * 将list放入缓存
     * @author z004267r
     * @param key  key
     * @param value  value
     * @param time  time
     * @return boolean
     * @date 3/28/2020 11:13 PM
     */
    public boolean lset(String key, List<Object> value, long time) {
        try {
            redisTemplate.opsForList().rightPushAll(key, value);
            if (time > 0) {
                expire(key, time);
            }
            return true;
        } catch (Exception e) {
            log.error("set list error",e);
            return false;
        }
    }

    /**
     * 根据索引修改list中的某条数据
     * @author z004267r
     * @param key  key
     * @param index  index
     * @param value  value
     * @return boolean
     * @date 3/28/2020 11:13 PM
     */
    public boolean lupdateIndex(String key, long index, Object value) {
        try {
            redisTemplate.opsForList().set(key, index, value);
            return true;
        } catch (Exception e) {
            log.error("set list error",e);
            return false;
        }
    }

    /**
     * 移除N个值为value
     * @author z004267r
     * @param key  key
     * @param count  count
     * @param value  value
     * @return long
     * @date 3/28/2020 11:14 PM
     */
    public long ldel(String key, long count, Object value) {
        try {
            Long remove = redisTemplate.opsForList().remove(key, count, value);
            return remove;
        } catch (Exception e) {
            log.error("remove list error",e);
            return 0;
        }
    }

}
