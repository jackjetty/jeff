package com.siemens.csde.simicas.common.util;

import com.google.gson.Gson;
import com.google.gson.annotations.SerializedName;
import com.siemens.csde.simicas.common.constant.CommonConstant;
import com.siemens.csde.simicas.common.model.UserBean;
import java.util.Date;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.StringUtils;
import org.springframework.security.jwt.Jwt;
import org.springframework.security.jwt.JwtHelper;


public class JwtUtil {

    /**
     * 获取用户名
     * @param token
     * @return
     */
    public static String getUserId(String token){
        if (token.startsWith(CommonConstant.TOKEN_SPLIT)) {
            token = StringUtils.removeStart(token, CommonConstant.TOKEN_SPLIT).trim();
        }
        Jwt verifiedJwt = JwtHelper.decode(token);
        JwtClaimsTo claims = new Gson().fromJson(verifiedJwt.getClaims(), JwtClaimsTo.class);
        return claims.getUserId();

    }

    /**
     * 获取用户角色
     * @param token
     * @return
     */
    public static List<String> getUserRoles(String token){
        if (token.startsWith(CommonConstant.TOKEN_SPLIT)) {
            token = StringUtils.removeStart(token, CommonConstant.TOKEN_SPLIT).trim();
        }
        Jwt verifiedJwt = JwtHelper.decode(token);
        JwtClaimsTo claims = new Gson().fromJson(verifiedJwt.getClaims(), JwtClaimsTo.class);
        return claims.getScopes();

    }

    /**
     * 是否过期
     * @param token
     * @return
     */
    public static boolean isExpiration(String token){

        if (token.startsWith(CommonConstant.TOKEN_SPLIT)) {
            token = StringUtils.removeStart(token, CommonConstant.TOKEN_SPLIT).trim();
        }
        Jwt verifiedJwt = JwtHelper.decode(token);
        JwtClaimsTo claims = new Gson().fromJson(verifiedJwt.getClaims(), JwtClaimsTo.class);
        return claims.getExpiredTime() >= new Date().getTime()/1000;
    }

    public static String getClientId(String token){
        if (token.startsWith(CommonConstant.TOKEN_SPLIT)) {
            token = StringUtils.removeStart(token, CommonConstant.TOKEN_SPLIT).trim();
        }
        Jwt verifiedJwt = JwtHelper.decode(token);
        JwtClaimsTo claims = new Gson().fromJson(verifiedJwt.getClaims(), JwtClaimsTo.class);
        return claims.getClientId();
    }

    public static UserBean getUser(String token){
        if (token.startsWith(CommonConstant.TOKEN_SPLIT)) {
            token = StringUtils.removeStart(token, CommonConstant.TOKEN_SPLIT).trim();
        }
        Jwt verifiedJwt = JwtHelper.decode(token);
        JwtClaimsTo claims = new Gson().fromJson(verifiedJwt.getClaims(), JwtClaimsTo.class);
        UserBean userBean = UserBean.builder()
                .userId(claims.getUserId())
                .userName(claims.getUserName())
                .email(claims.getEmail())
                .tenant(claims.getTenant())
                .subTenant(claims.getSubTenant())
                .scopes(claims.getScopes())
                .build();
        return userBean;
    }


    @Getter
    @Setter
    class JwtClaimsTo{

        @SerializedName(value = "jti")
        private String id;

        @SerializedName(value = "user_id")
        private String userId;

        @SerializedName(value = "user_name", alternate = {"sub"})
        private String userName;

        @SerializedName(value = "email")
        private String email;

        @SerializedName(value = "client_id")
        private String clientId;

        @SerializedName(value = "iat")
        private long issTime;

        @SerializedName(value = "exp")
        private long expiredTime;

        @SerializedName(value = "iss")
        private String issuer;

        private String zid;

        @SerializedName(value = "ten")
        private String tenant;

        @SerializedName(value = "subtenant")
        private String subTenant;

        @SerializedName(value = "cat")
        private String tokenCategory;

        @SerializedName(value = "scope")
        private List<String> scopes;

        @SerializedName(value = "aud")
        private List<String> audience;

        private List<String> schemas;
    }

}
