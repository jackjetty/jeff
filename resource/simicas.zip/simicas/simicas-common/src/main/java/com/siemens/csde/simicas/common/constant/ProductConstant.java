package com.siemens.csde.simicas.common.constant;

public interface ProductConstant {

    String NAME_UNKNOWN="Unknown";


}