package com.siemens.csde.simicas.common.config.rabbitmq;

import java.util.Properties;
import org.springframework.amqp.core.Binding;
import org.springframework.amqp.core.BindingBuilder;
import org.springframework.amqp.core.DirectExchange;
import org.springframework.amqp.core.ExchangeBuilder;
import org.springframework.amqp.core.Queue;
import org.springframework.amqp.core.QueueBuilder;
import org.springframework.beans.factory.config.YamlPropertiesFactoryBean;
import org.springframework.beans.factory.support.BeanDefinitionBuilder;
import org.springframework.beans.factory.support.BeanDefinitionRegistry;
import org.springframework.context.ApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

/**
 * RabbitMQConfigHelper 动态创建交换机、队列，并绑定
 *
 * @author z004267r
 * @version 1.0-SNAPSHOT
 * @date 3/3/2020 9:36 AM
 **/
public class RabbitMQConfigHelper {

    /**
     * 声明交换机
     * @author z004267r
     * @return void
     * @date 3/3/2020 9:26 AM
     */
    public static void declareExchange(BeanDefinitionRegistry beanDefinitionRegistry, String exchange) {
        beanDefinitionRegistry.registerBeanDefinition(exchange, BeanDefinitionBuilder.genericBeanDefinition(
                DirectExchange.class, () -> ExchangeBuilder
                        .directExchange(exchange)
                        .durable(true)
                        .build()).getBeanDefinition());
    }

    /**
     * 声明队列和绑定
     * @return void
     * @author z004267r
     * @date 3/3/2020 9:28 AM
     */
    public static void declareQueueAndBinding(BeanDefinitionRegistry beanDefinitionRegistry, ApplicationContext applicationContext, String exchange,
            String queue, String routeKey, String configKey) {
        String bindingSuffix = "Binding";
        int instances = Integer.parseInt(getCommonYml(configKey).toString());
        for (int i = 0; i < instances; i++) {
            //注册所有队列
            String queueName = queue + i;
            beanDefinitionRegistry.registerBeanDefinition(queueName, BeanDefinitionBuilder.genericBeanDefinition(
                    Queue.class, () -> QueueBuilder
                            .durable(queueName)
                            .build()).getBeanDefinition());

            //注册队列与交换机的绑定
            String routeKeyName = routeKey + i;
            beanDefinitionRegistry.registerBeanDefinition(queueName + bindingSuffix, BeanDefinitionBuilder.genericBeanDefinition(
                    Binding.class, () -> BindingBuilder
                            .bind(applicationContext.getBean(queueName, Queue.class))
                            .to(applicationContext.getBean(exchange, DirectExchange.class))
                            .with(routeKeyName)).getBeanDefinition());
        }
    }

    /**
     * 获取配置文件内容
     * @param key key
     * @return java.lang.Object
     * @author z004267r
     * @date 3/3/2020 9:28 AM
     */
    public static Object getCommonYml(String key) {
        String configFile = "application.yml";
        Resource resource = new ClassPathResource(configFile);
        Properties properties = null;
        try {
            YamlPropertiesFactoryBean yamlFactory = new YamlPropertiesFactoryBean();
            yamlFactory.setResources(resource);
            properties = yamlFactory.getObject();
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }

        return properties.get(key);
    }

}
