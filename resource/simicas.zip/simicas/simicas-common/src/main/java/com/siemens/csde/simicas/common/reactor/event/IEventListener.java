package com.siemens.csde.simicas.common.reactor.event;

/**
 * IEventListener 事件监听器接口
 *
 * @author z004267r
 * @version 1.0-SNAPSHOT
 * @date 8/23/2019 3:12 PM
 **/
public interface IEventListener {

    /**
     * 注册事件类型
     *
     * @param eventType eventType
     * @return void
     * @author z004267r
     * @date 8/23/2019 3:12 PM
     */
    void register(EventType eventType);

    /**
     * 是否含有事件类型
     *
     * @param eventType eventType
     * @return boolean
     * @author z004267r
     * @date 8/23/2019 3:12 PM
     */
    boolean containEventType(EventType eventType);

    /**
     * 执行事件
     *
     * @param event event
     * @return com.siemens.csde.simicas.common.reactor.event.EventResult
     * @author z004267r
     * @date 8/23/2019 3:13 PM
     */
    EventResult fireEvent(IEvent event);
}
