package com.siemens.csde.simicas.common.base;

import java.io.Serializable;

public class BaseQo implements Serializable {

    private static final long serialVersionUID = 4748258058044894498L;

}
