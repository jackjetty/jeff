package com.siemens.csde.simicas.common.model;

import java.io.Serializable;
import java.util.List;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;


@Getter
@Setter
@Builder
public class UserBean implements Serializable {

    private static final long serialVersionUID = -7111844897655791965L;
    private String userId;
    private String userName;
    private String email;
    private String tenant;
    private String subTenant;
    private List<String> scopes;

}
