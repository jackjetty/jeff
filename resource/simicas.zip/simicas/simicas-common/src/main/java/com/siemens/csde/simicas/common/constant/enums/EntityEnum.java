package com.siemens.csde.simicas.common.constant.enums;

/**
 * EntityEnum 实体枚举
 *
 * @author z004267r
 * @version 1.0-SNAPSHOT
 * @date 8/23/2019 2:44 PM
 **/
public enum EntityEnum {

    LINE("LINE"),
    STATION("STATION");

    private String entityType;

    EntityEnum( String entityType){
        this.entityType=entityType;
    }

    public String getEntityType() {
        return entityType;
    }

    public static EntityEnum getByType(String entityType){
        return EntityEnum.valueOf(entityType);
    }
}