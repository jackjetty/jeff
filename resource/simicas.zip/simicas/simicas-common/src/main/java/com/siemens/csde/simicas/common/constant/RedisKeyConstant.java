package com.siemens.csde.simicas.common.constant;

public interface RedisKeyConstant {

    String SHARDING_TABLES = "simicas:common:sharding-tables";

    String SHARDING_COLUMNS = "simicas:common:sharding-column";


    String SIMICAS_COLLECTION_INSTANCE_INDEX="simicas:collection:instance_index";

    String SIMICAS_HANDLE_INSTANCE_INDEX="simicas:handle:instance_index";


}
