package com.siemens.csde.simicas.common.model;


import lombok.Getter;
import lombok.Setter;


@Setter
@Getter
public class TableBean {

    @Getter
    private String tableName;

    @Getter
    private String columnName;

    @Getter
    private int orderIndex;

    private int isNullable;

    @Getter
    private String columnType;

    @Getter
    private String columnLength;

    private int isKey;

    public boolean isNullable(){
        return isNullable == 1;
    }

    public boolean isKey(){
        return isKey == 1;
    }





}
