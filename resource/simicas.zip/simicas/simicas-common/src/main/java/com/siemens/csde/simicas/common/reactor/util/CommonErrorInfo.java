package com.siemens.csde.simicas.common.reactor.util;

/**
 * CommonErrorInfo 线程池处理异常常量
 *
 * @author z004267r
 * @version 1.0-SNAPSHOT
 * @date 8/23/2019 3:21 PM
 **/
public class CommonErrorInfo {

    /**
     * 线程被中断
     */
    public static final String THRAD_ERR_INTERRUPTED = "THR.ERR.INTRRUPTED";

    /**
     * 消息处理时发生未知的异常
     */
    public static final String EVENT_PRO_ERROR = "EVENT.PRO.ERR";

    /**
     * 任务处理结果时发生未知的异常
     */
    public static final String EVENT_RESULT_PRO_ERROR = "EVENT.RESULT.PRO.ERR";

    /**
     * 消息处理时收到空的消息
     */
    public static final String EVENT_PRO_NULL_MSG = "EVENT.PRO.ERR.NULL.MSG";
}
