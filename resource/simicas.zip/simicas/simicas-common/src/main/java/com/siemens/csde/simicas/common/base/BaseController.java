package com.siemens.csde.simicas.common.base;

import com.siemens.csde.simicas.common.constant.enums.ResultEnum;

public class BaseController {


    protected BaseResult renderResult(){

        return new BaseResult(true,ResultEnum.SUCCESS);
    }

    protected  <T> BaseResult<T> renderResult4Vo(T data){

        return new BaseResult<>(data, ResultEnum.SUCCESS);

    }

}
