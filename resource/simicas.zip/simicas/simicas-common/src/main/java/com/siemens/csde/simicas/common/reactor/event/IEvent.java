package com.siemens.csde.simicas.common.reactor.event;

/**
 * IEvent 事件接口
 *
 * @author z004267r
 * @version 1.0-SNAPSHOT
 * @date 8/23/2019 3:07 PM
 **/
public interface IEvent {

    /**
     * 设置事件类型
     *
     * @param eventType eventType
     * @return void
     * @author z004267r
     * @date 8/23/2019 3:08 PM
     */
    void setEventType(EventType eventType);

    /**
     * 获取事件类型
     *
     * @return com.siemens.csde.simicas.common.reactor.event.EventType
     * @author z004267r
     * @date 8/23/2019 3:08 PM
     */
    EventType getEventType();

    /**
     * 设置事件参数
     *
     * @param eventParam eventParam
     * @return void
     * @author z004267r
     * @date 8/23/2019 3:08 PM
     */
    void setParam(EventParam eventParam);

    /**
     * 获取事件参数
     *
     * @return com.siemens.csde.simicas.common.reactor.event.EventParam
     * @author z004267r
     * @date 8/23/2019 3:08 PM
     */
    EventParam getParam();

    /**
     * 事件执行
     *
     * @return com.siemens.csde.simicas.common.reactor.event.EventResult
     * @author z004267r
     * @date 8/23/2019 3:08 PM
     */
    EventResult call();
}
