package com.siemens.csde.simicas.common.reactor.event.impl.event;

import com.siemens.csde.simicas.common.reactor.event.EventParam;
import com.siemens.csde.simicas.common.reactor.event.EventResult;
import com.siemens.csde.simicas.common.reactor.event.EventType;
import com.siemens.csde.simicas.common.reactor.event.impl.AbstractEvent;
import java.io.Serializable;

/**
 * SingleEvent 单次循环的事件
 *
 * @author z004267r
 * @version 1.0-SNAPSHOT
 * @date 8/23/2019 2:58 PM
 **/
@SuppressWarnings("unused")
public class SingleEvent<ID extends Serializable> extends AbstractEvent<ID> {

    //用于线程分片的shardingId
    private String shardingId;

    public SingleEvent(EventType eventType, ID eventId, String shardingId, EventParam param) {
        super(eventType, eventId, param);
        this.shardingId = shardingId;
    }

    public String getShardingId() {
        return shardingId;
    }

    public void setShardingId(String shardingId) {
        this.shardingId = shardingId;
    }

    @Override
    public EventResult call() {
        return null;
    }
}
