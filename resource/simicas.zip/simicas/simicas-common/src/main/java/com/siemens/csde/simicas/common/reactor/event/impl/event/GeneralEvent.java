package com.siemens.csde.simicas.common.reactor.event.impl.event;

import com.siemens.csde.simicas.common.reactor.event.EventParam;
import com.siemens.csde.simicas.common.reactor.event.EventResult;
import com.siemens.csde.simicas.common.reactor.event.EventType;
import com.siemens.csde.simicas.common.reactor.event.impl.AbstractEvent;
import java.io.Serializable;
import lombok.extern.slf4j.Slf4j;

/**
 * GeneralEvent 通用事件
 *
 * @author z004267r
 * @version 1.0-SNAPSHOT
 * @date 8/23/2019 2:57 PM
 **/
@SuppressWarnings("unused")
@Slf4j
public class GeneralEvent<ID extends Serializable> extends AbstractEvent {

    public GeneralEvent(EventType eventType, ID eventId, EventParam param) {
        super(eventType, eventId, param);
    }

    public EventResult call() {
        EventParam<Float> eventParam = getParam();
        log.info("update event " + eventParam.getT() + "float" + eventParam.getT());

        EventResult<Long> result = new EventResult<>(1L);
        return result;
    }
}
