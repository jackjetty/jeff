package com.siemens.csde.simicas.common.component;

import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component("concurrentRabbitTemplate")
@Slf4j
public class ConcurrentRabbitTemplate{

    @Autowired
    private RabbitTemplate rabbitTemplate;

    public void convertAndSend(String exchange, String routingKey, final Object object) {

        synchronized (rabbitTemplate){
            rabbitTemplate.convertAndSend(exchange, routingKey, object);
        }

    }

}
