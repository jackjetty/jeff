package com.siemens.csde.simicas.common.model;

import com.siemens.csde.simicas.common.constant.RabbitConstant;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

/**
 * AppBean
 *
 * @author z004267r
 * @version 1.0-SNAPSHOT
 * @date 3/5/2020 5:10 PM
 **/
@Getter
@Setter
@Builder
public class AppBean {

    private String appName;
    private int instanceIndex;
    private boolean initOK;
    private int appInstances;
    private String collectionQueueName;
    private String handleQueueName;

    public String getCollectionQueueName(){
        return RabbitConstant.QUEUE_SIMICAS_COLLECTION_GROUP+this.getInstanceIndex();
    }

    public String getHandleQueueName(){
        return RabbitConstant.QUEUE_SIMICAS_HANDLE_GROUP+this.getInstanceIndex();
    }

}
