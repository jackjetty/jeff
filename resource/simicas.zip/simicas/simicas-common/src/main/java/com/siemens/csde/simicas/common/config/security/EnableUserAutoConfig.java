package com.siemens.csde.simicas.common.config.security;

import com.siemens.csde.simicas.common.filter.UserFilter;
import com.siemens.csde.simicas.common.interceptor.UserFeignClientInterceptor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class EnableUserAutoConfig {

    /*public EnableUserAutoConfig() {
    }*/

    @Autowired
    UserFeignClientInterceptor userFeignClientInterceptor;

    @Bean
    public UserFeignClientInterceptor transmitUserInfo2FeignHttpHeader(){
        return userFeignClientInterceptor;
    }

    @Bean
    public UserFilter transmitUserInfoFromHttpHeader(){
        return new UserFilter() ;
    }

}
