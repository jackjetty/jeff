package com.siemens.csde.simicas.common.util;

import static java.util.regex.Pattern.compile;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.apache.commons.lang3.StringUtils;

/**
 * RegexUtil 正则表达式工具
 *
 * @author z0043y5h
 * @version 1.0
 * @date 2020/2/11 17:12
 */
public class RegexUtil {

    /*
     * 匹配订阅URL地址
     * @param path path
     * @param pathPattern pathPattern
     * @return boolean
     * @author z0043y5h
     * @date 2020/2/11 17:41
     **/
    public static boolean isMatch(String path, String pathPattern) {
        String pathRegex = StringUtils.replacePattern(pathPattern, "\\{[^/]+?\\}", "[^/]+?") + "\\?*.*";
        Pattern pattern = compile(pathRegex);
        Matcher matcher = pattern.matcher(path);
        boolean isMatched = matcher.matches();
        return isMatched;
    }

    /**
     * 匹配订阅指标
     * @param path path
     * @param pathPattern pathPattern
     * @return java.util.Map<java.lang.String,java.lang.String>
     * @author z0043y5h
     * @date 2020/2/11 17:40
     **/
    public static Map<String, String> getPathVariableMap(String path, String pathPattern) {
        Map<String, String> pathVariableMap = new HashMap<>();
        path = StringUtils.substringBefore(path, "?");
        List<String> pathList = Arrays.asList(StringUtils.split(path, "/"));
        List<String> patternList = Arrays.asList(StringUtils.split(pathPattern, "/"));
        for (int i = 0; i < patternList.size(); i++) {
            String patternStr = patternList.get(i);
            if (patternStr.contains("{")) {
                String patternMarker = StringUtils.removeAll(patternStr, "\\{|\\}");
                pathVariableMap.put(patternMarker, pathList.get(i));
            }
        }
        return pathVariableMap;
    }
}
