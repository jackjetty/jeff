package com.siemens.csde.simicas.common.util;

import com.alibaba.ttl.TransmittableThreadLocal;
import com.siemens.csde.simicas.common.model.UserBean;

/**
 * 本地线程工具类
 *
 * @author z004267r
 * @version 1.0-SNAPSHOT
 * @date 2020/2/14 16:17
 **/
public class ThreadLocalUtil {

    public final static ThreadLocal<UserBean> userBean = new TransmittableThreadLocal<>();

    public static String KEY_USER_IN_HTTP_HEADER = "X-AUTO-FP-USER";


    public static UserBean getUser() {
        return userBean.get();
    }

    public static void setUser(UserBean user) {
        userBean.set(user);
    }
}
