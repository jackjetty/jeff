package com.siemens.csde.simicas.common.constant.enums;

/**
 * PageTypeEnum 枚举类
 *
 * @author z0043y5h
 * @version 1.0-SNAPSHOT
 * @date 2020/3/27 10:22
 **/
public enum PageTypeEnum {
    Performance(0),
    Maintenance(1),
    Quality(2),
    Compare(3);

    private int value;

    public int value() {
        return value;
    }

    PageTypeEnum(int value) {
        this.value = value;
    }

    /**
     * 根据枚举值获取类型枚举
     *
     * @param value value
     * @return com.siemens.csde.macb.common.enums.PageTypeEnum
     * @author z004267r
     * @date 8/23/2019 2:47 PM
     */
    public static PageTypeEnum fromValue(Integer value) {
        PageTypeEnum pageTypeEnum = null;

        if (null != value && value >= 0 && value < PageTypeEnum.values().length) {
            pageTypeEnum = PageTypeEnum.values()[value];
        }
        return pageTypeEnum;
    }
}
