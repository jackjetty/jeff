package com.siemens.csde.simicas.common.reactor.event.enums;


/**
 * EventTypeEnum 事件类型枚举
 *
 * @author z004267r
 * @version 1.0-SNAPSHOT
 * @date 8/23/2019 2:56 PM
 **/
public enum EventTypeEnum {

    INGEST,
    ADMIN_AlARM,
    ADMIN_LINE,
    ADMIN_TENANT,
    ADMIN_OVERALL,
    ADMIN,
    CONSUMENR,
    SINGLERUN,
    WS,

    HUB,
    HANDLE;

}
