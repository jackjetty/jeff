package com.siemens.csde.simicas.common.reactor.event.constant;


import com.siemens.csde.simicas.common.reactor.event.EventType;
import com.siemens.csde.simicas.common.reactor.event.enums.EventTypeEnum;

/**
 * Constants 事件类型常量
 *
 * @author z004267r
 * @version 1.0-SNAPSHOT
 * @date 8/23/2019 2:54 PM
 **/
public class Constants {


    /**
     * EventTypeConstans 事件类型常量
     *
     * @author z004267r
     * @version 1.0-SNAPSHOT
     * @date 8/23/2019 2:54 PM
     **/
    public static class EventTypeConstans {

        public static EventType ingestEventType = new EventType(EventTypeEnum.INGEST.ordinal());
        public static EventType adminEventType = new EventType(EventTypeEnum.ADMIN.ordinal());
        public static EventType consumerEventType = new EventType(EventTypeEnum.CONSUMENR.ordinal());
        public static EventType singleRunEventType = new EventType(EventTypeEnum.SINGLERUN.ordinal());
        public static EventType wsEventType = new EventType(EventTypeEnum.WS.ordinal());

        public static EventType hubEventType = new EventType(EventTypeEnum.HUB.ordinal());
        public static EventType handleEventType = new EventType(EventTypeEnum.HANDLE.ordinal());

    }

}
