package com.siemens.csde.simicas.common.model;

import java.util.List;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AspectSchemaBean {

    private String name;
    private String holderAssetId;
    private String aspectTypeId;
    private String aspectTypeName;
    private String category;
    private String description;
    private List<VariableSchemaBean> variables;

    @Getter
    @Setter
    public static class VariableSchemaBean {

        private String name;
        private String dataType;
        private String unit;
        private boolean searchable;
        private Integer length;
        private boolean qualityCode;
        private Object defaultValue;
    }
}