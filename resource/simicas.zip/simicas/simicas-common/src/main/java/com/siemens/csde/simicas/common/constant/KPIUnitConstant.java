package com.siemens.csde.simicas.common.constant;


import com.google.common.collect.Maps;
import java.util.Map;

/**
 * KPIUnitConstant  kpi常量
 *
 * @author z004267r
 * @version 1.0-SNAPSHOT
 * @date 8/23/2019 2:29 PM
 **/
public class KPIUnitConstant {

    //FPY指标
    public static final String KPI_FPY = "FPY";

    //STATUS指标
    public static final String KPI_STATUS = "STATUS";

    //STOPCODE指标
    public static final String KPI_STOPCODE = "STOPCODE";

    //RACT指标
    public static final String KPI_RACT = "RACT";

    //WIP指标
    public static final String KPI_WIP = "WIP";

    //EFF指标
    public static final String KPI_EFF = "EFF";

    //OUTPUT指标
    public static final String KPI_OUTPUT = "OUTPUT";

    //TIMEUSAGE指标
    public static final String KPI_TIMEUSAGE = "TIMEUSAGE";

    //ALARM指标
    public static final String KPI_ALARM = "ALARM";

    //MTBF指标
	public static final String KPI_MTBF="MTBF";

	//kpi of NGReason
	public static final String KPI_NGREASON="NGREASON";

    public static final String KPI_DEFECT = "DEFECT";

    public static final String KPI_RUNTIME = "RUNTIME";

    public static final String KPI_DOWNTIME= "DOWNTIME";

    protected static Map<String, String> KPIUNIT_MAP;

    /**
     * 获取指标单位
     *
     * @param kpiName kpiName
     * @return java.lang.String
     * @author z004267r
     * @date 8/23/2019 2:31 PM
     */
    public static String getKPIUnit(String kpiName) {
        return KPIUNIT_MAP.get(kpiName);
    }

    static {
        KPIUNIT_MAP = Maps.newHashMap();
        KPIUNIT_MAP.put(KPI_FPY, "%");
        KPIUNIT_MAP.put(KPI_STATUS, "");
        KPIUNIT_MAP.put(KPI_STOPCODE, "");
        KPIUNIT_MAP.put(KPI_RACT, "");
        KPIUNIT_MAP.put(KPI_WIP, "one");
        KPIUNIT_MAP.put(KPI_EFF, "%");
        KPIUNIT_MAP.put(KPI_OUTPUT, "one");
        KPIUNIT_MAP.put(KPI_TIMEUSAGE, "");
        KPIUNIT_MAP.put(KPI_ALARM, "");
        KPIUNIT_MAP.put(KPI_MTBF, "");
        KPIUNIT_MAP.put(KPI_NGREASON, "");
        KPIUNIT_MAP.put(KPI_DEFECT, "one");
        KPIUNIT_MAP.put(KPI_RUNTIME, "ms");
        KPIUNIT_MAP.put(KPI_DOWNTIME, "ms");
    }

}
