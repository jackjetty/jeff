package com.siemens.csde.simicas.common.constant.enums;

/**
 * SubTypeEnum 订阅类型枚举
 *
 * @author z004267r
 * @version 1.0-SNAPSHOT
 * @date 8/23/2019 2:47 PM
 **/
public enum SubTypeEnum {
    ALARM,
    LINE,
    NOTICE,
    OVERALL,
    STATION,
    PING
}
