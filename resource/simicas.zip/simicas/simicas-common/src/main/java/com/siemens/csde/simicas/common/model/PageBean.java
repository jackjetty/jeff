package com.siemens.csde.simicas.common.model;


import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PageBean {

    public static final int DEFAULT_SIZE = 200;
    public static final int DEFAULT_INDEX = 0;
    private static final long serialVersionUID = 6541733885074112200L;
    private int size;
    private int totalElements;
    private int totalPages = 1;
    private int index;

    public PageBean() {

    }

    public PageBean(int index, int size, Long totalElements) {
        this(index, size, totalElements.intValue());
    }


    public PageBean(int index, int size, int totalElements) {
        this();
        setSize(size);
        setTotalElements(totalElements);
        setIndex(index);
        adjustPageNo();
    }

    public void adjustPageNo() {
        if (index == 0) {
            return;
        }
        int totalPage = getTotalPages();
        if (index > totalPage) {
            index = totalPage;
        }
    }

    public int getSize() {
        return size;
    }

    public void setSize(Integer pageSize) {
        if (pageSize == null || pageSize < 1) {
            this.size = DEFAULT_SIZE;
        } else {
            this.size = pageSize;
        }
    }

    public int getTotalElements() {
        return totalElements;
    }

    public void setTotalElements(int totalElements) {

        //设置总条数
        if (totalElements < 0) {
            this.totalElements = 0;
        } else {
            this.totalElements = totalElements;
        }

        //设置总页数
        int totalPage = totalElements / size;
        if (totalPage == 0 || totalElements % size != 0) {
            totalPage++;
        }
        this.totalPages = totalPage;
    }

    public int getTotalPages() {
        return totalPages;
    }

    public void setTotalPages(int totalPages) {
        this.totalPages = totalPages;
    }

    public int getIndex() {
        return index;
    }

    public void setIndex(int index) {
        this.index = index;
    }

}
