package com.siemens.csde.simicas.common.constant;

public interface AspectConstant {

    String ASPECT_DELIMETER = "_";

}