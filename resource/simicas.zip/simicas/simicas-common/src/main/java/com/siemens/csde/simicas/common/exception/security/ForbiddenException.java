package com.siemens.csde.simicas.common.exception.security;

import org.springframework.http.HttpStatus;


public class ForbiddenException extends Auth2Exception {

	public ForbiddenException(String msg, Throwable t) {
		super(msg);
	}

	@Override
	public String getOAuth2ErrorCode() {
		return HttpStatus.FORBIDDEN.getReasonPhrase();
	}

	@Override
	public int getHttpErrorCode() {
		return HttpStatus.FORBIDDEN.value();
	}

}

