package com.siemens.csde.simicas.common.exception;

import lombok.extern.slf4j.Slf4j;

/**
 * NotFoundException
 *
 * @author z004267r
 * @version 1.0-SNAPSHOT
 * @date 8/23/2019 2:52 PM
 **/
@Slf4j
public class NotFoundException extends BaseException {

    private static final long serialVersionUID = -7326356720224588982L;

    public NotFoundException(String message) {
        super(message);
    }
}
