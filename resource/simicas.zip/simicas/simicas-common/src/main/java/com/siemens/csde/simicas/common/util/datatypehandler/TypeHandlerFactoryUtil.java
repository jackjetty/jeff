package com.siemens.csde.simicas.common.util.datatypehandler;

import java.sql.ResultSet;
import java.util.Date;

public class TypeHandlerFactoryUtil {

    /**
     * 工厂模式，通过传入的class判断实例化哪个TypeHandler的实现类
     * 实现对TypeHandler实现类和调用者之间的解耦
     *
     * @param cls 判定对象
     * @return TypeHandler
     */
    public static TypeHandler creatTypeHandler(Class cls) {

        if (cls.isPrimitive() || cls == String.class || Number.class.isAssignableFrom(cls) || cls == Boolean.class) {
            return new PrimitiveHandler();//基本数据类型及其包装类以及String类处理器
        } else if (cls.getSimpleName().equals("Date") || Date.class.isAssignableFrom(cls)) {
            return new DateHandler();//java.sql.Date与java.util.Date处理器,字符串转Date
        } else if (ResultSet.class.isAssignableFrom(cls)) {
            return new ResultSetHandler();//ResultSet结果集处理器,一行结果封装成相应对象
        }
        return null;
    }

}
