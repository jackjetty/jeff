package com.siemens.csde.simicas.common.constant;

public interface KpiConstant {

    String PID_ROOT = "0";

    Integer LEVEL_NATIVE=1;

    String UNIT_UNKNOWN="Unknown";

    Integer KPI_TYPE_DEFAULT = 0;

    Integer KPI_TYPE_CUSTOM = 1;



}