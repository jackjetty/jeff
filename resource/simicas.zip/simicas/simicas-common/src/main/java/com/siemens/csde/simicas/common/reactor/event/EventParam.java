package com.siemens.csde.simicas.common.reactor.event;

/**
 * EventParam 事件参数
 *
 * @author z004267r
 * @version 1.0-SNAPSHOT
 * @date 8/23/2019 3:06 PM
 **/
public class EventParam<T> {

    private T t;

    public EventParam(T t) {
        this.t = t;
    }

    public T getT() {
        return t;
    }

    public void setT(T t) {
        this.t = t;
    }
}
