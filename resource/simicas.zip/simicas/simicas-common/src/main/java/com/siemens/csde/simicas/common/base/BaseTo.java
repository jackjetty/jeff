package com.siemens.csde.simicas.common.base;

import java.io.Serializable;

public class BaseTo implements Serializable {

    private static final long serialVersionUID = 8225634562813528754L;

}
