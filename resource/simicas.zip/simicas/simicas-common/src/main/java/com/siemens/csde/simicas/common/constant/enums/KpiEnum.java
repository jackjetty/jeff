package com.siemens.csde.simicas.common.constant.enums;

import java.util.stream.Stream;
import org.apache.commons.lang3.StringUtils;

/**
 * KpiEnum KPI 枚举
 *
 * @author z004267r
 * @version 1.0-SNAPSHOT
 * @date 8/23/2019 2:45 PM
 **/
public enum KpiEnum {

    EFF("EFF"),
    FPY("FPY"),
    OUTPUT("OUTPUT"),
    RACT("RACT"),
    STATUS("STATUS"),
    STOPCODE("STOPCODE"),
    ALARM("ALARM"),
    NOTICE("NOTICE"),
    TIMEUSAGE("TIMEUSAGE"),
    FINISHRATE("FINISHRATE"),
    DEFECT_PIECES("DEFECTPIECES"),
    DEFECT("DEFECT"),
    WIP("WIP"),
    RUNTIME("RUNTIME"),
    DOWNTIME("DOWNTIME"),
    //kpi of NGReason
    NGREASON("NGREASON"),
    PING("PING");

    private String value;

    public String value() {
        return value;
    }

    KpiEnum(String value) {
        this.value = value;
    }

    /**
     * 根据枚举名称获取对应枚举类
     *
     * @param messageTypeName messageTypeName
     * @return com.siemens.csde.macb.common.enums.KpiEnum
     * @author z004267r
     * @date 8/23/2019 2:45 PM
     */
    public static KpiEnum fromMessageTypeName(String messageTypeName) {
        KpiEnum kpiEnum;
        try {
            kpiEnum = KpiEnum.valueOf(messageTypeName.toUpperCase());
        } catch (IllegalArgumentException e) {
            kpiEnum = Stream.of(KpiEnum.values())
                    .filter(kpiEm -> StringUtils.equalsIgnoreCase(messageTypeName, kpiEm.name())
                            || StringUtils.equalsIgnoreCase(messageTypeName, kpiEm.value))
                    .findAny()
                    .orElse(null);
        }
        return kpiEnum;
    }

}
