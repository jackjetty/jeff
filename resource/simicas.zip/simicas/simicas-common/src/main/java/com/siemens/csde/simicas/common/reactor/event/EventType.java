package com.siemens.csde.simicas.common.reactor.event;

/**
 * EventType 事件类型
 *
 * @author z004267r
 * @version 1.0-SNAPSHOT
 * @date 8/23/2019 3:07 PM
 **/
public class EventType {

    private int index;

    public EventType(int index) {
        this.index = index;
    }

    public int getIndex() {
        return index;
    }

    public void setIndex(int index) {
        this.index = index;
    }
}
