package com.siemens.csde.simicas.common.util;

import com.siemens.csde.simicas.common.exception.BusinessException;
import java.nio.charset.Charset;
import java.security.Key;
import java.security.KeyFactory;
import java.security.PublicKey;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;
import javax.crypto.Cipher;
import org.apache.commons.lang3.StringUtils;

/**
 * 解密工具
 * @author z0042v1w
 *
 */
public class DecryptionUtil {

    private static final String PUBLIC_KEY = "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCLOS1OEczH1Fz2T4rmg7qFlbAGVN8bPznlEbqtarGtOMDYFhIbKTAbqKKNQ+owOrOGaa9GuMhhMvFBPY258GHDMseGZ95CHeoLZhancGwHNDBmj8fCfRgkuBJmtgMJVctOo8ANkZgp6gY07DwadeChD0lFt5z2AVQ5oZw3PpnhPQIDAQAB";

    public static String decrypt(String cipherText) throws BusinessException {
        if(StringUtils.isEmpty(cipherText)) {
            return "";
        }
        try {
            Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
            Key key = getPublicKey(PUBLIC_KEY);
            cipher.init(Cipher.DECRYPT_MODE, key);
            Charset UTF8 = Charset.forName("UTF-8");
            byte[] newPlainBytes = cipher.doFinal(Base64.getDecoder().decode(cipherText.getBytes(UTF8)));
            String plainText = new String(newPlainBytes,UTF8);
            return plainText;
        }catch(Exception e){
            throw new BusinessException("Decryption error",e);
        }
    }

    private static PublicKey getPublicKey(String key) throws Exception {
        byte[] keyBytes;
        keyBytes = Base64.getDecoder().decode(key);
        X509EncodedKeySpec keySpec = new X509EncodedKeySpec(keyBytes);
        KeyFactory keyFactory = KeyFactory.getInstance("RSA");
        PublicKey publicKey = keyFactory.generatePublic(keySpec);
        return publicKey;
    }

}
