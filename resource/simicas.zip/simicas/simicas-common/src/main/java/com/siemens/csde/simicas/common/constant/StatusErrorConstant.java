package com.siemens.csde.simicas.common.constant;

/**
 * StatusErrorConstant status错误常量
 *
 * @author z004267r
 * @version 1.0-SNAPSHOT
 * @date 8/23/2019 2:34 PM
 **/
public class StatusErrorConstant {

    //正常
    public static final Integer NORMAL = 0;

    //没有配置所有的status值
    public static final Integer TOTAL_UN_CONFIG = -1;

    //没有配置当前status值
    public static final Integer CURRENT_VALUE_UN_CONFIG = -2;

    //config tool没有配置status
    public static final Integer UNKNOWN_STATUS = -3;
}
