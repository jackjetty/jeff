package com.siemens.csde.simicas.common.constant;

public interface AdapterConstant {

    String ADAPTER_AXIS = "axis";

    String ADAPTER_CXF = "cxf";

    String ADAPTER_KAFKA = "kafka";

    String ADAPTER_HTTP = "https";

    String ADAPTER_MINDSPHERE = "mindsphere";

    String ADAPTER_MYSQL = "mysql";

    String ADAPTER_ORACLE = "oracle";

    String ADAPTER_RABBIT = "rabbit";

    String ADAPTER_SOCKET = "socket";

}
