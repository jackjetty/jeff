package com.siemens.csde.simicas.common.config.web;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.siemens.csde.simicas.common.config.swagger.SpringfoxJsonToGsonAdapter;
import com.siemens.csde.simicas.common.util.DateUtil;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.convert.converter.Converter;
import org.springframework.format.FormatterRegistry;
import org.springframework.http.MediaType;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.json.GsonHttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import springfox.documentation.spring.web.json.Json;

/**
 * WebConfig web 配置类]
 *
 * @author z004267r
 * @version 1.0-SNAPSHOT
 * @date 8/22/2019 4:26 PM
 **/

@Configuration
@Slf4j
public class WebMvcConfig implements WebMvcConfigurer {

    @Override
    public void addFormatters(FormatterRegistry registry) {
        Converter<String, Date> converter = new Converter<String, Date>() {
            @Override
            public Date convert(String source) {
                if (Objects.isNull(source)) {
                    return null;
                }
                String value = source.trim();
                try {
                    //return Date.from(Instant.parse(value));
                    return DateUtil.parseDate(value);
                } catch (Exception ex) {
                    log.error("date format conversion failed :{}", value);
                    return null;
                }
            }
        };
        registry.addConverter(converter);
    }

    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        registry.addResourceHandler("/**").addResourceLocations(
                "classpath:/static/");
        registry.addResourceHandler("swagger-ui.html")
                .addResourceLocations("classpath:/META-INF/resources/");
        registry.addResourceHandler("/webjars/**")
                .addResourceLocations("classpath:/META-INF/resources/webjars/");
    }

    @Override
    public void addCorsMappings(CorsRegistry registry) {
        registry.addMapping("/**")
                .allowedOrigins("*")
                .allowedMethods("*")
                .allowedHeaders("*")
                .allowedMethods("POST", "GET", "PUT", "OPTIONS", "DELETE")// 允许请求方法
                .allowCredentials(true)
                .maxAge(3600);
    }

    @Override
    public void configureMessageConverters(List<HttpMessageConverter<?>> converters) {
        boolean isExist=false;
        for (int i = 0; i < converters.size(); i++) {
            if (converters.get(i) instanceof GsonHttpMessageConverter && !isExist){
                converters.set(i, customGsonHttpMessageConverter());
                isExist=true;
            }
            if (converters.get(i) instanceof MappingJackson2HttpMessageConverter && !isExist) {
                converters.set(i, customGsonHttpMessageConverter());
                isExist=true;
            }
        }
        if(!isExist){
            converters.add(customGsonHttpMessageConverter());
        }
    }
    
    private GsonHttpMessageConverter customGsonHttpMessageConverter() {
        //对于swagger json 类型转换
        Gson gson = new GsonBuilder().registerTypeAdapter(Json.class, new SpringfoxJsonToGsonAdapter()).create();
        GsonHttpMessageConverter gsonMessageConverter = new GsonHttpMessageConverter();
        gsonMessageConverter.setGson(gson);
        gsonMessageConverter.setSupportedMediaTypes(Arrays.asList(MediaType.APPLICATION_JSON));
        return gsonMessageConverter;
    }
}