package com.siemens.csde.simicas.common.interceptor;

import com.siemens.csde.simicas.common.base.BaseResult;
import com.siemens.csde.simicas.common.exception.BusinessException;
import com.siemens.csde.simicas.common.exception.LogicException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;


@Slf4j
@ControllerAdvice
@Order(-1)
public class BusinessExceptionHandler {

    @ResponseStatus(HttpStatus.OK)
    @ExceptionHandler(value = BusinessException.class)
    @ResponseBody
    public BaseResult handleBusiness(BusinessException ex) {
        log.error("BusinessException：", ex);
        return new BaseResult(ex);
    }

    @ResponseStatus(HttpStatus.OK)
    @ExceptionHandler(value = LogicException.class)
    @ResponseBody
    public BaseResult handleLogic(LogicException ex) {
        log.error("LogicException code :{} stack :", ex.getCode(), ex);
        return new BaseResult(ex.getCode(), ex.getMessage());
    }
}
