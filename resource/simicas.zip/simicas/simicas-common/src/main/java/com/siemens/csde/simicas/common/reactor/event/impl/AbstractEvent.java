package com.siemens.csde.simicas.common.reactor.event.impl;


import com.siemens.csde.simicas.common.reactor.event.EventParam;
import com.siemens.csde.simicas.common.reactor.event.EventType;
import com.siemens.csde.simicas.common.reactor.event.IEvent;
import java.io.Serializable;

/**
 * AbstractEvent  抽象事件
 *
 * @author z004267r
 * @version 1.0-SNAPSHOT
 * @date 8/23/2019 3:00 PM
 **/
public abstract class AbstractEvent<ID extends Serializable> implements IEvent {

    private EventType eventType;
    private EventParam eventParam;
    private ID id;


    public AbstractEvent(EventType eventType, ID eventId, EventParam param) {
        setEventType(eventType);
        setParam(param);
        setId(eventId);
    }

    public void setEventType(EventType eventType) {
        this.eventType = eventType;
    }

    public EventType getEventType() {
        return this.eventType;
    }

    public EventParam getParam() {
        return this.eventParam;
    }

    public void setParam(EventParam eventParam) {
        this.eventParam = eventParam;
    }

    public ID getId() {
        return id;
    }

    public void setId(ID id) {
        this.id = id;
    }


}
