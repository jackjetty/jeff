package com.siemens.csde.simicas.common.util;

import java.security.MessageDigest;

/**
 * Md5Util MD%工具类
 *
 * @author z004267r
 * @version 1.0-SNAPSHOT
 * @date 8/23/2019 5:07 PM
 **/
public class Md5Util {

    /**
     * 生成MD5
     *
     * @param message message
     * @return java.lang.String
     * @author z004267r
     * @date 8/23/2019 5:07 PM
     */
    public static String getMD5(String message) {
        String md5 = "";
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");  // 创建一个md5算法对象
            byte[] messageByte = message.getBytes("UTF-8");
            byte[] md5Byte = md.digest(messageByte);              // 获得MD5字节数组,16*8=128位
            md5 = bytesToHex(md5Byte);                            // 转换为16进制字符串
        } catch (Exception e) {
            e.printStackTrace();
        }
        return md5;
    }

    /**
     * 二进制转十六进制
     *
     * @param bytes bytes
     * @return java.lang.String
     * @author z004267r
     * @date 8/23/2019 5:07 PM
     */
    public static String bytesToHex(byte[] bytes) {
        StringBuffer hexStr = new StringBuffer();
        int num;
        for (int i = 0; i < bytes.length; i++) {
            num = bytes[i];
            if (num < 0) {
                num += 256;
            }
            if (num < 16) {
                hexStr.append("0");
            }
            hexStr.append(Integer.toHexString(num));
        }
        return hexStr.toString().toUpperCase();
    }
}