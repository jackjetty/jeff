package com.siemens.csde.simicas.common.constant;

public interface IotTimeSeriesConstant {

    String ASPECT_DELIMETER = "_";

    String DEFAULT_STATION_NAME = "LINE"; //代表产线

    String OTHER_STATION_NAME = "STATION"; //工站

    String TIMESTAMP_KEY = "_time";

    String PRODUCT_ID = "ProductID";

    String BATCH_ID = "BatchID";

    String CHANGE_OVER = "ChangeOver";

    String ORDER_ID = "OrderID";

    String DEFAULT_ORDER_ID = "";

    String DEFAULT_PRODUCT_ID = "";

    long PERMIT_DELAY_SECONDS = 24 * 60 * 60L;




}
