package com.siemens.csde.simicas.common.converter;


import java.sql.Timestamp;
import java.time.Instant;
import org.dozer.DozerConverter;

public class TimestampToInstantConverter extends DozerConverter<Timestamp, Instant> {

    /**
     * 构造函数
     *
     * @param * @return
     * @author z004267r
     * @date 8/23/2019 2:43 PM
     */
    public TimestampToInstantConverter() {
        super(Timestamp.class, Instant.class);
    }

    @Override
    public Timestamp convertFrom(Instant source, Timestamp destination) {

        return java.sql.Timestamp.from(source);
    }

    @Override
    public Instant convertTo(Timestamp source, Instant destination) {
        return source.toInstant();
    }
}