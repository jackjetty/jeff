package com.siemens.csde.simicas.common.reactor.threadpool.executor;


import com.siemens.csde.simicas.common.reactor.threadpool.ThreadNameFactory;
import com.siemens.csde.simicas.common.reactor.threadpool.worker.AbstractWork;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/**
 * NonOrderedQueuePoolExecutor 无序执行线程池
 * @author z004267r
 * @version 1.0-SNAPSHOT
 * @date 8/23/2019 3:13 PM
 **/
public class NonOrderedQueuePoolExecutor extends ThreadPoolExecutor {
    public NonOrderedQueuePoolExecutor(int corePoolSize) {
        super(corePoolSize, corePoolSize * 2, 30L, TimeUnit.SECONDS, new LinkedBlockingQueue());
    }

    public NonOrderedQueuePoolExecutor(String name, int corePoolSize) {
        super(corePoolSize, corePoolSize * 2, 30L,
                TimeUnit.SECONDS, new LinkedBlockingQueue(), new ThreadNameFactory(name));
    }

    /**
     * 添加work
     * @author z004267r
     * @param work  work
     * @return void
     * @date 8/23/2019 3:14 PM
     */
    public void addTask(AbstractWork work) {
        this.execute(work);
    }
}