package com.siemens.csde.simicas.common.util;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.RoundingMode;
import java.util.Objects;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

/**
 * MathUtil 计算工具
 *
 * @author z004267r
 * @version 1.0-SNAPSHOT
 * @date 8/23/2019 3:48 PM
 **/
@Slf4j
public class MathUtil {

    /**
     * BigDecimal 相加
     *
     * @param bigDecimal1 bigDecimal1
     * @param bigDecimal2 bigDecimal2
     * @return java.math.BigDecimal
     * @author z004267r
     * @date 8/23/2019 3:48 PM
     */
    public static BigDecimal addBigDecimal(BigDecimal bigDecimal1, BigDecimal bigDecimal2) {
        if (Objects.isNull(bigDecimal1) && Objects.isNull(bigDecimal2)) {
            return null;
        }
        if (Objects.nonNull(bigDecimal1) && Objects.isNull(bigDecimal2)) {
            return bigDecimal1;
        }
        if (Objects.isNull(bigDecimal1) && Objects.nonNull(bigDecimal2)) {
            return bigDecimal2;
        }
        bigDecimal1 = bigDecimal1.add(new BigDecimal("" + bigDecimal2.toString()));
        return bigDecimal1;

    }

    /**
     * 将数值对象转换为 BigDecimal
     *
     * @param value value
     * @return java.math.BigDecimal
     * @author z004267r
     * @date 8/23/2019 3:48 PM
     */
    public static BigDecimal parseBigDecimal(Object value) {
        BigDecimal ret = null;
        if (Objects.isNull(value)) {
            return null;
        }
        if (value instanceof BigDecimal) {
            ret = (BigDecimal) value;
        }
        if (value instanceof String) {
            ret = new BigDecimal((String) value);
        }
        if (value instanceof BigInteger) {
            ret = new BigDecimal((BigInteger) value);
        }
        if (value instanceof Number) {
            ret = new BigDecimal(((Number) value).doubleValue());
        }
        if (Objects.isNull(ret)) {
            log.error("Not possible to coerce [" + value + "] from class " + value.getClass()
                    + " into a BigDecimal.");
        }
        return ret;
    }

    /**
     * BigDecimal转换成Double 小时点保留size位
     *
     * @param bigDecimal bigDecimal
     * @param size size
     * @return java.lang.Double
     * @author z004267r
     * @date 8/23/2019 3:49 PM
     */
    public static Double parseDouble(BigDecimal bigDecimal, Integer size) {
        if (Objects.isNull(bigDecimal)) {
            return null;
        }
        return bigDecimal.setScale(size, RoundingMode.HALF_EVEN).doubleValue();
    }

    /**
     * Double数据类型保留小数点后size位
     *
     * @param dbl dbl
     * @param size size
     * @return java.lang.Double
     * @author z004267r
     * @date 8/23/2019 3:49 PM
     */
    public static Double parseDouble(Double dbl, Integer size) {
        if (Objects.isNull(dbl)) {
            return null;
        }
        //当数值为无限值
        if(Double.isInfinite(dbl)){
            dbl=0.0D;
        }
        return BigDecimal.valueOf(dbl).setScale(size, RoundingMode.HALF_EVEN).doubleValue();
    }

    /**
     * 将Number转换为Double类型
     *
     * @param dataValue dataValue
     * @return java.lang.Double
     * @author z004267r
     * @date 8/23/2019 3:49 PM
     */
    public static Double parseDouble(Number dataValue) {
        if (Objects.isNull(dataValue)) {
            return null;
        }
        return dataValue.doubleValue();
    }

    /**
     * Number转换为Long
     *
     * @param dataValue dataValue
     * @return java.lang.Long
     * @author z004267r
     * @date 8/23/2019 3:49 PM
     */
    public static Long parseLong(Number dataValue) {
        if (Objects.isNull(dataValue)) {
            return null;
        }
        return dataValue.longValue();
    }

    /**
     * Number转换为Integer
     *
     * @param dataValue dataValue
     * @return java.lang.Integer
     * @author z004267r
     * @date 8/23/2019 3:49 PM
     */
    public static Integer parseInteger(Number dataValue) {
        if (Objects.isNull(dataValue)) {
            return null;
        }
        return dataValue.intValue();
    }



    public static Long parseLong(String str,Long def) {

        Long ret = def;
        str = StringUtils.trimToEmpty(str);
        if (Objects.isNull(str)) {
            return def;
        }
        try {
            ret = Long.parseLong(str);
        } catch (Exception ex) {
            log.error("字符串:{}转为Long类型出错！", str);
        }
        return ret;

    }

    public static Integer parseInteger(String str,Integer def) {

        Integer ret = def;
        str = StringUtils.trimToEmpty(str);
        if (Objects.isNull(str)) {
            return ret;
        }
        Pattern pattern = Pattern.compile("(\\d+)(\\.\\d+){0,1}");
        Matcher matcher = pattern.matcher(str);
        if (matcher.find()) {
            str=  matcher.group(1) ;
        }
        try {
            ret = Integer.parseInt(str);
        } catch (Exception ex) {
            log.error("字符串:{}转为Integer类型出错！", str);
        }
        return ret;

    }

    public static Boolean parseBoolean(String str,Boolean def) {

        Boolean ret = def;
        str = StringUtils.trimToEmpty(str);
        if (Objects.isNull(str)) {
            return ret;
        }
        try {
            ret = Boolean.parseBoolean(str);
        } catch (Exception ex) {
            log.error("字符串:{}转为Boolean类型出错！", str);
        }
        return ret;

    }


    public static Double parseDouble(String str,Double def) {

        Double ret = def;
        str = StringUtils.trimToEmpty(str);
        if (Objects.isNull(str)) {
            return ret;
        }
        try {
            ret = Double.parseDouble(str);
        } catch (Exception ex) {
            log.error("字符串:{}转为Double类型出错！", str);
        }
        return ret;

    }

}