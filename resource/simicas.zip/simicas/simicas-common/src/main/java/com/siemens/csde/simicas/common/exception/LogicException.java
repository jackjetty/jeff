package com.siemens.csde.simicas.common.exception;

import com.siemens.csde.simicas.common.constant.enums.ErrorEnum;
import com.siemens.csde.simicas.common.constant.enums.ResultEnum;
import lombok.Getter;
import lombok.Setter;

/**
 * LogicException 逻辑异常
 *
 * @author z0043y5h
 * @version 1.0-SNAPSHOT
 * @date 2020/2/22 16:38
 **/
@Setter
@Getter
public class LogicException extends BaseException {

    private static final long serialVersionUID = -5965505145401064194L;

    protected ErrorEnum errorEnum;

    private int code;

    public LogicException(ErrorEnum errorEnum) {
        super(errorEnum.getMsg());
        this.code = errorEnum.getCode();
    }

    public LogicException(int code, String message) {
        super(message);
        this.code = code;
    }

    public LogicException(String message) {
        super(message);
        this.code = ResultEnum.ERROR.getCode();
    }

    public LogicException(int code, Throwable cause) {
        super(cause);
        this.code = code;
    }

    public ErrorEnum getErrorEnum() {
        return errorEnum;
    }
}
