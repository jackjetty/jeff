package com.siemens.csde.simicas.common.reactor.threadpool.worker;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

/**
 * TasksQueue 任务队列
 *
 * @author z004267r
 * @version 1.0-SNAPSHOT
 * @date 8/23/2019 3:18 PM
 **/
public class TasksQueue<V> {

    private final BlockingQueue<V> tasksQueue = new LinkedBlockingQueue();
    private boolean processingCompleted = true;

    public TasksQueue() {
    }

    public V poll() {
        return this.tasksQueue.poll();
    }

    public boolean add(V value) {
        return this.tasksQueue.add(value);
    }

    public void clear() {
        this.tasksQueue.clear();
    }

    public int size() {
        return this.tasksQueue.size();
    }

    public boolean isProcessingCompleted() {
        return this.processingCompleted;
    }

    public void setProcessingCompleted(boolean processingCompleted) {
        this.processingCompleted = processingCompleted;
    }
}