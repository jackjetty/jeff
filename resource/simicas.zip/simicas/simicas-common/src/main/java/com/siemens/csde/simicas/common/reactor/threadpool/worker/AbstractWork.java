package com.siemens.csde.simicas.common.reactor.threadpool.worker;

/**
 * AbstractWork 抽象work
 *
 * @author z004267r
 * @version 1.0-SNAPSHOT
 * @date 8/23/2019 3:16 PM
 **/
public abstract class AbstractWork implements Runnable {

    private TasksQueue<AbstractWork> tasksQueue;

    public AbstractWork() {
    }

    /**
     * 获取队列
     *
     * @return com.siemens.csde.simicas.common.reactor.threadpool.worker.TasksQueue<com.siemens.csde.simicas.common.reactor.threadpool.worker.AbstractWork>
     * @author z004267r
     * @date 8/23/2019 3:16 PM
     */
    public TasksQueue<AbstractWork> getTasksQueue() {
        return this.tasksQueue;
    }

    /**
     * 设置队列
     *
     * @param tasksQueue tasksQueue
     * @return void
     * @author z004267r
     * @date 8/23/2019 3:16 PM
     */
    public void setTasksQueue(TasksQueue<AbstractWork> tasksQueue) {
        this.tasksQueue = tasksQueue;
    }
}