package com.siemens.csde.simicas.common.model;

import static com.siemens.csde.simicas.common.constant.IotTimeSeriesConstant.ORDER_ID;
import static com.siemens.csde.simicas.common.constant.IotTimeSeriesConstant.PRODUCT_ID;
import static com.siemens.csde.simicas.common.constant.IotTimeSeriesConstant.TIMESTAMP_KEY;

import java.time.Instant;
import java.util.HashMap;
import java.util.Objects;
import lombok.NoArgsConstructor;
import lombok.ToString;
import org.apache.commons.lang3.StringUtils;

@NoArgsConstructor
@ToString
public class IotTimeSeriesBean extends HashMap<String,Object> {

    public String getTime() {
        Object timeObj = this.get(TIMESTAMP_KEY);
        return Objects.isNull(timeObj) ? null : timeObj.toString();
    }

    public Instant getInstant() {
        String timeStr = getTime();
        return Objects.isNull(timeStr) ? null : Instant.parse(timeStr);
    }

    public boolean containIgnoreCases(String variable) {
        return this.entrySet().stream().map(Entry::getKey)
                .anyMatch(key -> StringUtils.containsIgnoreCase(key, variable));
    }

    public String getProductId() {
        return getStringValue(PRODUCT_ID);
    }

    public String getOrderId() {
        return getStringValue(ORDER_ID);
    }

    public String getStringValue(String variable) {
        return getValue(variable,String.class);
    }

    public <T> T getValue(String variable, Class<T> clazz) {
        return this.entrySet().stream().filter(entry -> {
            String variableName = entry.getKey();
            return StringUtils.equals(variableName, variable);
        }).findAny().map(Entry::getValue).map(value -> (T) value).orElse(null);
    }


}
