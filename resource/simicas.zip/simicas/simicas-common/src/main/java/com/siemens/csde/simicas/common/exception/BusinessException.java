package com.siemens.csde.simicas.common.exception;


import com.siemens.csde.simicas.common.constant.enums.ResultEnum;
import lombok.Getter;

public class BusinessException extends BaseException {

    private static final long serialVersionUID = 12230340719776817L;

    @Getter
    private String detail;

    protected ResultEnum errorEnum;

    public BusinessException() {
    }

    public BusinessException(String message) {
        super(message);
    }

    public BusinessException(String message,String detail) {
        super(message);
        this.detail=detail;
    }

    public BusinessException(Throwable cause) {
        super(cause);
    }

    public BusinessException(String message, Throwable cause) {
        super(message, cause);
    }

    public BusinessException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }

    public BusinessException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace, ResultEnum errorEnum) {
        super(message, cause, enableSuppression, writableStackTrace);
        setErrorEnum(errorEnum);
    }

    public ResultEnum getErrorEnum() {
        return errorEnum;
    }

    public void setErrorEnum(ResultEnum errorEnum) {
        this.errorEnum = errorEnum;
    }
}
