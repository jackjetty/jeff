package com.siemens.csde.simicas.common.model;

import com.google.gson.annotations.SerializedName;
import java.io.Serializable;
import java.util.List;
import lombok.Getter;
import lombok.Setter;


@Getter
@Setter
public class WorkSpaceModel implements Serializable {

    private static final long serialVersionUID = 8875940480008321220L;
    @SerializedName("class")
    private String clazz;
    private List<NodeData> nodeDataArray;
    private List<LinkData> linkDataArray;


    @Getter
    @Setter
    public  static class NodeData{

        private String text;
        private String disText;
        private String id;
        private Boolean isGroup;
        private String category;
        private List<String> containing;
        private String key;
        private String color;
        private Boolean config;
        private Boolean unConfig;
        private String group;
        private String loc;

    }

    @Getter
    @Setter
    public static class LinkData {

        private String from;
        private String to;
    }
}