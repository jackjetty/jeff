package com.siemens.csde.simicas.common.model;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Builder
public class QuartzJobBean {

    //任务名
    private String jobName;

    //任务组名
    private String jobGroupName;

    //触发器名
    private String triggerName;

    //触发器组名
    private String triggerGroupName;

    //时间设置，参考quartz说明文档
    private String cron;

}
