package com.siemens.csde.simicas.common.exception.security;

import org.springframework.http.HttpStatus;


public class MethodNotAllowed extends Auth2Exception {

	public MethodNotAllowed(String msg, Throwable t) {
		super(msg);
	}

	@Override
	public String getOAuth2ErrorCode() {
		return HttpStatus.METHOD_NOT_ALLOWED.getReasonPhrase();
	}

	@Override
	public int getHttpErrorCode() {
		return HttpStatus.METHOD_NOT_ALLOWED.value();
	}

}
