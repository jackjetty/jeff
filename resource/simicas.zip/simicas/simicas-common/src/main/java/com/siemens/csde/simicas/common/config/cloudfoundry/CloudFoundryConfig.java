package com.siemens.csde.simicas.common.config.cloudfoundry;

import lombok.extern.slf4j.Slf4j;
import org.springframework.cloud.Cloud;
import org.springframework.cloud.CloudException;
import org.springframework.cloud.CloudFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

/**
 * CloudFoundryConfig CloudFoundry配置信息类
 *
 * @author z004267r
 * @version 1.0-SNAPSHOT
 * @date 8/23/2019 5:17 PM
 **/
@Configuration
@Profile("cloud")
@Slf4j
public class CloudFoundryConfig {

    @Bean
    public Cloud cloudFactory() {
        try {
            return new CloudFactory().getCloud();
        } catch (CloudException ce) {
            log.error("CloudFoundryConfig error",ce);
            //	Not running in cloud environment, return null
            return null;
        }
    }
}