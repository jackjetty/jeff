package com.siemens.csde.simicas.common.valid;

public interface AddValidGroup {

}
