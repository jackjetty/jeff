package com.siemens.csde.simicas.common.util;

import java.util.UUID;

/**
 * UUIDUtil 类功能说明：UUID随机数生成器
 *
 * @author z004267r
 * @version 1.0-SNAPSHOT
 * @date 8/23/2019 5:13 PM
 **/
public class UUIDUtil {

    /**
     * 获得一个UUID
     *
     * @param * @return java.lang.String
     * @author z004267r
     * @date 8/23/2019 5:13 PM
     */
    public static String getUUID() {
        String s = UUID.randomUUID().toString();
        //去掉“-”符号
        //
        return s.substring(0, 8) + s.substring(9, 13) + s.substring(14, 18) + s.substring(19, 23)+s.substring(24);
    }

    /**
     * 获得指定数目的UUID
     *
     * @param number number
     * @return java.lang.String[]
     * @author z004267r
     * @date 8/23/2019 5:13 PM
     */
    public static String[] getUUID(int number) {
        if (number < 1) {
            return null;
        }
        String[] ss = new String[number];
        for (int i = 0; i < number; i++) {
            ss[i] = getUUID();
        }
        return ss;
    }
}