package com.siemens.csde.simicas.common.reactor.threadpool;

import java.util.concurrent.ThreadFactory;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * ThreadNameFactory 线程名称工厂
 *
 * @author z004267r
 * @version 1.0-SNAPSHOT
 * @date 8/23/2019 3:20 PM
 **/
public class ThreadNameFactory implements ThreadFactory {

    private ThreadGroup group;
    private AtomicInteger threadNumber;
    private String namePrefix;
    private boolean daemon;

    public ThreadNameFactory(String namePreFix) {
        this(namePreFix, false);
    }

    public ThreadNameFactory(String namePreFix, boolean daemon) {
        this.threadNumber = new AtomicInteger(0);
        SecurityManager s = System.getSecurityManager();
        this.group = s != null ? s.getThreadGroup() : Thread.currentThread().getThreadGroup();
        this.namePrefix = namePreFix + "-thread-";
        this.daemon = daemon;
    }

    public Thread newThread(Runnable r) {
        Thread t = new Thread(this.group, r, this.namePrefix + this.threadNumber.getAndIncrement(), 0L);
        if (this.daemon) {
            t.setDaemon(this.daemon);
        } else {
            if (t.isDaemon()) {
                t.setDaemon(false);
            }

            if (t.getPriority() != 5) {
                t.setPriority(5);
            }
        }
        return t;
    }

    public String getNamePrefix() {
        return this.namePrefix;
    }
}
