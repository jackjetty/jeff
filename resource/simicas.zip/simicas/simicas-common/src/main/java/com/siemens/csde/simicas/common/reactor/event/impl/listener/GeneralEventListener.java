package com.siemens.csde.simicas.common.reactor.event.impl.listener;


import com.siemens.csde.simicas.common.reactor.event.EventResult;
import com.siemens.csde.simicas.common.reactor.event.IEvent;
import com.siemens.csde.simicas.common.reactor.event.constant.Constants.EventTypeConstans;
import com.siemens.csde.simicas.common.reactor.event.impl.AbstractEventListener;

/**
 * GeneralEventListener 通用事件监听器
 *
 * @author z004267r
 * @version 1.0-SNAPSHOT
 * @date 8/23/2019 2:59 PM
 **/
public class GeneralEventListener extends AbstractEventListener {

    @Override
    public void initEventType() {
        register(EventTypeConstans.singleRunEventType);
    }

    @Override
    public EventResult fireEvent(IEvent event) {
        EventResult result = super.fireEvent(event);
        return result;
    }
}
