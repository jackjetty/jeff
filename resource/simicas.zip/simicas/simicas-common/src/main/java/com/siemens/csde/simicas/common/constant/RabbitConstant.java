package com.siemens.csde.simicas.common.constant;

public interface RabbitConstant{


    //采集中心队列配置
    String EXCHANGE_DIRECT_SIMICAS_COLLECTION = "exchange.direct.simicas.collection";

    String QUEUE_SIMICAS_COLLECTION_GROUP="queue.simicas.collection.group";

    String ROUTINGKEY_SIMICAS_COLLECTION_GROUP="routingkey.simicas.collection.group";

    //分线器队列配置
    String EXCHANGE_DIRECT_SIMICAS_HUB = "exchange.direct.simicas.hub";

    String QUEUE_SIMICAS_HUB_GROUP="queue.simicas.hub.group";

    String ROUTINGKEY_SIMICAS_HUB_GROUP="routingkey.simicas.hub.group";

    //处理中心队列配置
    String EXCHANGE_DIRECT_SIMICAS_HANDLE="exchange.direct.simicas.handle";

    String QUEUE_SIMICAS_HANDLE_GROUP="queue.simicas.handle.group";

    String ROUTINGKEY_SIMICAS_HANDLE_GROUP="routingkey.simicas.handle.group";

    //订阅中心队列配置（临时新老框架共存的时候用）
    String EXCHANGE_DIRECT_SIMICAS_WS="exchange.direct.macb.consumer";

    String QUEUE_SIMICAS_WS_GROUP="queue.macb.consumer.group";

    String ROUTINGKEY_SIMICAS_WS_GROUP="routingkey.macb.consumer.group";

}