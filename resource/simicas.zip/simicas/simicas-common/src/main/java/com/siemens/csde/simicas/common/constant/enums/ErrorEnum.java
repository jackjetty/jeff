package com.siemens.csde.simicas.common.constant.enums;

/**
 * ErrorEnum 错误枚举
 *
 * @author z004267r
 * @version 1.0-SNAPSHOT
 * @date 8/23/2019 2:44 PM
 **/
public enum ErrorEnum {

    BUSINESS_ERROR_PARAMETERS(1000101, "Parameters incorrect"),
    BUSINESS_ERROR_PERMISSION(1000102, "Permission limit"),
    BUSINESS_ERROR_DBPLAN_DUP(9000003, "Plan duplicate in db"),
    BUSINESS_ERROR_PRODUCTID_DUP(9000101, "Product id duplicate"),
    BUSINESS_ERROR_PRODUCTNAME_DUP(9000102, "Product name duplicate"),
    BUSINESS_ERROR_PRODUCT_UNKNOWN(9000103, "Product unknown"),
    BUSINESS_ERROR_USERSETTING_DUP(9000203, "UserSetting duplicate");

    private int code;

    private String msg;

    ErrorEnum(int code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    public int getCode() {
        return code;
    }

    public String getMsg() {
        return msg;
    }
}