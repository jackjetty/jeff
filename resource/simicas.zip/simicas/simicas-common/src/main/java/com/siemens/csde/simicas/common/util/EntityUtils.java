package com.siemens.csde.simicas.common.util;

import java.lang.reflect.Field;
import javax.persistence.Column;
import org.apache.commons.lang3.StringUtils;

/**
 * EntityUtils 实体工具类 主要用于判断实体类是否含有字段
 *
 * @author z0043y5h
 * @version 1.0-SNAPSHOT
 * @date 2020/2/23 11:27
 **/
public class EntityUtils {

    /**
     * 判断是否包含该字段
     *
     * @param field field
     * @param clazz clazz
     * @return boolean
     * @author z0043y5h
     * @date 2020/2/23 11:27
     **/
    public static <T> boolean hasField(String field, Class<T> clazz) {
        try {
            if (StringUtils.isEmpty(field)) {
                return false;
            }
            clazz.getDeclaredField(field);
        } catch (NoSuchFieldException e) {
            return false;
        }
        return true;
    }

    /**
     * 获取实体域对应的数据库字段名
     *
     * @param fieldName   fieldName
     * @param entityClazz entityClazz
     * @return java.lang.String
     * @author z0043y5h
     * @date 2020/2/23 11:27
     **/
    public static <T> String getColumn(String fieldName, Class<T> entityClazz) {
        try {
            if (StringUtils.isEmpty(fieldName)) {
                return null;
            }
            Field field = entityClazz.getDeclaredField(fieldName);
            Column annotation = field.getAnnotation(Column.class);
            if (null != annotation) {
                return annotation.name();
            }
        } catch (NoSuchFieldException e) {
        }
        return null;
    }
}
