package com.siemens.csde.simicas.common.base;

import com.google.gson.annotations.SerializedName;
import com.siemens.csde.simicas.common.constant.enums.ResultEnum;
import java.io.Serializable;
import java.time.Instant;
import lombok.Getter;
import lombok.Setter;


@Setter
@Getter
public class BaseResult<T> implements Serializable {

    private static final long serialVersionUID = -8867237549211002186L;

    private String timestamp;

    private String message ;

    private int code;

    @SerializedName(value="_embedded", alternate = "embedded")
    private T embedded;

    public BaseResult() {
        this.code = ResultEnum.SUCCESS.getCode();
        this.timestamp= Instant.now().toString();
    }

    public BaseResult(T data) {
        this.embedded = data;
        this.code = ResultEnum.SUCCESS.getCode();
        this.timestamp= Instant.now().toString();
    }

    public BaseResult(T data, String message) {
        this.code = ResultEnum.SUCCESS.getCode();
        this.embedded = data;
        this.message = message;
        this.timestamp= Instant.now().toString();
    }


    public BaseResult(T data, int code) {
        this.embedded = data;
        this.code = code;
        this.timestamp= Instant.now().toString();
    }

    public BaseResult(T data, int code, String message) {
        this.embedded = data;
        this.code = code;
        this.message = message;
        this.timestamp= Instant.now().toString();
    }

    public BaseResult(int code, String message) {
        this.code = code;
        this.message = message;
        this.timestamp= Instant.now().toString();
    }

    public BaseResult(ResultEnum resultEnum) {
        this.code =resultEnum.getCode();
        this.message = resultEnum.getInfo();
        this.timestamp= Instant.now().toString();
    }

    public BaseResult(T data, ResultEnum resultEnum) {
        this.code = resultEnum.getCode();
        this.message = resultEnum.getInfo();
        this.embedded = data;
        this.timestamp= Instant.now().toString();
    }

    public BaseResult(Throwable e) {
        this.message = e.getMessage();
        this.code = ResultEnum.ERROR.getCode();
        this.timestamp= Instant.now().toString();
    }

}
