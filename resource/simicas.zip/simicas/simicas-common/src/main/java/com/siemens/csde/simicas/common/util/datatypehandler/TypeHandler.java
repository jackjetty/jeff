package com.siemens.csde.simicas.common.util.datatypehandler;

public interface TypeHandler {

    Object typeHandler(Class type, Object value);

}
