package com.siemens.csde.simicas.common.exception.security;

import org.springframework.http.HttpStatus;


public class ServerErrorException extends Auth2Exception {

	public ServerErrorException(String msg, Throwable t) {
		super(msg);
	}

	@Override
	public String getOAuth2ErrorCode() {
		return HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase();
	}

	@Override
	public int getHttpErrorCode() {
		return HttpStatus.INTERNAL_SERVER_ERROR.value();
	}

}
