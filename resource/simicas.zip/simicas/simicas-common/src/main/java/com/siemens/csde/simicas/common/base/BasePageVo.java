package com.siemens.csde.simicas.common.base;


import com.siemens.csde.simicas.common.model.PageBean;
import java.io.Serializable;
import java.util.List;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class BasePageVo<T> implements Serializable {

    private static final long serialVersionUID = -8867237549211004386L;

    private PageBean page;

    private List<T> data;



}
