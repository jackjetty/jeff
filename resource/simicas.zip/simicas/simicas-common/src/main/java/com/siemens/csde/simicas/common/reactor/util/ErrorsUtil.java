package com.siemens.csde.simicas.common.reactor.util;

/**
 * ErrorsUtil 错误工具
 *
 * @author z004267r
 * @version 1.0-SNAPSHOT
 * @date 8/23/2019 3:22 PM
 **/
public class ErrorsUtil {

    /**
     * 构造一个错误消息,处理动作无
     *
     * @param reason reason
     * @return java.lang.String
     * @author z004267r
     * @date 8/23/2019 3:22 PM
     */
    @Deprecated
    public static String error(String reason) {
        return "Err:" + reason + ",Action:None";
    }

    /**
     * 构造一个错误消息以及对错误采取的处理动作
     *
     * @param reason reason
     * @param source source
     * @return java.lang.String
     * @author z004267r
     * @date 8/23/2019 3:22 PM
     */
    @Deprecated
    public static String error(String reason, String source) {
        return "Err:" + reason + ",Action:" + source;
    }

    /**
     * 构造一个包括了错误原因,对错误采取的动作以及错误来源的错误信息
     *
     * @param reason reason
     * @param action action
     * @param source source
     * @return java.lang.String
     * @author z004267r
     * @date 8/23/2019 3:23 PM
     */
    @Deprecated
    public static String error(String reason, String action, Object source) {
        return "Err:" + reason + ",Action:" + action + ",Source:" + source;
    }

    /**
     * 构造一个包包括了错误代码,错误来源以及调用者信息的错误描述
     *
     * @param errorCode errorCode
     * @param cause cause
     * @param callerDesc callerDesc
     * @return java.lang.String
     * @author z004267r
     * @date 8/23/2019 3:23 PM
     */
    @Deprecated
    public static String errorWithCaller(String errorCode, String cause, String callerDesc) {
        return new StringBuilder().append("Err:").append(errorCode).append(",Cause:").append(cause).append(",Caller:")
                .append(callerDesc).toString();
    }

    /**
     * 构造一个标准格式的错误信息
     *
     * @param errorCode errorCode
     * @param origin origin
     * @param param param
     * @return java.lang.String
     * @author z004267r
     * @date 8/23/2019 3:23 PM
     */
    public static String error(String errorCode, String origin, String param) {
        StringBuilder _errorStr = new StringBuilder("[").append(errorCode).append("] [").append(origin).append("]");
        if (param != null && param.length() > 0) {
            _errorStr.append(" [").append(param).append("]");
        }
        return _errorStr.toString();
    }

}

