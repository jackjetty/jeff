package com.siemens.csde.simicas.common.reactor.threadpool.worker;

import java.util.concurrent.ConcurrentHashMap;

/**
 * OrderedQueuePool 顺序队列驰
 *
 * @author z004267r
 * @version 1.0-SNAPSHOT
 * @date 8/23/2019 3:17 PM
 **/
public class OrderedQueuePool<K, V> {

    ConcurrentHashMap<K, TasksQueue<V>> map = new ConcurrentHashMap();

    public OrderedQueuePool() {
    }

    /**
     * 根据队列key获取队列
     *
     * @param key key
     * @return com.siemens.csde.simicas.common.reactor.threadpool.worker.TasksQueue<V>
     * @author z004267r
     * @date 8/23/2019 3:18 PM
     */
    public TasksQueue<V> getTasksQueue(K key) {
        TasksQueue<V> queue = (TasksQueue) this.map.get(key);
        if (queue == null) {
            TasksQueue<V> newQueue = new TasksQueue();
            queue = (TasksQueue) this.map.putIfAbsent(key, newQueue);
            if (queue == null) {
                queue = newQueue;
            }
        }
        return queue;
    }

    public ConcurrentHashMap<K, TasksQueue<V>> getTasksQueues() {
        return this.map;
    }

    public void removeTasksQueue(K key) {
        this.map.remove(key);
    }
}