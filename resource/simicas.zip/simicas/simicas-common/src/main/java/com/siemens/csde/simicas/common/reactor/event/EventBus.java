package com.siemens.csde.simicas.common.reactor.event;

import com.siemens.csde.simicas.common.reactor.event.impl.AbstractEventListener;
import java.util.HashSet;
import java.util.Map;
import java.util.Queue;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.atomic.AtomicInteger;
import lombok.extern.slf4j.Slf4j;


/**
 * EventBus 事件总线
 *
 * @author z004267r
 * @version 1.0-SNAPSHOT
 * @date 8/23/2019 3:05 PM
 **/
@Slf4j
public class EventBus implements IEventBus {

    private Map<EventType, Set<AbstractEventListener>> listenerMap;

    //事件队列
    private Queue<IEvent> events;

    //调用线程size比较费性能，这里采用原子的更新器
    private AtomicInteger size = new AtomicInteger();

    public EventBus() {
        this.listenerMap = new ConcurrentHashMap<EventType, Set<AbstractEventListener>>();
        this.events = new ConcurrentLinkedQueue<IEvent>();
    }

    public void addEventListener(AbstractEventListener listener) {
        Set<EventType> sets = listener.getSet();
        for (EventType eventType : sets) {
            if (!listenerMap.containsKey(eventType)) {
                listenerMap.put(eventType, new HashSet<AbstractEventListener>());
            }
            listenerMap.get(eventType).add(listener);
        }
    }

    public void removeEventListener(AbstractEventListener abstractEventListener) {
        Set<EventType> sets = abstractEventListener.getSet();
        for (EventType eventType : sets) {
            listenerMap.get(eventType).remove(abstractEventListener);
        }
    }

    public void clearEventListener() {
        listenerMap.clear();
    }

    public void addEvent(IEvent event) {
        this.events.add(event);
        size.getAndIncrement();
    }

    public IEvent pollEvent() {
        IEvent event = events.poll();
        if (event != null) {
            size.getAndDecrement();
        }
        return event;
    }

    public void handleEvent() {
        while (!events.isEmpty()) {
            IEvent event = pollEvent();
            if (event == null) {
                break;
            }
            try {
                handleSingleEvent(event);
            } catch (Exception e) {
                log.error(e.toString(), e);
            }

        }
    }

    /**
     * 单次超过最大设置需要停止 并且返回调度了多少事件
     *
     * @param maxSize maxSize
     * @return int
     * @author z004267r
     * @date 8/23/2019 3:05 PM
     */
    public int cycle(int maxSize) {
        int i = 0;
        while (!events.isEmpty()) {
            IEvent event = pollEvent();
            if (event == null) {
                break;
            }
            try {
                handleSingleEvent(event);
            } catch (Exception e) {
                log.error(e.toString(), e);
            }

            i++;
            if (i > maxSize) {
                break;
            }
        }

        return i;
    }

    /**
     * 执行事件
     *
     * @param event event
     * @return void
     * @author z004267r
     * @date 8/23/2019 3:05 PM
     */
    public void handleSingleEvent(IEvent event) throws Exception {
        EventType eventType = event.getEventType();
        if (listenerMap.containsKey(eventType)) {
            Set<AbstractEventListener> listenerSet = listenerMap.get(eventType);
            for (IEventListener eventListener : listenerSet) {
                if (eventListener.containEventType(event.getEventType())) {
                    eventListener.fireEvent(event);
                }
            }
        }
    }

    public void clearEvent() {
        events.clear();
    }

    public void clear() {
        clearEvent();
        clearEventListener();
    }

    /**
     * 获取事件的大小
     *
     * @param * @return int
     * @author z004267r
     * @date 8/23/2019 3:06 PM
     */
    public int getEventsSize() {
        return size.get();
    }
}
