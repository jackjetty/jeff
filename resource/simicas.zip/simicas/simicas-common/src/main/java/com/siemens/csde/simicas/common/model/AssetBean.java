package com.siemens.csde.simicas.common.model;

import com.google.gson.annotations.SerializedName;
import java.util.List;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AssetBean {

    private String assetId;
    private String tenantId;
    private String name;
    @SerializedName("etag")
    private int eTag;
    private String externalId;
    private String t2Tenant;
    private String subTenant;
    private String description;
    private String timezone;
    private String twinType;
    private String parentId;
    private String typeId;
    private LocationBean location;
    private Object deleted;
    private LinksBean _links;
    private List fileAssignments;
    private List variables;
    private List aspects;
    private List<LockBean> locks;

    @Getter
    @Setter
    public static class LocationBean {

        private String country;
        private String region;
        private String locality;
        private String streetAddress;
        private String postalCode;
        private int longitude;
        private int latitude;

    }

    @Getter
    @Setter
    public static class LinksBean {

        private LinkBean self;
        private LinkBean aspects;
        private LinkBean variables;
        private LinkBean location;
        private LinkBean parent;

        @Getter
        @Setter
        public static class LinkBean {

            private String href;
        }

    }

    @Getter
    @Setter
    public static class LockBean {

        private String service;
        private String reason;
        private String reasonCode;
        private String id;
    }

}
