package com.siemens.csde.simicas.common.reactor.event.service;

import com.siemens.csde.simicas.common.reactor.event.EventBus;
import com.siemens.csde.simicas.common.reactor.event.impl.AbstractEvent;
import com.siemens.csde.simicas.common.reactor.threadpool.worker.AbstractWork;
import lombok.extern.slf4j.Slf4j;

/**
 * SingleEventWork 单事件worker
 * @author z004267r
 * @version 1.0-SNAPSHOT
 * @date 8/23/2019 3:04 PM
 **/
@Slf4j
public class SingleEventWork extends AbstractWork {

    private EventBus eventBus;
    private AbstractEvent event;

    public SingleEventWork(EventBus eventBus, AbstractEvent event) {
        this.eventBus = eventBus;
        this.event = event;
    }

    @Override
    public void run()  {
        try {
            if (event != null) {
                eventBus.handleSingleEvent(event);
            }
        }catch (Exception e){
           throw  new Error(e);
        }

    }
}
