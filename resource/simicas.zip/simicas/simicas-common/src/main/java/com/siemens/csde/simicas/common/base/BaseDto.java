package com.siemens.csde.simicas.common.base;

import java.io.Serializable;

public class BaseDto implements Serializable {

    private static final long serialVersionUID = 01216126242033476051771L;

}
