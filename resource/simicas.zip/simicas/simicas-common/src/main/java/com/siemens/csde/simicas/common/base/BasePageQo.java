package com.siemens.csde.simicas.common.base;

import com.siemens.csde.simicas.common.model.PageBean;
import java.io.Serializable;

public class BasePageQo implements Serializable {

    private static final long serialVersionUID = -6287329388530045564L;

    /*
     * 页码，从1开始
     */
    protected int index;

    /*
     * 页面大小
     */
    protected int size;

    /*
     * 排序字段
     */
    protected String orderByColumn;

    /*
     * 排序方式
     */
    protected String orderByType;

    public int getIndex() {
        if (index <= 0) {
            index = PageBean.DEFAULT_INDEX;
        }
        return index;
    }

    public void setIndex(Integer index) {

        this.index = index == null || index.intValue() < 0 ? PageBean.DEFAULT_INDEX : index.intValue();
    }

    public int getSize() {
        if (size <= 0) {
            size = PageBean.DEFAULT_SIZE;
        }
        return size;
    }

    public void setSize(Integer size) {
        this.size = size == null || size.intValue() < 0 ? PageBean.DEFAULT_SIZE : size.intValue();
    }

    public String getOrderByColumn() {
        return orderByColumn;
    }

    public void setOrderByColumn(String orderByColumn) {
        this.orderByColumn = orderByColumn;
    }

    public String getOrderByType() {
        return orderByType;
    }

    public void setOrderByType(String orderByType) {
        this.orderByType = orderByType;
    }

}
