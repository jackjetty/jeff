package com.siemens.csde.simicas.common.model;

import java.io.Serializable;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class NotifyBean implements Serializable {

    private static final long serialVersionUID = 2726574084618340094L;
    private NotifyBody body;
    private String recipientsTo;
    private String from;
    private String subject;


    public class NotifyBody implements Serializable {

        private static final long serialVersionUID = 5303619654916275816L;
        String message;

        public void setMessage(String message) {
            this.message = message;
        }

        public String getMessage() {
            return this.message;
        }
    }

}
