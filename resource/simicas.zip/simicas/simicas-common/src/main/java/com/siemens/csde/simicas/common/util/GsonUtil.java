package com.siemens.csde.simicas.common.util;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import java.util.List;
import java.util.Map;

public class GsonUtil {

    private static Gson gson = new GsonBuilder()
            //.excludeFieldsWithoutExposeAnnotation() //不导出实体中没有用@Expose注解的属性
            //.setFieldNamingPolicy(FieldNamingPolicy.UPPER_CAMEL_CASE)//会把字段首字母大写,注:对于实体上使用了@SerializedName注解的不会生效.
            .enableComplexMapKeySerialization() //支持Map的key为复杂对象的形式
            .serializeNulls().setDateFormat("yyyy-MM-dd HH:mm:ss:SSS")//时间转化为特定格式
            .setPrettyPrinting() //对json结果格式化.
            .create();

    public static  String objectToJson(Object object){

        return gson.toJson(object);
    }

    public static <T> T jsonToObject(String jsonString, Class<T> T){
        //Gson gson = new Gson();
        return gson.fromJson(jsonString,T);
    }

    public static <T> List<T> jsonToList(String jsonString){
        //Gson gson = new Gson();

        return  gson.fromJson(jsonString, new TypeToken<List<T>>() {}.getType());
    }

    public static <T> Map<String,T> jsonToMap(String jsonString){
        //Gson gson = new Gson();
        return gson.fromJson(jsonString,new TypeToken<Map<String,T>>() {}.getType());
    }


    /*public static void main(String[] args) {
        Student student1 = Student.builder().id(0).name("张三").birthDay(new Date()).build();
        Student student2 = Student.builder().id(1).name("李四").birthDay(new Date()).build();
        Student student3 = Student.builder().id(2).name("王五").birthDay(new Date()).build();

        List<Student> studentList = new ArrayList<>();
        studentList.add(student1);
        studentList.add(student2);
        studentList.add(student3);




        Teacher teacher1 = Teacher.builder().id(0).name("赵六").title("hello").build();
        Teacher teacher2 = Teacher.builder().id(1).name("孙乾").title("hello").build();
        Teacher teacher3 = Teacher.builder().id(1).name("赵利").title("hello").build();

        List<Teacher> teacherList = new ArrayList<>();
        teacherList.add(teacher1);
        teacherList.add(teacher2);
        teacherList.add(teacher3);

        Map<String, Object> map = new LinkedHashMap<>();
        map.put("students", studentList);
        map.put("teachers", teacherList);


        String s1 = objectToJson(map);
        System.out.println(s1);

        Map<String,Object> retMap = jsonToMap(s1);
        for (String key : retMap.keySet()) {
            System.out.println("key:" + key + " values:" + retMap.get(key));
            if (key.equals("students")) {
                List<Student> stuList =  (List<Student>) retMap.get(key);
                System.out.println(stuList);
            } else if (key.equals("teachers")) {
                List<Teacher> tchrList = (List<Teacher>) retMap.get(key);
                System.out.println(tchrList);
            }
        }

        String s2 = objectToJson(student1);
        System.out.println(s2);

        Student student = jsonToObject(s2,Student.class);
        System.out.println(student);

        String s3 = objectToJson(studentList);
        System.out.println(s3);

        //Gson gson = new Gson();
        List<Student> list = jsonToList(s3);
        List<Student> list2 = gson.fromJson(s3,new TypeToken<List<Student>>() {}.getType());
        list2.forEach(student4 -> {
            System.out.println(student4.getId());
            System.out.println(student4.getName());
            System.out.println(student4.getBirthDay());
        });
        System.out.println(list);


    }

    @Getter
    @Setter
    @ToString
    @Builder
    static class Student {
        private int id;
        private String name;
        private Date birthDay;
    }

    @Getter
    @Setter
    @ToString
    @Builder
    static class Teacher {
        private int id;
        private String name;
        private String title;
    }*/




}
