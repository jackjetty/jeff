package com.siemens.csde.simicas.common.util;

import java.nio.charset.Charset;
import org.apache.commons.codec.binary.Base64;

/**
 * AuthUtil 权限工具类
 * @author z004267r
 * @version 1.0-SNAPSHOT
 * @date 8/23/2019 5:51 PM
 **/
public class AuthUtil {

    public static String getBasicAuth(String clientId, String secret) {
        String auth = clientId + ":" + secret;
        byte[] encodedAuth = Base64.encodeBase64(auth.getBytes(Charset.forName("US-ASCII")));
        String authHeader = "Basic " + new String(encodedAuth);
        return authHeader;
    }
}