package com.siemens.csde.simicas.common.interceptor;

import com.google.gson.Gson;
import com.siemens.csde.simicas.common.base.BaseResult;
import com.siemens.csde.simicas.common.constant.enums.ResultEnum;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.validation.BindException;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;


@Slf4j
@ControllerAdvice
@Component
@Order(-2)
public class ValidExceptionHandler {

    private static final Gson gson = new Gson();

    @ResponseStatus(HttpStatus.OK)
    @ExceptionHandler(BindException.class)
    @ResponseBody
    public BaseResult handleBindException(BindException ex) {

        log.error("BindException", ex);
        List<Map<String,String>> results = new ArrayList<>();
        BindingResult result = ex.getBindingResult();
        if (result.hasErrors()) {
            List<ObjectError> errors = result.getAllErrors();
            errors.forEach(p -> {
                FieldError fieldError = (FieldError) p;
                Map<String,String> map = new HashMap<>();
                map.put(fieldError.getField(),fieldError.getDefaultMessage());
                log.error("Error Data : object={}, field={}, errorMessage={}",
                        fieldError.getObjectName(), fieldError.getField(), fieldError.getDefaultMessage());
                results.add(map);
            });
        }
        return new BaseResult(ResultEnum.ERROR.getCode(),gson.toJson(results));

    }

}
