package com.siemens.csde.simicas.common.base;


import java.io.Serializable;
import lombok.Getter;
import lombok.Setter;


@Setter
@Getter
public class BaseVo implements Serializable {

	private static final long serialVersionUID = 5363342232258180057L;

}
