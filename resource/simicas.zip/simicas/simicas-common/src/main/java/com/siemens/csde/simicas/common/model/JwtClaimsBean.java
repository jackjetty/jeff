package com.siemens.csde.simicas.common.model;


import com.google.gson.annotations.SerializedName;
import java.util.List;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class JwtClaimsBean {

    @SerializedName(value = "jti")
    private String id;

    @SerializedName(value = "user_id")
    private String userId;

    @SerializedName(value = "user_name", alternate = {"sub"})
    private String userName;

    @SerializedName(value = "email")
    private String email;

    @SerializedName(value = "client_id")
    private String clientId;

    @SerializedName(value = "iat")
    private long issTime;

    @SerializedName(value = "exp")
    private long expiredTime;

    @SerializedName(value = "iss")
    private String issuer;

    private String zid;

    @SerializedName(value = "ten")
    private String tenant;

    @SerializedName(value = "subtenant")
    private String subTenant;

    @SerializedName(value = "cat")
    private String tokenCategory;

    @SerializedName(value = "scope")
    private List<String> scopes;

    @SerializedName(value = "aud")
    private List<String> audience;

    private List<String> schemas;


}
