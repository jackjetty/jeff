package com.siemens.csde.simicas.common.reactor.event;

/**
 * EventResult 事件结果
 *
 * @author z004267r
 * @version 1.0-SNAPSHOT
 * @date 8/23/2019 3:06 PM
 **/
public class EventResult<T> {

    private T t;

    public EventResult(T t) {
        this.t = t;
    }

    public T getT() {
        return t;
    }

    public void setT(T t) {
        this.t = t;
    }

}
