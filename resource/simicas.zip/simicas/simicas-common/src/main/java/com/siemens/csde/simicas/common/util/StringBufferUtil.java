package com.siemens.csde.simicas.common.util;

import java.util.Objects;

/**
 * StringBufferUtil  StringBuffer工具类
 * @author z004267r
 * @version 1.0-SNAPSHOT
 * @date 8/23/2019 5:12 PM
 **/
public class StringBufferUtil {

    /**
     * stringBuffer 替换
     * @author z004267r
     * @param stringBuffer  stringBuffer
     * @param placeHolder  placeHolder
     * @param replace  replace
     * @return void
     * @date 8/23/2019 5:12 PM
     */
    public static void replace(StringBuffer stringBuffer, String placeHolder, String replace) {
        if (Objects.isNull(stringBuffer) || stringBuffer.length() == 0) {
            return;
        }
        while (stringBuffer.indexOf(placeHolder) != -1) {
            stringBuffer.replace(stringBuffer.indexOf(placeHolder), (stringBuffer.indexOf(placeHolder) + placeHolder.length()), replace);
        }
    }
}