package com.siemens.csde.simicas.common.util;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.commons.lang3.time.DateUtils;


@Slf4j
public class DateUtil extends DateUtils {

    public static final Long MILLISECONDS_PER_SECOND=1000L;

    //2019-02-12T07:24:20Z
    private static String[] parsePatterns = {"yyyy-MM", "yyyy-MM-dd", "yyyy-MM-dd HH:mm:ss", "yyyy-MM-dd'T'HH:mm:ss'Z'", "yyyy-MM-dd HH:mm",
            "yyyy-MM-dd HH", "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'",
            "yyyy/MM", "yyyy/MM/dd", "yyyy/MM/dd HH:mm:ss", "yyyy/MM/dd'T'HH:mm:ss'Z'", "yyyy/MM/dd HH:mm", "yyyy/MM/dd HH",
            "yyyy/MM/dd'T'HH:mm:ss.SSS'Z'","EEE MMM dd HH:mm:ss z yyyy"};

    /**
     * 得到当前日期字符串 格式（yyyy-MM-dd） pattern可以为："yyyy-MM-dd" "HH:mm:ss" "E"
     *
     * @param pattern pattern
     * @return java.lang.String
     * @author z004267r
     * @date 8/23/2019 3:30 PM
     */
    public static String getDate(String pattern) {
        return DateFormatUtils.format(new Date(), pattern);
    }

    /**
     * 得到日期字符串 默认格式（yyyy-MM-dd） pattern可以为："yyyy-MM-dd" "HH:mm:ss" "E"
     *
     * @param date date
     * @param pattern pattern
     * @return java.lang.String
     * @author z004267r
     * @date 8/23/2019 3:30 PM
     */
    public static String formatDate(Date date, Object... pattern) {
        String formatDate = null;
        if (date == null) {
            return null;
        }
        if (pattern != null && pattern.length > 0) {
            formatDate = DateFormatUtils.format(date, pattern[0].toString());
        } else {
            formatDate = DateFormatUtils.format(date, "yyyy-MM-dd");
        }
        return formatDate;
    }

    /**
     * 得到日期时间字符串，转换格式（yyyy-MM-dd HH:mm:ss）
     *
     * @param date date
     * @return java.lang.String
     * @author z004267r
     * @date 8/23/2019 3:30 PM
     */
    public static String formatDateTime(Date date) {
        return formatDate(date, "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
    }

    /**
     * 得到当前日期和时间字符串 格式（yyyy-MM-dd HH:mm:ss）
     *
     * @param * @return java.lang.String
     * @author z004267r
     * @date 8/23/2019 3:30 PM
     */
    public static String getDateTime() {
        return formatDate(new Date(), "yyyy-MM-dd HH:mm:ss");
    }

    /**
     * 日期型字符串转化为日期
     * 格式 { "yyyy-MM-dd", "yyyy-MM-dd HH:mm:ss", "yyyy-MM-dd HH:mm", "yyyy/MM/dd", "yyyy/MM/dd HH:mm:ss", "yyyy/MM/dd HH:mm" }
     *
     * @param str str
     * @return java.util.Date
     * @author z004267r
     * @date 8/23/2019 3:30 PM
     */
    public static Date parseDate(Object str) {
        if (str == null) {
            return null;
        }
        try {
            return parseDate(str.toString(), Locale.ENGLISH, parsePatterns);
        } catch (ParseException e) {
            log.error("日期转换异常:{}", e);
            return null;
        }
    }

    /**
     * 将时间yyyy-MM-dd HH:mm:ss 转换为 yyyy-MM-dd 00:00:00
     *
     * @param date date
     * @return java.util.Date
     * @author z004267r
     * @date 8/23/2019 3:31 PM
     */
    public static Date getDateStart(Date date) {
        if (date == null) {
            return null;
        }
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        try {
            date = sdf.parse(formatDate(date, "yyyy-MM-dd") + " 00:00:00");
        } catch (ParseException e) {
            log.error("日期转换异常:{}", e);
            return null;
        }
        return date;
    }

    /**
     * 将时间yyyy-MM-dd HH:mm:ss 转换为 yyyy-MM-dd 23:59:59
     *
     * @param date date
     * @return java.util.Date
     * @author z004267r
     * @date 8/23/2019 3:31 PM
     */
    public static Date getDateEnd(Date date) {
        if (date == null) {
            return null;
        }
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        try {
            date = sdf.parse(formatDate(date, "yyyy-MM-dd") + " 23:59:59");
        } catch (ParseException e) {
            log.error("日期转换异常:{}", e);
            return null;
        }
        return date;
    }

    /**
     * 本地时间转换（加时区）
     *
     * @param timeZone timeZone
     * @param calendar calendar
     * @return void
     * @author z004267r
     * @date 8/23/2019 3:31 PM
     */
    public static void toLocalCalendar(Integer timeZone, Calendar calendar) {
        calendar.add(Calendar.HOUR_OF_DAY, timeZone);
    }

    /**
     * UTC时间转换（减时区）
     *
     * @param timeZone timeZone
     * @param calendar calendar
     * @return void
     * @author z004267r
     * @date 8/23/2019 3:31 PM
     */
    public static void toUTCCalendar(Integer timeZone, Calendar calendar) {
        calendar.add(Calendar.HOUR_OF_DAY, -timeZone);
    }

    /**
     * 计算时间差
     *
     * @param beginDate beginDate
     * @param endDate endDate
     * @return long
     * @author z004267r
     * @date 8/23/2019 3:31 PM
     */
    public static long getDiffTimeBySecond(Date beginDate, Date endDate) {
        if (beginDate == null) {
            return 0L;
        }
        if (endDate == null) {
            return 0L;
        }
        long diff = endDate.getTime() - beginDate.getTime();
        diff = diff / 1000;
        return diff;
    }


    public static long getDiffTimeByMinute(Date beginDate, Date endDate) {
        if (beginDate == null) {
            return 0L;
        }
        if (endDate == null) {
            return 0L;
        }
        long diff = endDate.getTime() - beginDate.getTime();
        diff = diff / 1000 / 60;
        return diff;
    }

    /**
     * 计算时间字符串差值
     *
     * @param from from
     * @param to to
     * @return long
     * @author z004267r
     * @date 8/23/2019 3:31 PM
     */
    public static long getIntervalSeconds(String from, String to) {
        long diff = Instant.parse(to).getEpochSecond() - Instant.parse(from).getEpochSecond();
        return diff;
    }

    /**
     * 格式化时间
     *
     * @param timestamp timestamp
     * @return java.lang.String
     * @author z004267r
     * @date 8/23/2019 3:31 PM
     */
    public static String dateFormat(Date timestamp) {
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        return format.format(timestamp);
    }

    /**
     * 获取系统时间Timestamp
     *
     * @param * @return java.sql.Timestamp
     * @author z004267r
     * @date 8/23/2019 3:31 PM
     */
    public static Timestamp getSysTimestamp() {
        return new Timestamp(System.currentTimeMillis());
    }


    /**
     * 生成时间随机数
     *
     * @param * @return java.lang.String
     * @author z004267r
     * @date 8/23/2019 3:31 PM
     */
    public static String getDateRandom() {
        String s = new SimpleDateFormat("yyyyMMddHHmmssSSS").format(new Date());
        return s;
    }

    /**
     * 获取时间下一个小时
     *
     * @param date date
     * @return java.util.Date
     * @author z004267r
     * @date 8/23/2019 3:31 PM
     */
    public static Date getNextHour(Date date) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.add(Calendar.HOUR_OF_DAY, 1);
        calendar.set(Calendar.MINUTE, 0);
        calendar.set(Calendar.SECOND, 0);
        calendar.set(Calendar.MILLISECOND, 0);
        return calendar.getTime();
    }

    /**
     * 获取时间（输入Calendar）
     *
     * @param calendar calendar
     * @return java.util.Date
     * @author z004267r
     * @date 8/23/2019 3:31 PM
     */
    public static Date getZeroHour(Calendar calendar) {
        // 时
        calendar.set(Calendar.HOUR_OF_DAY, 0);
        // 分
        calendar.set(Calendar.MINUTE, 0);
        // 秒
        calendar.set(Calendar.SECOND, 0);
        // 毫秒
        calendar.set(Calendar.MILLISECOND, 0);
        return calendar.getTime();

    }

    /**
     * 获取时间下一个小时（输入Calendar）
     *
     * @param calendar calendar
     * @return java.util.Date
     * @author z004267r
     * @date 8/23/2019 3:31 PM
     */
    public static Date getLastHour(Calendar calendar) {
        // 时
        calendar.set(Calendar.HOUR_OF_DAY, 23);
        // 分
        calendar.set(Calendar.MINUTE, 59);
        // 秒
        calendar.set(Calendar.SECOND, 59);
        // 毫秒
        calendar.set(Calendar.MILLISECOND, 999);
        return calendar.getTime();

    }

    /**
     * 将给定时间分钟、秒转换为0秒0ms
     *
     * @param calendar calendar
     * @return java.util.Calendar
     * @author z004267r
     * @date 8/23/2019 3:31 PM
     */
    public static Calendar getStartMinute(Calendar calendar) {
        Calendar startCalendar = (Calendar) calendar.clone();
        startCalendar.set(Calendar.SECOND, 0);
        startCalendar.set(Calendar.MILLISECOND, 0);
        return startCalendar;

    }

    /**
     * 将给定时间分钟、秒转换为59s999ms
     *
     * @param calendar calendar
     * @return java.util.Calendar
     * @author z004267r
     * @date 8/23/2019 3:32 PM
     */
    public static Calendar getEndMinute(Calendar calendar) {
        Calendar endCalendar = (Calendar) calendar.clone();
        endCalendar.set(Calendar.SECOND, 59);
        endCalendar.set(Calendar.MILLISECOND, 999);
        return endCalendar;

    }

    /**
     * 将给定时间分钟、秒转换为0min0s0ms
     *
     * @param calendar calendar
     * @return java.util.Calendar
     * @author z004267r
     * @date 8/23/2019 3:32 PM
     */
    public static Calendar getStartHour(Calendar calendar) {
        Calendar startCalendar = (Calendar) calendar.clone();
        startCalendar.set(Calendar.MINUTE, 0);
        startCalendar.set(Calendar.SECOND, 0);
        startCalendar.set(Calendar.MILLISECOND, 0);
        return startCalendar;

    }

    /**
     * 将给定时间分钟、秒转换为0min0s0ms（输入为Date）
     *
     * @param date date
     * @return java.util.Date
     * @author z004267r
     * @date 8/23/2019 3:32 PM
     */
    public static Date getStartHour(Date date) {

        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar = getStartHour(calendar);
        return calendar.getTime();
    }

    /**
     * 将给定时间分钟、秒转换为59min59s999ms
     *
     * @param calendar calendar
     * @return java.util.Calendar
     * @author z004267r
     * @date 8/23/2019 3:32 PM
     */
    public static Calendar getEndHour(Calendar calendar) {
        Calendar endCalendar = (Calendar) calendar.clone();
        endCalendar.set(Calendar.MINUTE, 59);
        endCalendar.set(Calendar.SECOND, 59);
        endCalendar.set(Calendar.MILLISECOND, 999);
        return endCalendar;

    }

    /**
     * 获取小时中的截至时间
     * @author Z0040M9S
     * @param date :
     * @return : java.util.Date
     * @date   4/7/2020 2:35 PM
     */
    public static Date getEndHour(Date date) {

        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar = getEndHour(calendar);
        return calendar.getTime();
    }

    /**
     * 将给定时间分钟、秒转换为0h0min0s0ms
     *
     * @param calendar calendar
     * @return java.util.Calendar
     * @author z004267r
     * @date 8/23/2019 3:32 PM
     */
    public static Calendar getStartDay(Calendar calendar) {
        Calendar startCalendar = (Calendar) calendar.clone();
        startCalendar.set(Calendar.HOUR_OF_DAY, 0);
        startCalendar.set(Calendar.MINUTE, 0);
        startCalendar.set(Calendar.SECOND, 0);
        startCalendar.set(Calendar.MILLISECOND, 0);
        return startCalendar;

    }

    /**
     * 将给定时间分钟、秒转换为23h59min59s999ms
     *
     * @param calendar calendar
     * @return java.util.Calendar
     * @author z004267r
     * @date 8/23/2019 3:32 PM
     */
    public static Calendar getEndDay(Calendar calendar) {
        Calendar endCalendar = (Calendar) calendar.clone();
        endCalendar.set(Calendar.HOUR_OF_DAY, 23);
        endCalendar.set(Calendar.MINUTE, 59);
        endCalendar.set(Calendar.SECOND, 59);
        endCalendar.set(Calendar.MILLISECOND, 999);
        return endCalendar;

    }

    /**
     * 将给定时间分钟、秒转换为0m0h0min0s0ms
     *
     * @param calendar calendar
     * @return java.util.Calendar
     * @author z004267r
     * @date 8/23/2019 3:32 PM
     */
    public static Calendar getStartMonth(Calendar calendar) {
        Calendar startCalendar = (Calendar) calendar.clone();
        startCalendar.set(Calendar.DAY_OF_MONTH, 1);
        startCalendar.set(Calendar.HOUR_OF_DAY, 0);
        startCalendar.set(Calendar.MINUTE, 0);
        startCalendar.set(Calendar.SECOND, 0);
        startCalendar.set(Calendar.MILLISECOND, 0);
        return startCalendar;

    }

    /**
     * 将给定时间分钟、秒转换为11m23h59min59s999ms
     *
     * @param calendar calendar
     * @return java.util.Calendar
     * @author z004267r
     * @date 8/23/2019 3:32 PM
     */
    public static Calendar getEndMonth(Calendar calendar) {
        Calendar endCalendar = (Calendar) calendar.clone();
        int maxMonthDay = endCalendar.getActualMaximum(Calendar.DAY_OF_MONTH);
        endCalendar.set(Calendar.DAY_OF_MONTH, maxMonthDay);
        endCalendar.set(Calendar.HOUR_OF_DAY, 23);
        endCalendar.set(Calendar.MINUTE, 59);
        endCalendar.set(Calendar.SECOND, 59);
        endCalendar.set(Calendar.MILLISECOND, 999);
        return endCalendar;

    }

    public static Date getInitalDate() {
        return DateUtil.parseDate("1900-01-01");
    }

}
