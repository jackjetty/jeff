package com.siemens.csde.simicas.common.interceptor;


import com.google.gson.Gson;
import com.siemens.csde.simicas.common.base.BaseResult;
import com.siemens.csde.simicas.common.constant.CommonConstant;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.oauth2.provider.error.OAuth2AccessDeniedHandler;
import org.springframework.stereotype.Component;


@Slf4j
@Component
@AllArgsConstructor
public class AccessDeniedHandler extends OAuth2AccessDeniedHandler {

    @Override
    public void handle(
            HttpServletRequest request, HttpServletResponse response, AccessDeniedException authException) throws IOException {

        response.setCharacterEncoding(CommonConstant.UTF8);
        response.setContentType(CommonConstant.CONTENT_TYPE);

        log.info("AccessDeniedException:", authException);

        BaseResult result = new BaseResult(authException);

        response.setStatus(HttpServletResponse.SC_FORBIDDEN);
        PrintWriter printWriter = response.getWriter();
        printWriter.append(new Gson().toJson((result)));

    }

}
