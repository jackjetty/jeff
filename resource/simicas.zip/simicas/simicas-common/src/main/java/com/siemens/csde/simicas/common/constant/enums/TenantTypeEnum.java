package com.siemens.csde.simicas.common.constant.enums;

import java.util.stream.Stream;
import org.apache.commons.lang3.StringUtils;

/**
 * TenantTypeEnum TenantType 枚举
 *
 * @author z0043y5h
 * @version 1.0-SNAPSHOT
 * @date 2020/3/24 14:53
 **/
public enum TenantTypeEnum {
    DEVELOPER("DEVELOPER"),
    OPERATOR("OPERATOR"),
    USER("USER"),
    CUSTOMER("CUSTOMER");

    private String value;

    public String value() {
        return value;
    }

    TenantTypeEnum(String value) {
        this.value = value;
    }

    /**
     * 根据枚举名称获取对应枚举类
     *
     * @param TenantTypeName TenantTypeName
     * @return com.siemens.csde.macb.common.enums.KpiEnum
     * @author z004267r
     * @date 8/23/2019 2:45 PM
     */
    public static TenantTypeEnum fromMessageTypeName(String TenantTypeName) {
        TenantTypeEnum tenantTypeEnum;
        try {
            tenantTypeEnum = TenantTypeEnum.valueOf(TenantTypeName.toUpperCase());
        } catch (IllegalArgumentException e) {
            tenantTypeEnum = Stream.of(TenantTypeEnum.values())
                    .filter(tenantTypeEm -> StringUtils.containsIgnoreCase(TenantTypeName, tenantTypeEm.name()) ||
                            StringUtils.containsIgnoreCase(TenantTypeName, tenantTypeEm.value))
                    .findAny()
                    .orElse(null);
        }
        return tenantTypeEnum;
    }
}
