package com.siemens.csde.simicas.common.exception.security;


import com.siemens.csde.simicas.common.constant.enums.ResultEnum;

public class InvalidTokenException extends Auth2Exception {

	public InvalidTokenException(String msg) {
		super(msg);
	}

	public InvalidTokenException(String msg, Throwable t) {
		super(msg);
	}


	@Override
	public String getOAuth2ErrorCode() {
		return ResultEnum.INVALID_TOKEN.getInfo();
	}

	@Override
	public int getHttpErrorCode() {
		return ResultEnum.INVALID_TOKEN.getCode();
	}

}
