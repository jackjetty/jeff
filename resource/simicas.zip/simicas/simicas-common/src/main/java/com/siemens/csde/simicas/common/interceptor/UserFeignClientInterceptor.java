package com.siemens.csde.simicas.common.interceptor;

import com.google.gson.Gson;
import com.siemens.csde.simicas.common.model.UserBean;
import com.siemens.csde.simicas.common.util.ThreadLocalUtil;
import feign.RequestInterceptor;
import feign.RequestTemplate;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class UserFeignClientInterceptor implements RequestInterceptor {

    @Override
    public void apply(RequestTemplate requestTemplate) {

        //从应用上下文中取出user信息，放入Feign的请求头中
        UserBean user = ThreadLocalUtil.getUser();

        if (user != null) {
            try {
                String userJson = new Gson().toJson(user);
                requestTemplate.header(ThreadLocalUtil.KEY_USER_IN_HTTP_HEADER,
                        new String[]{URLDecoder.decode(userJson,"UTF-8")});
            } catch (UnsupportedEncodingException e) {
                log.error("User set error",e);
            }
        }
    }

}
