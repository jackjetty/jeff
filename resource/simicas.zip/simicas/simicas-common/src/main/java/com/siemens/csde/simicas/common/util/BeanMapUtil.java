package com.siemens.csde.simicas.common.util;

import com.google.common.collect.Lists;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import org.dozer.DozerBeanMapper;

public class BeanMapUtil {

    /**
     * 持有Dozer单例, 避免重复创建DozerMapper消耗资源.
     */
    private static DozerBeanMapper dozer = new DozerBeanMapper(Lists.newArrayList("dozer/dozer-mapper.xml"));

    /**
     * 基于Dozer转换对象的类型.
     *
     * @param source source
     * @param destinationClass destinationClass
     * @return T
     * @author z004267r
     * @date 8/23/2019 3:29 PM
     */
    public static <T> T map(Object source, Class<T> destinationClass) {
        return dozer.map(source, destinationClass);
    }

    /**
     * 基于Dozer转换Collection中对象的类型.
     *
     * @param sourceList sourceList
     * @param destinationClass destinationClass
     * @return java.util.List<T>
     * @author z004267r
     * @date 8/23/2019 3:29 PM
     */
    public static <T> List<T> mapList(Collection<?> sourceList, Class<T> destinationClass) {
        List<T> destinationList = new ArrayList<T>();
        for (Object sourceObject : sourceList) {
            T destinationObject = dozer.map(sourceObject, destinationClass);
            destinationList.add(destinationObject);
        }

        return destinationList;
    }

    /**
     * 基于Dozer将对象A的值拷贝到对象B中.
     *
     * @param source source
     * @param destinationObject destinationObject
     * @return void
     * @author z004267r
     * @date 8/23/2019 3:29 PM
     */
    public static void copy(Object source, Object destinationObject) {
        dozer.map(source, destinationObject);
    }

}
