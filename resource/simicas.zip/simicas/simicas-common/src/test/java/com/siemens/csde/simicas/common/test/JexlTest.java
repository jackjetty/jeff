package com.siemens.csde.simicas.common.test;

import java.util.Comparator;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.jexl2.Expression;
import org.apache.commons.jexl2.JexlContext;
import org.apache.commons.jexl2.JexlEngine;
import org.apache.commons.jexl2.MapContext;
import org.assertj.core.util.Lists;
import org.junit.Assert;
import org.junit.Test;
@Slf4j
public class JexlTest {

    @Test
    public void express(){
        JexlEngine jexl = new JexlEngine();
        //创建一个表达式
        Expression e = jexl.createExpression("n1+n2+3");
        JexlContext jc = new MapContext();
        jc.set("n1","2");
        jc.set("n2","3");
        jc.set("n3",3);
        Assert.assertEquals(e.evaluate(jc),8);
        int i=9;
        System.out.print(i++);
    }

    @Test
    public void listSort(){
        List list= Lists.newArrayList(2,1,3);
        list.sort(Comparator.naturalOrder());
        log.info("result:{}",list);
    }


    @Test
    public void parseInt(){
        String str="517";
        Pattern pattern = Pattern.compile("(\\d+)(\\.\\d+){0,1}");
        Matcher matcher = pattern.matcher(str);
        if (matcher.find()) {
            str=  matcher.group(1) ;
        }
        log.info("result:{}",str);
    }
}