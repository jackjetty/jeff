package com.siemens.csde.simicas.jpa.repository;

import com.siemens.csde.simicas.jpa.entity.AlarmCfgRule2EmailEntity;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface AlarmCfgRule2EmailRepository extends JpaRepository<AlarmCfgRule2EmailEntity, String>, JpaSpecificationExecutor<AlarmCfgRule2EmailEntity> {


    List<AlarmCfgRule2EmailEntity> findByRuleIdOrderByEmailAddress(@Param("ruleId") String ruleId);

    @Query(value="SELECT re.emailAddress FROM AlarmCfgRule2EmailEntity re WHERE re.ruleId= :ruleId ORDER BY re.emailAddress")
    List<String> findEmailAddressesByRuleId(@Param("ruleId") String ruleId);


    @Modifying
    @Query(value="DELETE AlarmCfgRule2EmailEntity re WHERE re.ruleId= :ruleId AND re.emailAddress in (:emailAddresses) ")
    void deleteByRuleIdAndEmailAddresses(@Param("ruleId") String ruleId,@Param("emailAddresses") List<String> emailAddresses);


    @Modifying
    @Query(value="DELETE AlarmCfgRule2EmailEntity re WHERE re.ruleId= :ruleId  ")
    void deleteByRuleId(@Param("ruleId") String ruleId );

    @Modifying
    @Query(value = "DELETE FROM tb_alarm_cfg_rule2email AS e USING tb_alarm_cfg_rule AS c WHERE c.id=e.rule_id AND c.line_id=:lineId",nativeQuery = true)
    void deleteByLineId(@Param("lineId") String lineId);

}
