package com.siemens.csde.simicas.jpa.repository;

import com.siemens.csde.simicas.jpa.entity.AlarmCfgRuleEntity;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface AlarmCfgRuleRepository extends JpaRepository<AlarmCfgRuleEntity, String>, JpaSpecificationExecutor<AlarmCfgRuleEntity> {

    void deleteById(@Param("id") String id);

    Optional<AlarmCfgRuleEntity> findById(@Param("id") String id);

    @Query(value = " SELECT * FROM  tb_alarm_cfg_rule WHERE  line_id= :lineId AND kpi= :kpi AND alarm_level= :alarmLevel AND status= :status  LIMIT 1", nativeQuery = true)
    Optional<AlarmCfgRuleEntity> findByLineIdAndKpiAndAlarmLevel(@Param("lineId") String lineId, @Param("kpi") String kpi, @Param("alarmLevel") String alarmLevel,@Param("status") Integer status);

    List<AlarmCfgRuleEntity> findByLineIdAndKpiAndStatus(@Param("lineId") String lineId, @Param("kpi") String kpi, @Param("status") Integer status);

    List<AlarmCfgRuleEntity> findByLineIdAndStatus(@Param("lineId") String lineId, @Param("status") Integer status);

    @Modifying
    @Query(value = "DELETE FROM tb_alarm_cfg_rule AS r USING tb_alarm_category AS c WHERE c.id=r.category_id AND c.line_id=:lineId",nativeQuery = true)
    void deleteTbAlarmRuleByLineId(@Param("lineId") String lineId);

}
