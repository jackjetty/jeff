package com.siemens.csde.simicas.jpa.entity;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Type;

@Entity
@Setter
@Getter
@ToString
@Table(name = "tb_data_collect_stopcode", schema = "public")
public class DataCollectStopCodeEntity {

    @Id
    @GenericGenerator(name="idGenerator", strategy="uuid")
    @GeneratedValue(generator="idGenerator")
    private String id;

    @Column(name = "line_id",  length = 50 )
    private String lineId;

    @Column(name = "order_id",  length = 50 )
    private String orderId;

    @Column(name = "station_id",  length = 50 )
    private String stationId;

    @Column(name = "batch_id",  length = 50 )
    private String batchId;

    @Column(name = "statistic_time" )
    private Date statisticTime;

    @Column(name = "save_time" )
    private Date saveTime;

    @Column(name = "downtime_category"  )
    @Type(type="org.hibernate.type.NumericBooleanType")
    private Boolean downtimeCategory;


    @Column(name = "joint"  )
    @Type(type="org.hibernate.type.NumericBooleanType")
    private Boolean joint;

    @Column(name = "status" )
    private String status;

    @Column(name = "start_time" )
    private Date startTime;

    @Column(name = "end_time" )
    private Date endTime;

    @Column(name = "stop_code",length = 50)
    private String stopCode;

}