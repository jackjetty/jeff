package com.siemens.csde.simicas.jpa.shardingjdbc.constant;

/**
 * ShardingConstant
 *
 * @author z0043y5h
 * @version 1.0-SNAPSHOT
 * @date 2019/11/7 17:16
 **/
public interface ShardingConstant {

    /**
     * 数据库名与表名间分隔符
     */

    String DB_TABLE_SEPARATOR = ".";

    /**
     * 物理表间分隔符
     */
    String SHARDING_TABLE_SEPARATOR = ",";

    /**
     * 分表规则，表名与tenant之间的分隔符
     **/
    String TABLE_TENANT_SEPARATOR = "_";

    /**
     * 默认分表字段
     */
    String SHARDING_DEFAULT_COLUMN = "line_id";


    String TABLE_DETAIL_QUERY_SQL = "SELECT\n"
            + "\tcolumns.table_name tableName,\n"
            + "\tcolumns.column_name columnName,\n"
            + "\tcolumns.ordinal_position orderIndex,\n"
            + "\tcolumns.is_nullable isNullable,\n"
            + "\tcolumns.udt_name columnType,\n"
            + "\tcolumns.character_maximum_length cloumnLength,\n"
            + "\tCASE\n"
            + "\t\tWHEN key_column.column_name IS NOT NULL THEN 1\n"
            + "\t\tELSE 0\n"
            + "\tEND AS isKey\n"
            + "FROM\n"
            + "\tinformation_schema. COLUMNS COLUMNS\n"
            + "LEFT JOIN information_schema.key_column_usage key_column ON\n"
            + "\tkey_column.table_name = columns.table_name\n"
            + "\tAND key_column.column_name = columns.column_name\n"
            + "WHERE\n"
            + "\tcolumns.table_schema = 'public'\n"
            + "\tAND columns.table_name = ? ";

    String SHARDING_TABLE_NAMES_SQL = "SELECT table_name FROM information_schema.TABLES WHERE table_schema='public' AND table_name LIKE '%tb_order%'";

    String SHARDING_COLUMN_MAPPING_SQL = "SELECT id,tenant FROM tb_cfg_line WHERE status = 1";
}
