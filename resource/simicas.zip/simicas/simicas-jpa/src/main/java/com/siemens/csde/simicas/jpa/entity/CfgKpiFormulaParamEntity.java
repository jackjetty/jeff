package com.siemens.csde.simicas.jpa.entity;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.GenericGenerator;

@Entity
@Setter
@Getter
@Table(name = "tb_cfg_kpi_formula_param", schema = "public")
public class CfgKpiFormulaParamEntity {

    @Id
    @GenericGenerator(name = "idGenerator", strategy = "uuid")
    @GeneratedValue(generator = "idGenerator")
    @Column(name = "id", length = 50)
    private String id;


    @Column(name = "name",length = 50)
    private String name;

    @Column(name = "expression",length = 150)
    private String expression;

    @Column(name = "script",columnDefinition="text")
    private String script;

    @Column(name = "kpi_id",length = 50)
    private String kpiId;

    @Column(name = "create_time" )
    private Date createTime;

    @Column(name = "create_user",length = 64 )
    private String createUser;

    @Column(name = "update_time")
    private Date updateTime;

    @Column(name = "update_user",length = 64 )
    private String updateUser;

    @Column(name = "status")
    private Integer status;

}