package com.siemens.csde.simicas.jpa.entity;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.hibernate.annotations.GenericGenerator;

@Entity
@Setter
@Getter
@ToString
@Table(name = "tb_alarm_cfg_notify_policy", schema = "public")
public class AlarmCfgNotifyPolicyEntity {

    @Id
    @GenericGenerator(name = "idGenerator", strategy = "uuid")
    @GeneratedValue(generator = "idGenerator")
    private String id;

    @Column(name = "tenant",length = 50 )
    private String tenant;

    @Column(name = "line_id",length = 50 )
    private String lineId;

    @Column(name = "kpi",length = 50 )
    private String kpi;

    @Column(name = "policy_type" )
    private Integer policyType;

    @Column(name = "limit_web" )
    private Integer webLimit;

    @Column(name = "limit_email" )
    private Integer emailLimit;

    @Column(name = "create_time" )
    private Date createTime;

    @Column(name = "create_user_id",length = 50 )
    private String createUserId;

    @Column(name = "update_time")
    private Date updateTime;

    @Column(name = "update_user_id",length = 50 )
    private String updateUserId;

    @Column(name = "status")
    private Integer status;



}
