package com.siemens.csde.simicas.jpa.repository;

import com.siemens.csde.simicas.jpa.entity.SysUserSettingEntity;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

/**
 * SysUserSettingRepository 接口
 *
 * @author z0043y5h
 * @version 1.0-SNAPSHOT
 * @date 2020/3/12 10:53
 **/
@Repository
public interface SysUserSettingRepository extends JpaRepository<SysUserSettingEntity, String>,
        JpaSpecificationExecutor<SysUserSettingEntity> {

    Optional<SysUserSettingEntity> findByIdAndStatusAndCreateUser(@Param("id") String id, @Param("status") int status,
            @Param("createUser") String createUser);

    SysUserSettingEntity findByStatusAndCreateUserAndPartTypeAndSettingType(Integer status, String userId,
            String partType, String settingType);
}
