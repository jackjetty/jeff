package com.siemens.csde.simicas.jpa.entity;

import lombok.Getter;
import lombok.Setter;
@Getter
@Setter
public class TrStationRangeEntity {

    private String station;
    private String range;

}