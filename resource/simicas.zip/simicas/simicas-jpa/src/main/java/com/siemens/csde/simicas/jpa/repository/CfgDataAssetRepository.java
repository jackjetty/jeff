package com.siemens.csde.simicas.jpa.repository;

import com.siemens.csde.simicas.jpa.entity.CfgDataAssetEntity;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
public interface CfgDataAssetRepository extends JpaRepository<CfgDataAssetEntity, String>, JpaSpecificationExecutor<CfgDataAssetEntity> {

    String SQL_DATAASSETS =  new StringBuffer( "SELECT  da.id AS  \"id\",  \n")
            .append(" da.aspect_name AS  \"aspectName\", \n")
            .append(" da.asset_id AS  \"assetId\", \n")
            .append(" da.tenant_id  AS  \"tenantId\", \n")
            .append(" da.last_process_time AS  \"lastProcessTime\", \n")
            .append(" da.status AS  \"status\", \n")
            .append(" da.collection_method AS  \"collectionMethod\", \n")
            .append(" da.collection_type AS  \"collectionType\", \n")
            .append(" da.password AS  \"password\", \n")
            .append(" da.url AS  \"url\", \n")
            .append(" da.user_name AS  \"userName\", \n")
            .append(" da.part AS  \"part\", \n")
            .append(" pl.id AS \"lineId\" , \n")
            .append(" pl.name AS \"lineName\", \n")
            .append(" pl.index AS \"createIndex\" \n")
            .append(" FROM tb_cfg_data_asset da    \n")
            .append(" INNER JOIN tb_sys_tenant t ON t.id=da.tenant_id  \n")
            .append(" INNER JOIN tb_cfg_line pl ON pl.asset_id=da.asset_id   \n")
            .append(" WHERE t.status=1  AND  pl.status=1 AND da.status=1 \n")
            .append(" ORDER BY  da.tenant_id,da.asset_id,aspect_name").toString();

    List<CfgDataAssetEntity> findByAssetIdAndStatus(@Param("assetId") String assetId,@Param("status") Integer status);

    @Transactional
    @Modifying
    @Query(value = "UPDATE tb_cfg_data_asset SET  status=0  WHERE status=1 AND asset_id=:assetId",nativeQuery = true)
    void deleteByAssetId(@Param("assetId") String assetId);

    @Transactional
    @Modifying
    @Query(value = "UPDATE tb_cfg_data_asset SET collection_type= :collectioType ,  collection_method= :collectioMethod , url= :url , user_name= :userName , password= :password     WHERE id=:id ",nativeQuery = true)
    void updateCollectionInfo(@Param("id") String id ,@Param("collectioType") String collectioType ,@Param("collectioMethod") String collectioMethod,@Param("url") String url ,@Param("userName") String userName,@Param("password") String password  );
}
