package com.siemens.csde.simicas.jpa.repository;

import com.siemens.csde.simicas.jpa.entity.CfgLineStatusEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

/**
 * Line Status的Dao接口
 *
 * @author z0043y5h
 * @version 1.0-SNAPSHOT
 * @date 2020/2/11 17:21
 **/
@Repository
public interface CfgLineStatusRepository extends JpaRepository<CfgLineStatusEntity, String>,
        JpaSpecificationExecutor<CfgLineStatusEntity> {

}