package com.siemens.csde.simicas.jpa.repository;

import com.siemens.csde.simicas.jpa.entity.DataHandleStatusEntity;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

/**
 * DataHandleStatusRepository Status处理数据的Dao接口
 *
 * @author z0043y5h
 * @version 1.0-SNAPSHOT
 * @date 2020/3/20 11:46
 **/
@Repository
public interface DataHandleStatusRepository extends JpaRepository<DataHandleStatusEntity, String>,
        JpaSpecificationExecutor<DataHandleStatusEntity> {

    String INSERT_SQL = new StringBuffer("INSERT INTO tb_data_handle_status\n")
            .append("(id, data_time, data_value, line_id, station_id, start_time, end_time)\n")
            .append("VALUES(:id, :dataTime, :dataValue, :lineId, :stationId, :startTime, :endTime)").toString();

    @Query(value = "SELECT * FROM tb_data_handle_status WHERE line_id= :lineId  AND station_id = :stationId  AND end_time is null ORDER BY start_time DESC LIMIT 1", nativeQuery = true)
    Optional<DataHandleStatusEntity> findLastEntity(@Param("lineId") String lineId, @Param("stationId") String stationId);

}