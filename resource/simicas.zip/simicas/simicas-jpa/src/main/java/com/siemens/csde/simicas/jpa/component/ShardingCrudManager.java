package com.siemens.csde.simicas.jpa.component;


import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.annotation.PostConstruct;
import javax.sql.DataSource;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class ShardingCrudManager {

    private Connection connection;

    private PreparedStatement preparedStatement;

    private ResultSet resultSet;

    @Autowired()@Qualifier("sharding-dataSource")
    DataSource shardingDataSourceConfig;

    @PostConstruct
    private Connection getConnection() {
        try {
            connection = shardingDataSourceConfig.getConnection();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return connection;
    }

    public List<Map> queryByParam(String sql, Map<String,Object> param){

        List<Map> result = new ArrayList<>();

        try {
            List<String> paramKeys = getParamsKey(sql);
            sql = getFormatSql(sql);
            preparedStatement = connection.prepareStatement(sql);
            setStatementByMap(preparedStatement,paramKeys,param);
            resultSet = preparedStatement.executeQuery();
            result.addAll(convertToMap(resultSet));
        } catch (SQLException e) {
            e.printStackTrace();
        }    finally {
            close();
        }
        return result;
    }

    public Map queryByKey(String sql, Map<String,Object> param){

        Map result = new HashMap<>();

        try {
            List<String> paramKeys = getParamsKey(sql);
            sql = getFormatSql(sql);
            preparedStatement = connection.prepareStatement(sql);
            setStatementByMap(preparedStatement,paramKeys,param);
            resultSet = preparedStatement.executeQuery();
            List<Map<String,Object>> lists = convertToMap(resultSet);
            if (lists.size()>0){
                result  = lists.get(0);
            }

        }catch (SQLException e) {
            e.printStackTrace();
        } finally {
            close();
        }
        return result;
    }

    public int insert(String sql,Map map){

        int row = 0;

        try {
            executeUpdate(sql,map);
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            close();
        }
        return row;
    }

    public void insertBatch(String sql,List<Map> list){

        int row = 0;

        try {

            executeBatch(sql,list);
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            close();
        }
    }

    public int update(String sql,Map map){

        int row = 0;

        try {
            executeUpdate(sql,map);
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            close();
        }
        return row;
    }

    public int delete(String sql,Map map){

        int row = 0;

        try {
            executeUpdate(sql,map);
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            close();
        }
        return row;
    }



    private int executeUpdate(String sql,Map map) throws SQLException{

        List<String> paramKeys = getParamsKey(sql);
        sql = getFormatSql(sql);
        preparedStatement = connection.prepareStatement(sql);
        setStatementByMap(preparedStatement,paramKeys,map);
        int row = preparedStatement.executeUpdate();

        return row;
    }

    private void executeBatch(String sql,List<Map> list) throws SQLException{

        List<String> paramKeys = getParamsKey(sql);
        sql = getFormatSql(sql);
        preparedStatement = connection.prepareStatement(sql);
        connection.setAutoCommit(false);
        for (Map map :list){
            setStatementByMap(preparedStatement,paramKeys,map);
            preparedStatement.addBatch();
        }
        preparedStatement.executeBatch();
        connection.commit();

    }

    private  String matchTableName(String sql){

        Matcher matcher = Pattern
                .compile("\\s+(?i)from\\s+[\\w\\[\\]]*\\.?[\\w\\[\\]]*\\.?\\[?(\\b\\w+)\\]?[\\r\\n\\s]*")
                .matcher(sql);
        if (matcher.find()){
            return matcher.group(1);
        }
        return null;

    }

    private String getPrimaryKey(String table)throws SQLException {

        DatabaseMetaData metaData = connection.getMetaData();
        ResultSet pkRSet = metaData.getPrimaryKeys(null, "public", table);
        if (pkRSet.next()) {
            return pkRSet.getString(6);
        }

        return null;
    }

    private PreparedStatement setStatementByMap(PreparedStatement statement,
            List<String> paramKeys,
            Map<String,Object> param) throws SQLException{

        for (Map.Entry<String, Object> entry : param.entrySet()) {
            for (int i = 0; i< paramKeys.size();i++){
                if (StringUtils.equals(entry.getKey(),paramKeys.get(i).substring(1))){
                    statement.setObject(i+1,entry.getValue());
                }
            }
        }
        return statement;
    }

    private List<Map<String,Object>> convertToMap(ResultSet resultSet) throws SQLException{
        List<Map<String,Object>> list = new ArrayList<>();
        ResultSetMetaData md = resultSet.getMetaData();
        while (resultSet.next()) {
            Map<String, Object> map = new HashMap<>();
            for (int j = 1; j <= md.getColumnCount(); j++) {
                map.put(md.getColumnName(j), resultSet.getString(j));
            }
            list.add(map);
        }
        return list;
    }

    private List<String> getParamsKey(String sql){
        List<String> list = new ArrayList<>();
        String regex="\\:[a-zA-Z]+";
        Pattern r = Pattern.compile(regex);
        Matcher m = r.matcher(sql);
        while (m.find()){
            list.add(m.group());
        }
        return list;
    }

    private String getFormatSql(String str) {
        str = str.replaceAll(":[a-zA-Z]+", "?");
        return str;
    }



    private void close() {

        try {
            if (connection != null && !connection.isClosed()) {
                connection.close();
            }
            if (preparedStatement != null) {
                preparedStatement.close();
            }
            if (resultSet != null && !resultSet.isClosed()) {
                resultSet.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }





}
