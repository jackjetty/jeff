package com.siemens.csde.simicas.jpa.repository;

import com.siemens.csde.simicas.jpa.entity.DataOriginalEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

/**
 * DataOriginalRepository
 *
 * @author z004267r
 * @version 1.0-SNAPSHOT
 * @date 3/17/2020 3:50 PM
 **/
public interface DataOriginalRepository extends JpaRepository<DataOriginalEntity, String>,
        JpaSpecificationExecutor<DataOriginalEntity> {

    String INSERT_SQL = new StringBuffer("INSERT INTO tb_data_original \n")
            .append("(id, original_id, var_name, var_value) \n")
            .append("VALUES(:id, :originalId, :varName, :varValue)").toString();

}