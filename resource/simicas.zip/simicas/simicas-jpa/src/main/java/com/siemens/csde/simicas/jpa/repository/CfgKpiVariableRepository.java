package com.siemens.csde.simicas.jpa.repository;

import com.siemens.csde.simicas.jpa.entity.CfgKpiVariableEntity;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface CfgKpiVariableRepository extends JpaRepository<CfgKpiVariableEntity,String>, JpaSpecificationExecutor<CfgKpiVariableEntity> {

    List<CfgKpiVariableEntity> findByKpiIdEquals(String kpiId);

    @Query(value = "SELECT ckv.* FROM tb_cfg_kpi_variable ckv LEFT JOIN tb_cfg_kpi ck ON ckv.kpi_id=ck.id\n"
            + " WHERE ck.line_id= :lineId  AND ckv.status=1  ",nativeQuery = true)
    List<CfgKpiVariableEntity> findByLineId(@Param("lineId") String lineId );

    @Query(value = "SELECT ckv.* FROM tb_cfg_kpi_variable ckv LEFT JOIN tb_cfg_kpi ck ON ckv.kpi_id=ck.id\n"
            + " WHERE ck.line_id= :lineId AND ck.id=:kpiId AND ckv.status=1  ",nativeQuery = true)
    List<CfgKpiVariableEntity> findByLineIdAndKpiId(@Param("lineId") String lineId,@Param("kpiId") String kpiId );



}
