package com.siemens.csde.simicas.jpa.constant;

public interface DBConstant {

    Integer DB_STATUS_VALID = 1;

    Integer DB_STATUS_INVALID = 0;

    String DB_ORDER_ASC = "ASC";

    String DB_ORDER_DESC = "DESC";

}
