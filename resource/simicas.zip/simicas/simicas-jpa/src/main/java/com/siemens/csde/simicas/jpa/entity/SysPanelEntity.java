package com.siemens.csde.simicas.jpa.entity;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Index;
import javax.persistence.Table;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.hibernate.annotations.GenericGenerator;

/**
 * SysPanelEntity
 *
 * @author z0043y5h
 * @version 1.0-SNAPSHOT
 * @date 2020/3/12 14:26
 **/
@ToString
@Entity
@Setter
@Getter
@Table(name = "tb_sys_panel", schema = "public", indexes = {@Index(columnList = "create_user")})
public class SysPanelEntity {

    @Id
    @GenericGenerator(name = "idGenerator", strategy = "uuid")
    @GeneratedValue(generator = "idGenerator")
    private String id;

    @Column(name = "title")
    private String title;

    @Column(name = "resource_id")
    private String resourceId;

    @Column(name = "create_user", length = 64)
    private String createUser;

    @Column(name = "create_time")
    private Date createTime;

    @Column(name = "update_time")
    private Date updateTime;

    @Column(name = "status")
    private Integer status;
}
