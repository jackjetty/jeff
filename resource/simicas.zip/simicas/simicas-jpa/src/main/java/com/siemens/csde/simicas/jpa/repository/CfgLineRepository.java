package com.siemens.csde.simicas.jpa.repository;

import com.siemens.csde.simicas.jpa.entity.CfgLineEntity;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

/**
 * CfgLineRepository Production Line的Dao接口
 *
 * @author z0043y5h
 * @version 1.0-SNAPSHOT
 * @date 2020/2/11 17:21
 **/
@Repository
public interface CfgLineRepository extends JpaRepository<CfgLineEntity, String>,
        JpaSpecificationExecutor<CfgLineEntity> {

    Optional<CfgLineEntity> findById(String id);

    Optional<CfgLineEntity> findOneByAssetId(String assetId);

    Optional<CfgLineEntity> findByIdAndStatus(@Param("id") String id, @Param("status") Integer status);

    Optional<CfgLineEntity> findByAssetIdAndStatus(@Param("assetId") String assetId, @Param("status") Integer status);

    /**
     * 获取租户下从from到to（不含）的产线数据
     *
     * @param tenant 租户id
     * @param from   查询开始时间
     * @param to     查询结束时间
     * @return List<CfgLineEntity>
     * @author z0043y5h
     * @date 2020/2/11 17:21
     */
    @Query(value = "SELECT p FROM CfgLineEntity p WHERE p.tenant=:tenant AND p.createTime<:to "
            + "AND (p.status=1 OR p.updateTime>=:from) ORDER BY p.createTime")
    List<CfgLineEntity> findByTenantAndFromAndTo(@Param("tenant") String tenant, @Param("from") Date from,
            @Param("to") Date to);

    int countByTenantAndNameAndStatusAndIdNot(@Param("tenant") String tenant, @Param("name") String name,
            @Param("status") Integer status, @Param("id") String id);

    CfgLineEntity findByIdAndTenantAndStatus(String id, String tenant, Integer status);

    @Query(value = "SELECT COUNT(1) FROM CfgLineEntity p WHERE p.tenant=:tenant AND p.status=:status AND p.id IN(:ids)")
    int countByTenantAndStatus(@Param("tenant") String tenant, @Param("status") Integer status,
            @Param("ids") Set<String> ids);

    List<CfgLineEntity> findByStatus(@Param("status") Integer status);
}