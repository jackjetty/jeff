package com.siemens.csde.simicas.jpa.entity;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.hibernate.annotations.GenericGenerator;

@Entity
@Setter
@Getter
@ToString
@Table(name = "tb_data_collect_eff", schema = "public")
public class DataCollectEFFEntity {

    @Id
    @GenericGenerator(name="idGenerator", strategy="uuid")
    @GeneratedValue(generator="idGenerator")
    private String id;

    @Column(name = "line_id",  length = 50 )
    private String lineId;

    @Column(name = "product_id",  length = 50 )
    private String productId;

    @Column(name = "order_id",  length = 50 )
    private String orderId;

    @Column(name = "station_id",  length = 50 )
    private String stationId;

    @Column(name = "batch_id",  length = 50 )
    private String batchId;

    @Column(name = "statistic_time" )
    private Date statisticTime;

    @Column(name = "save_time" )
    private Date saveTime;

    @Column(name = "ict" )
    private Double ict;

    @Column(name = "start_output" )
    private Integer startOutput;

    @Column(name = "start_time" )
    private Date startTime;

    @Column(name = "end_output" )
    private Integer endOutput;

    @Column(name = "end_time" )
    private Date endTime;

    @Column(name = "error_code" )
    private Integer errorCode;

    @Column(name = "eff" )
    private Double eff;

    @Column(name = "pb_id" ,length = 50)
    private String pbId;

}