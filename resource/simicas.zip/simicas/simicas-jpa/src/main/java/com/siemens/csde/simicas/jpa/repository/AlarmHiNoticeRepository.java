package com.siemens.csde.simicas.jpa.repository;

import com.siemens.csde.simicas.jpa.entity.AlarmHiNoticeEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

@Repository
public interface AlarmHiNoticeRepository extends JpaRepository<AlarmHiNoticeEntity, String>,
        JpaSpecificationExecutor<AlarmHiNoticeEntity> {

}