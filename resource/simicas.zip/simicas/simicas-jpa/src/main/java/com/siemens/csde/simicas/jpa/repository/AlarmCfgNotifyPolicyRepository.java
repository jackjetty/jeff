package com.siemens.csde.simicas.jpa.repository;

import com.siemens.csde.simicas.jpa.entity.AlarmCfgNotifyPolicyEntity;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface AlarmCfgNotifyPolicyRepository extends JpaRepository<AlarmCfgNotifyPolicyEntity,String>, JpaSpecificationExecutor<AlarmCfgNotifyPolicyEntity> {

    
    @Query(value = "SELECT * FROM tb_alarm_cfg_notify_policy WHERE tenant= :tenant AND line_id= :lineId AND kpi= :kpi AND status= :status LIMIT 1", nativeQuery = true)
    Optional<AlarmCfgNotifyPolicyEntity> findByTenantAndLineIdAndKpiAndStatus(@Param("tenant") String tenant, @Param("lineId") String lineId,@Param("kpi") String kpi,@Param("status") Integer status);


    Optional<AlarmCfgNotifyPolicyEntity> findById(@Param("id") String id);

    List<AlarmCfgNotifyPolicyEntity> findByTenantAndLineIdAndStatusOrderByKpi(@Param("tenant") String tenant, @Param("lineId") String lineId,@Param("status") Integer status);

}
