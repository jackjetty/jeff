package com.siemens.csde.simicas.jpa.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.hibernate.annotations.GenericGenerator;

/**
 * DataOriginalMainEntity
 *
 * @author z004267r
 * @version 1.0-SNAPSHOT
 * @date 3/17/2020 3:28 PM
 **/
@Entity
@Setter
@Getter
@ToString
@Table(name = "tb_data_original", schema = "public")
public class DataOriginalEntity {

    @Id
    @GenericGenerator(name="idGenerator", strategy="uuid")
    @GeneratedValue(generator="idGenerator")
    private String id;

    @Column(name = "original_id",  length = 64 )
    private String originalId;

    @Column(name = "data_name")
    private String dataName;

    @Column(name = "data_value")
    private String dataValue;

}
