package com.siemens.csde.simicas.jpa.repository;

import com.siemens.csde.simicas.jpa.entity.SysUserCompareEntity;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

/**
 * SysUserCompareRepository UserCompare的Dao接口
 *
 * @author z0043y5h
 * @version 1.0-SNAPSHOT
 * @date 2020/3/19 18:01
 **/
@Repository
public interface SysUserCompareRepository extends JpaRepository<SysUserCompareEntity, String>,
        JpaSpecificationExecutor<SysUserCompareEntity> {

    boolean existsByCreateUser(String createUser);

    boolean existsByIdAndCreateUser(String id, String createUser);

    Optional<SysUserCompareEntity> findByIdAndCreateUser(String id, String createUser);

    SysUserCompareEntity findByCreateUser(String createUser);
}