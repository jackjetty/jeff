package com.siemens.csde.simicas.jpa.entity;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.Immutable;

@Immutable
@Entity
@Table(name="v_kpi_fpy")
@Setter
@Getter
public class VKpiFPYEntity {

    @Id
    @Column(name = "original_id",length = 50)
    private String originalId;

    @Column(name = "line_id",length = 50)
    private String lineId;

    @Column(name = "station_id")
    private String stationId;

    @Column(name = "kpi",length = 64)
    private String kpi;

    @Column(name = "data_time")
    private Date dataTime;

    @Column(name = "save_time")
    private Date saveTime;

    @Column(name = "last_pid",length = 50)
    private String lastPid;

    @Column(name = "defect",length = 50)
    private String defect;

    @Column(name = "total",length = 50)
    private String total;

    @Column(name = "fpy",length = 50)
    private String fpy;

    @Column(name = "product_id",length = 50)
    private String productId;

    @Column(name = "batch_id",length = 50)
    private String batchId;

    @Column(name = "order_id",length = 50)
    private String orderId;

}
