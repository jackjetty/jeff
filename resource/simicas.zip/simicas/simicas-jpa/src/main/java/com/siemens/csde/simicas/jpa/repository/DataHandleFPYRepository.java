package com.siemens.csde.simicas.jpa.repository;

import com.siemens.csde.simicas.jpa.entity.DataHandleFPYEntity;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

/**
 * DataHandleFPYRepository  FPY处理数据的Dao接口
 *
 * @author z0043y5h
 * @version 1.0-SNAPSHOT
 * @date 2020/3/20 11:52
 **/
@Repository
public interface DataHandleFPYRepository extends JpaRepository<DataHandleFPYEntity, String>,
        JpaSpecificationExecutor<DataHandleFPYEntity> {

    String INSERT_SQL = new StringBuffer("INSERT INTO tb_data_handle_fpy\n")
            .append("(id, batch_id, data_time, data_value, defect, end_time, line_id, order_id, product_id, start_time, station_id, total)\n")
            .append("VALUES(:id, :batchId, :dataTime, :dataValue, :defect, :endTime, :lineId, :orderId, :productId, :startTime, :stationId, :total)").toString();

    @Query(value = "SELECT * FROM tb_data_handle_fpy WHERE line_id= :lineId  AND station_id = :stationId  AND end_time is null ORDER BY start_time DESC LIMIT 1", nativeQuery = true)
    Optional<DataHandleFPYEntity> findLastEntity(@Param("lineId") String lineId, @Param("stationId") String stationId);

}