package com.siemens.csde.simicas.jpa.entity;

import lombok.Getter;
import lombok.Setter;
@Getter
@Setter
public class TrCollectDefectEntity {

    private String id;
    private String lineId;
    private String productId;
    private String stationId;
    private String statisticTime;
    private Long defect;

}