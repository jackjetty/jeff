package com.siemens.csde.simicas.jpa.util;


import com.alibaba.druid.util.JdbcUtils;
import com.siemens.csde.simicas.common.constant.RedisKeyConstant;
import com.siemens.csde.simicas.common.util.RedisUtil;
import com.siemens.csde.simicas.jpa.config.ShardingDataSourceConfig;
import com.siemens.csde.simicas.jpa.shardingjdbc.constant.ShardingConstant;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import javax.sql.DataSource;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * ShardingUtils
 *
 * @author z0043y5h
 * @version 1.0-SNAPSHOT
 * @date 2019/11/1 16:43
 **/
@Slf4j
@Component
public class ShardingUtil {

    @Autowired
    RedisUtil redisUtil;

    private static final String SQL_WHERE = " WHERE ";

    private static final String SQL_AND = " AND ";

    private static final String SQL_EQUALS = "=";

    private static final String QUERY_REFER_TABLE_EXPR = "SELECT DISTINCT %s FROM %s";

    /* 复制表及表结构sql模板 */
    private static final String CREATE_TABLE_SQL_EXP = "CREATE TABLE IF NOT EXISTS %s(LIKE %s INCLUDING INDEXES INCLUDING COMMENTS )";

    public Map<String, List<String>> loadShardingTables(DataSource dataSource) {

        Map<String, List<String>> logic2ActualTablesMap = new HashMap<>();
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet resultSet = null;
        try {
            conn = dataSource.getConnection();
            stmt = conn.prepareStatement(ShardingConstant.SHARDING_TABLE_NAMES_SQL);
            resultSet = stmt.executeQuery();

            while (resultSet.next()) {
                String actualTable = resultSet.getString(1);
                String logicTable = actualTable.substring(0, actualTable.lastIndexOf(ShardingConstant.TABLE_TENANT_SEPARATOR));

                if (!logic2ActualTablesMap.containsKey(logicTable)) {
                    List<String> newList = new ArrayList<>();
                    newList.add(actualTable);
                    logic2ActualTablesMap.put(logicTable, newList);
                } else {
                    logic2ActualTablesMap.get(logicTable).add(actualTable);
                }

            }
            redisUtil.set(RedisKeyConstant.SHARDING_TABLES, logic2ActualTablesMap);
        } catch (Exception e) {
            log.error("get all tableNames failed.", e);
        } finally {
            JdbcUtils.close(resultSet);
            JdbcUtils.close(stmt);
            JdbcUtils.close(conn);
        }
        return logic2ActualTablesMap;

    }

    public void loadShardingColumn(DataSource dataSource) {

        Map<String, List<String>> tenant2lineMap = new HashMap<>();
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet resultSet = null;

        try {
            conn = dataSource.getConnection();
            stmt = conn.prepareStatement(ShardingConstant.SHARDING_COLUMN_MAPPING_SQL);
            resultSet = stmt.executeQuery();
            while (resultSet.next()) {
                String tenantId = resultSet.getString(2);
                String lineId = resultSet.getString(1);

                if (!tenant2lineMap.containsKey(tenantId)) {
                    List<String> newList = new ArrayList<>();
                    newList.add(lineId);
                    tenant2lineMap.put(tenantId, newList);
                } else {
                    tenant2lineMap.get(tenantId).add(lineId);
                }

            }
            redisUtil.set(RedisKeyConstant.SHARDING_COLUMNS, tenant2lineMap);
        } catch (Exception e) {
            log.error("get all tableNames failed.", e);
        } finally {
            JdbcUtils.close(resultSet);
            JdbcUtils.close(stmt);
            JdbcUtils.close(conn);
        }
    }


    /**
     * 创建物理表并刷新分表逻辑
     *
     * @param dataSource dataSource
     * @param existsPhysicsTable existsPhysicsTable
     * @param physicsTable physicsTable
     * @param shardingJDBCConfig shardingJDBCConfig
     * @return boolean
     * @author z0043y5h
     * @date 2019/11/8 16:02
     **/
    public synchronized boolean createTableAndFlushDataSource(DataSource dataSource, String existsPhysicsTable,
            String physicsTable, ShardingDataSourceConfig shardingJDBCConfig) {
        try {
            boolean success = createTable(dataSource, physicsTable, existsPhysicsTable);
            if (success) {
                addNewTable(physicsTable, physicsTable, shardingJDBCConfig);
            }
            return true;
        } catch (Exception e) {
            log.error("create table failed. tableName=" + physicsTable, e);
            return false;
        }

    }

    private void addNewTable(String logicTable, String actualTable, ShardingDataSourceConfig shardingJDBCConfig) throws Exception {
        Map<String, List<String>> logic2ActualTablesMap;
        List<String> actualTables = new ArrayList<>();
        Object object = redisUtil.get(RedisKeyConstant.SHARDING_TABLES);
        if (object != null) {
            logic2ActualTablesMap = (Map<String, List<String>>) object;
            actualTables.addAll(logic2ActualTablesMap.get(logicTable));
            if (actualTables.contains(actualTable)) {
                return;
            }
        } else {
            logic2ActualTablesMap = new HashMap<>();
        }

        actualTables.add(actualTable);
        logic2ActualTablesMap.put(logicTable, actualTables);

        shardingJDBCConfig.flushDataSource(actualTable); // 刷新数据源对象，将物理表加入分表规则中

    }

    /**
     * 建表并刷新资源对象
     *
     * @param dataSource dataSource
     * @param table      table
     * @return java.lang.String
     * @author z0043y5h
     * @date 2019/11/4 10:36
     **/
    /*public static void cacheReferTableDatas(DataSource dataSource, ReferTableModel table) throws SQLException {
        for (Entry<String, ConcurrentHashMap<String, String>> referKeyReferColumns :
                table.getSharingColumnReferColumnsMap().entrySet()) {
            String selectKeys = referKeyReferColumns.getKey();
            String sql = String.format(QUERY_REFER_TABLE_EXPR, selectKeys, table.getTableName());
            Map<String, String> tableKeyValues = queryTableData(dataSource.getConnection(), sql, selectKeys);
            referKeyReferColumns.getValue().putAll(tableKeyValues);
        }
    }*/

    /**
     * 建表并刷新资源对象
     *
     * @param dataSource dataSource
     * @param table      table
     * @param selectKeys selectKeys
     * @param params     params
     * @return java.lang.String
     * @author z0043y5h
     * @date 2019/11/4 10:36
     **/
    /*public static String queryOneReferTableData(DataSource dataSource, ReferTableModel table,
            String selectKeys, Map<String, String> params) {
        try {
            String tableName = table.getTableName();
            String sqlNoWhere = String.format(QUERY_REFER_TABLE_EXPR, selectKeys, tableName);
            StringBuilder sqlSB = new StringBuilder(sqlNoWhere).append(SQL_WHERE);
            params.entrySet().forEach(param -> {
                sqlSB.append(param.getKey()).append(SQL_EQUALS).append(param.getValue()).append(SQL_AND);
            });
            String sql = sqlSB.substring(0, sqlSB.length() - SQL_AND.length());
            Map<String, String> tableKeyValues = queryTableData(dataSource.getConnection(), sql, selectKeys);
            return tableKeyValues.isEmpty() ? null : tableKeyValues.values().iterator().next();
        } catch (Exception e) {
            log.error("error occured when query one referTableData.", e);
            return null;
        }
    }*/

    /**
     * 查询指定sql，并将查询结果封装到map中
     *
     * @param conn             conn
     * @param sql              查询sql
     * @param selectColumnsStr sql查询字段序列
     * @return java.util.Map<java.lang.String, java.lang.String>
     * @author z0043y5h
     * @date 2019/11/8 16:01
     **/
    /*private static Map<String, String> queryTableData(Connection conn, String sql,
            String selectColumnsStr) throws SQLException {
        String[] selectColumns = selectColumnsStr.split(ShardingConstant.TABLE_COLUMN_SEPARATOR);
        Statement stmt = null;
        ResultSet rs = null;
        try {
            stmt = conn.createStatement();
            rs = stmt.executeQuery(sql);
            Map<String, String> tableKeyValues = new HashMap<>(rs.getFetchSize());
            while (rs.next()) {
                StringBuilder tableKeys = new StringBuilder();
                int i = 0;
                for (; i < selectColumns.length - 1; i++) {
                    tableKeys.append(rs.getString(selectColumns[i])).append(ShardingConstant.TABLE_KEY_SEPARATOR);
                }
                tableKeyValues.put(tableKeys.toString(), rs.getString(selectColumns[i]));
            }
            log.info("query refer table success! sql=" + sql);
            return tableKeyValues;
        } catch (SQLException e) {
            log.error("query refer table failed! sql=" + sql);
            throw e;
        } finally {
            JdbcUtils.close(rs);
            JdbcUtils.close(stmt);
            JdbcUtils.close(conn);
        }
    }*/


    /**
     * 建表并刷新资源对象
     *
     * @param dataSource dataSource
     * @param physicsTable physicsTable
     * @param existsPhysicsTable 已存在的，映射到同一个物理表下的逻辑表，以该表结构为模板创建physicsTable
     * @return java.lang.String
     * @author z0043y5h
     * @date 2019/11/4 10:36
     **/
    public static boolean createTable(DataSource dataSource, String physicsTable, String existsPhysicsTable) {
        String createSql = String.format(CREATE_TABLE_SQL_EXP, physicsTable, existsPhysicsTable);

        Connection conn = null;
        Statement stmt = null;
        boolean success = false;
        try {
            conn = dataSource.getConnection();
            stmt = conn.createStatement();
            stmt.executeUpdate(createSql);
            success = true;
            log.info("create table success! tableName=" + physicsTable);
        } catch (Exception e) {
            log.info("create table failed! tableName=" + physicsTable, e);
        } finally {
            JdbcUtils.close(stmt);
            JdbcUtils.close(conn);
        }
        return success;
    }

    /**
     * 解析所有数据源url地址，缓存到新的容器中
     *
     * @param dataSourceMap dataSourceMap
     * @return Map<String, String>
     * @author z0043y5h
     * @date 2019/11/1 16:50
     **/
    public static Map<String, String> getDataSourceURLs(final Map<String, DataSource> dataSourceMap)
            throws SQLException {
        Map<String, String> result = new LinkedHashMap<>(dataSourceMap.size(), 1);
        for (Entry<String, DataSource> entry : dataSourceMap.entrySet()) {
            DataSource dataSource = entry.getValue();
            try (Connection connection = dataSource.getConnection()) {
                String url = connection.getMetaData().getURL();
                result.put(entry.getKey(), url);
            }
        }
        return result;
    }

    public String getTenant(String shardingValue) {

        Map<String, List<String>> tenant2lineMap;
        Object object = redisUtil.get(RedisKeyConstant.SHARDING_COLUMNS);
        if (object != null) {
            tenant2lineMap = (Map<String, List<String>>) object;
            for (String tenant : tenant2lineMap.keySet()){
                if (tenant2lineMap.get(tenant).contains(shardingValue)){
                    return tenant;
                }
            }

        }
        return null;

    }
}
