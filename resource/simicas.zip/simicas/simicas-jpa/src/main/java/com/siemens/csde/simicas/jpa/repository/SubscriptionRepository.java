package com.siemens.csde.simicas.jpa.repository;

import com.siemens.csde.simicas.common.constant.enums.SubTypeEnum;
import com.siemens.csde.simicas.jpa.entity.SubscriptionEntity;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

@Repository
public interface SubscriptionRepository extends JpaRepository<SubscriptionEntity, String>,
        JpaSpecificationExecutor<SubscriptionEntity> {

    Optional<SubscriptionEntity> findById(String id);

    Optional<SubscriptionEntity> findByUserIdAndDestination(String userId, String destination);

    List<SubscriptionEntity> findBySubType(SubTypeEnum subType);
}
