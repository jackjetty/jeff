package com.siemens.csde.simicas.jpa.repository;

import com.siemens.csde.simicas.jpa.entity.DataHandleEntity;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

/**
 * DataHandleRepositoty
 *
 * @author z004267r
 * @version 1.0-SNAPSHOT
 * @date 3/17/2020 3:50 PM
 **/
public interface DataHandleRepository extends JpaRepository<DataHandleEntity, String>,
        JpaSpecificationExecutor<DataHandleEntity> {

    String INSERT_SQL = new StringBuffer("INSERT INTO tb_data_handle \n")
            .append("(id, tenant_id, line_id, station_id, kpi, data_value, data_time, save_time) \n")
            .append("VALUES(:id, :tenantId, :lineId, stationId, :kpi, :dataValue, :dataTime, :saveTime)").toString();

    @Query(value = "SELECT *  FROM tb_data_handle WHERE line_id= :lineId  AND station_id = :stationId  AND kpi = :kpi ORDER BY data_time DESC LIMIT 1", nativeQuery = true)
    Optional<DataHandleEntity> findLastestEntity(@Param("lineId") String lineId, @Param("stationId") String orderId,@Param("kpi") String productId);


}