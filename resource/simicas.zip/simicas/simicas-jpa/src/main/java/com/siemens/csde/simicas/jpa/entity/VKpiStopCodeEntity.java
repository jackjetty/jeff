package com.siemens.csde.simicas.jpa.entity;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.Immutable;

@Immutable
@Entity
@Table(name="v_kpi_stopcode")
@Setter
@Getter
public class VKpiStopCodeEntity {

    @Id
    @Column(name = "original_id",length = 50)
    private String originalId;

    @Column(name = "line_id",length = 50)
    private String lineId;

    @Column(name = "station_id")
    private String stationId;

    @Column(name = "kpi",length = 64)
    private String kpi;

    @Column(name = "data_time")
    private Date dataTime;

    @Column(name = "save_time")
    private Date saveTime;

    @Column(name = "stop_code",length = 50)
    private String stopCode;

    @Column(name = "batch_id",length = 50)
    private String batchId;

    @Column(name = "order_id",length = 50)
    private String orderId;

}
