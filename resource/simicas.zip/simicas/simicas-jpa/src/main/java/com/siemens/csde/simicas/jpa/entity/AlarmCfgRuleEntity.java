package com.siemens.csde.simicas.jpa.entity;

import java.util.Date;
import java.util.List;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Type;
@Entity
@Setter
@Getter
@Table(name="tb_alarm_cfg_rule",schema = "public")
public class AlarmCfgRuleEntity {
    @Id
    @GenericGenerator(name="idGenerator", strategy="uuid")
    @GeneratedValue(generator="idGenerator")
    private String id;


    @Column(name = "alarm_level"  )
    private String alarmLevel;

    @Column(name = "expression"  )
    private String expression;

    @Column(name = "highlight"   )
    @Type(type="org.hibernate.type.NumericBooleanType")
    private Boolean highlight;

    @Column(name = "notify_email"   )
    @Type(type="org.hibernate.type.NumericBooleanType")
    private Boolean notifyEmail;

    @Column(name = "notify_web" )
    @Type(type="org.hibernate.type.NumericBooleanType")
    private Boolean notifyWeb;

    @Column(name = "notify_sms"  )
    @Type(type="org.hibernate.type.NumericBooleanType")
    private Boolean notifySms;

    @Column(name = "kpi", length = 50)
    private String kpi;

    @Column(name = "tenant", length = 50,nullable = false)
    private String tenant;

    @Column(name = "line_id", length = 50,nullable = false)
    private String lineId;

    @Column(name = "status"  )
    private Integer status;

    @Column(name = "create_user_id"  )
    private String createUserId;

    @Column(name = "create_time"  )
    private Date createTime;

    @Column(name = "update_user_id"  )
    private String updateUserId;

    @Column(name = "update_time"  )
    private Date updateTime;

    @Transient
    private List<String> emailAddresses;

}