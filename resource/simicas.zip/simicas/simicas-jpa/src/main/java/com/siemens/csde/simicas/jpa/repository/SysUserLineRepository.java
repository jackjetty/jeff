package com.siemens.csde.simicas.jpa.repository;

import com.siemens.csde.simicas.jpa.entity.SysUserLineEntity;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

/**
 * SysUserLineRepository
 *
 * @author z0043y5h
 * @version 1.0-SNAPSHOT
 * @date 2020/2/26 1:03
 **/
@Repository
public interface SysUserLineRepository extends JpaRepository<SysUserLineEntity, String>,
        JpaSpecificationExecutor<SysUserLineEntity> {

    String NSQL_USERLINES_USERID_DIS =
            "SELECT DISTINCT l.id AS \"lineId\",l.name AS \"lineName\",ul.user_id AS \"userId\",ul.kpi_name AS \"kpiName\" "
                    + "FROM tb_cfg_line l "
                    + "INNER JOIN tb_sys_user_line ul ON l.status=1 AND l.tenant=:tenant AND l.id=ul.line_id AND ul.status=1 AND ul.user_id=:userId "
                    + "ORDER BY \"lineId\" ";

    List<SysUserLineEntity> findByUserIdAndKpiNameAndStatus(String userId, String kpiName, Integer status);
}
