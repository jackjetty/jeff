package com.siemens.csde.simicas.jpa.repository;

import com.siemens.csde.simicas.jpa.entity.SysFeedbackEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

/**
 * SysFeedbackRepository Feedback的Dao接口
 *
 * @author z0043y5h
 * @version 1.0-SNAPSHOT
 * @date 2020/3/19 18:05
 **/
@Repository
public interface SysFeedbackRepository extends JpaRepository<SysFeedbackEntity, String>,
        JpaSpecificationExecutor<SysFeedbackEntity> {

    String NSQL_FEEDBACKS =
            "SELECT f.id AS \"id\",f.type AS \"type\",f.title AS \"title\",f.content AS \"content\",f.status AS \"status\","
                    + "f.create_user AS \"createUser\" ,f.create_time AS \"createTime\",u.name AS \"userName\",u.email AS \"email\" "
                    + "FROM tb_sys_feedback f LEFT JOIN tb_sys_user u ON f.create_user=u.id "
                    + "WHERE f.create_time>= :from AND f.create_time<= :to "
                    + "ORDER BY \"createUser\" DESC ";
}
