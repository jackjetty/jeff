package com.siemens.csde.simicas.jpa.repository;

import com.siemens.csde.simicas.jpa.entity.CfgKpiFormulaParamEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

@Repository
public interface CfgKpiFormulaParamRepository extends JpaRepository<CfgKpiFormulaParamEntity,String>, JpaSpecificationExecutor<CfgKpiFormulaParamEntity> {

}
