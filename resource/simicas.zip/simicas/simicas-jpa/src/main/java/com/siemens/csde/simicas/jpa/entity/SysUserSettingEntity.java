package com.siemens.csde.simicas.jpa.entity;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Index;
import javax.persistence.Table;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.hibernate.annotations.GenericGenerator;

/**
 * SysUserSettingEntity
 *
 * @author z0043y5h
 * @version 1.0-SNAPSHOT
 * @date 2020/3/12 11:17
 **/
@ToString
@Entity
@Setter
@Getter
@Table(name = "tb_sys_user_setting", schema = "public",
        indexes = {@Index(columnList = "create_user")})
public class SysUserSettingEntity {

    @Id
    @GenericGenerator(name = "idGenerator", strategy = "uuid")
    @GeneratedValue(generator = "idGenerator")
    private String id;

    @Column(name = "create_user", length = 64)
    private String createUser;

    @Column(name = "part_type", length = 64)
    private String partType;

    @Column(name = "setting_type")
    private String settingType;

    @Column(name = "setting_code")
    private String settingCode;

    @Column(name = "setting_value")
    private String settingValue;

    @Column(name = "parent_id", length = 64)
    private String parentId;

    @Column(name = "create_time")
    private Date createTime;

    @Column(name = "update_time")
    private Date updateTime;

    @Column(name = "status")
    private Integer status;
}
