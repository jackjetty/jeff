package com.siemens.csde.simicas.jpa.entity;

import lombok.Getter;
import lombok.Setter;
@Getter
@Setter
public class TrCollectPlanEntity {

    private String statisticTime;
    private Long quantityCount;

}