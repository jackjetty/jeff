package com.siemens.csde.simicas.jpa.repository;

import com.siemens.csde.simicas.jpa.entity.SysPanelEntity;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.repository.query.Param;

/**
 * SysPanelRepository 接口
 *
 * @author z0043y5h
 * @version 1.0-SNAPSHOT
 * @date 2020/3/12 14:25
 **/
public interface SysPanelRepository extends JpaRepository<SysPanelEntity, String>,
        JpaSpecificationExecutor<SysPanelEntity> {

    Optional<SysPanelEntity> findByStatusAndIdAndCreateUser(@Param("status") Integer status, @Param("id") String id,
            @Param("createUser") String createUser);
}
