package com.siemens.csde.simicas.jpa.repository;

import com.siemens.csde.simicas.jpa.entity.DataOriginalMainEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

/**
 * DataOriginalMainRepository
 *
 * @author z004267r
 * @version 1.0-SNAPSHOT
 * @date 3/17/2020 3:51 PM
 **/
public interface DataOriginalMainRepository extends JpaRepository<DataOriginalMainEntity, String>,
        JpaSpecificationExecutor<DataOriginalMainEntity> {

    String INSERT_SQL = new StringBuffer("INSERT INTO tb_data_original_main \n")
            .append("(id, line_id,station_id, kpi, data_time, save_time) \n")
            .append("VALUES(:id, :lineId, stationId, :kpi, :dataTime, saveTime)").toString();

}