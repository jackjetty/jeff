package com.siemens.csde.simicas.jpa.entity;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.hibernate.annotations.GenericGenerator;

@ToString
@Entity
@Setter
@Getter
@Table(name = "tb_data_handle_eff", schema = "public")
public class DataHandleEFFEntity {

    @Id
    @GenericGenerator(name = "idGenerator", strategy = "uuid")
    @GeneratedValue(generator = "idGenerator")
    private String id;

    @Column(name = "line_id", length = 64)
    private String lineId;

    @Column(name = "station_id", length = 50)
    private String stationId;

    @Column(name = "data_value")
    private Double dataValue;

    @Column(name = "ict",length = 64)
    private Double ict;

    @Column(name = "act",length = 64)
    private Double act;

    @Column(name = "data_unit", length = 64)
    private String dataUnit;

    @Column(name = "error_code")
    private Integer errorCode;

    @Column(name = "data_time")
    private Date dataTime;

    @Column(name = "product_id",length = 64)
    private String productId;

    @Column(name = "order_id",length = 64)
    private String orderId;

    @Column(name = "batch_id",length = 64)
    private String batchId;
}
