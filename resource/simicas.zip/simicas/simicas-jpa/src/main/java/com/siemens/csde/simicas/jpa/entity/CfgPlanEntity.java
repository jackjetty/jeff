package com.siemens.csde.simicas.jpa.entity;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Index;
import javax.persistence.Table;
import javax.persistence.Transient;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.hibernate.annotations.GenericGenerator;

@ToString
@Entity
@Setter
@Getter
@Table(name = "tb_cfg_plan", schema = "public",
        indexes = {@Index(columnList = "line_id")})
public class CfgPlanEntity {

    @Id
    @GenericGenerator(name = "idGenerator", strategy = "uuid")
    @GeneratedValue(generator = "idGenerator")
    private String id;

    @Column(name = "plan_date", nullable = false)
    private Date planDate;

    @Column(name = "quantity", nullable = false)
    private Integer quantity;

    @Column(name = "product_id", nullable = false)
    private String productId;

    @Column(name = "line_id", nullable = false)
    private String lineId;

    @Column(name = "status")
    private Integer status;

    @Column(name = "create_user_id")
    private String createUserId;

    @Column(name = "update_user_id")
    private String updateUserId;

    @Column(name = "create_time")
    private Date createTime;

    @Column(name = "update_time")
    private Date updateTime;

    @Transient
    private String productName;
}
