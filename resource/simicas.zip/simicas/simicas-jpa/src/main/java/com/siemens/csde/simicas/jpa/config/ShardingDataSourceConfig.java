package com.siemens.csde.simicas.jpa.config;


import com.siemens.csde.simicas.common.util.RedisUtil;
import com.siemens.csde.simicas.jpa.shardingjdbc.algorithm.PreciseModuloShardingTableAlgorithm;
import com.siemens.csde.simicas.jpa.shardingjdbc.constant.ShardingConstant;
import com.siemens.csde.simicas.jpa.util.ShardingUtil;
import java.lang.reflect.Field;
import java.sql.DatabaseMetaData;
import java.sql.SQLException;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.stream.Collectors;
import javax.sql.DataSource;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.shardingsphere.api.config.sharding.ShardingRuleConfiguration;
import org.apache.shardingsphere.api.config.sharding.TableRuleConfiguration;
import org.apache.shardingsphere.api.config.sharding.strategy.StandardShardingStrategyConfiguration;
import org.apache.shardingsphere.core.constant.properties.ShardingPropertiesConstant;
import org.apache.shardingsphere.core.execute.metadata.TableMetaDataInitializer;
import org.apache.shardingsphere.core.metadata.datasource.ShardingDataSourceMetaData;
import org.apache.shardingsphere.core.metadata.table.TableMetaData;
import org.apache.shardingsphere.core.rule.ShardingRule;
import org.apache.shardingsphere.core.rule.TableRule;
import org.apache.shardingsphere.shardingjdbc.jdbc.core.ShardingContext;
import org.apache.shardingsphere.shardingjdbc.jdbc.core.datasource.ShardingDataSource;
import org.apache.shardingsphere.shardingjdbc.jdbc.metadata.JDBCTableMetaDataConnectionManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;


@Slf4j
@Configuration
public class ShardingDataSourceConfig {

    @Autowired
    private ShardingUtil shardingUtils;

    @Autowired
    private DruidDataSourceConfig druidDataSourceConfig;

    @Autowired
    RedisUtil redisUtil;

    @Autowired
    PreciseModuloShardingTableAlgorithm preciseModuloShardingTableAlgorithm;

    // 产生dataSource后，缓存该实例，动态建表时对其维护
    private ShardingDataSource shardingDataSource;

    //
    private Map<String, DataSource> dataSourceMap = new HashMap<>(1);

    private DataSource dataSource ;


    @Bean(name = "sharding-dataSource")
    public DataSource getDataSource() throws SQLException {
        synchronized (this) {
            dataSource = druidDataSourceConfig.getDataSource();
            dataSourceMap.put(druidDataSourceConfig.getDsname(), dataSource);

            Map<String, List<String>> logic2ActualTablesMap = shardingUtils.loadShardingTables(dataSource);
            shardingUtils.loadShardingColumn(dataSource);

            ShardingRuleConfiguration shardingRuleConfiguration = new ShardingRuleConfiguration();
            logic2ActualTablesMap.keySet().forEach(
                    tableName ->
                    {
                        List<String> tableNodes = logic2ActualTablesMap.get(tableName).stream()
                                .map(physicsTable -> druidDataSourceConfig.getDsname() + ShardingConstant.DB_TABLE_SEPARATOR + physicsTable)
                                .collect(Collectors.toList());
                        String tableNodesStr = StringUtils.join(tableNodes, ShardingConstant.SHARDING_TABLE_SEPARATOR);

                        TableRuleConfiguration tableRuleConfiguration = new TableRuleConfiguration(tableName, tableNodesStr);

                        shardingRuleConfiguration.getTableRuleConfigs().add(tableRuleConfiguration);
                    });

            // 配置分片规则
            shardingRuleConfiguration.setDefaultTableShardingStrategyConfig(
                    new StandardShardingStrategyConfiguration(ShardingConstant.SHARDING_DEFAULT_COLUMN, preciseModuloShardingTableAlgorithm));

            ShardingRule shardingRule = new ShardingRule(shardingRuleConfiguration, dataSourceMap.keySet());
            Properties prop = new Properties();
            prop.setProperty("sql.show", "true");
            shardingDataSource = new ShardingDataSource(dataSourceMap, shardingRule, prop);
            return shardingDataSource;
        }
    }

    /**
     * 刷新数据源对象，将物理表加入分表规则中
     *
     * @param physicsTable 新增物理表名称
     * @return void
     * @author z0043y5h
     * @date 2019/11/1 15:49
     **/
    public void flushDataSource(String physicsTable) throws SQLException, IllegalAccessException {
        // 获取逻辑表名称
        String logicTable = StringUtils.substringBefore(physicsTable, ShardingConstant.TABLE_TENANT_SEPARATOR);

        // 数据源实例中的各属性对象，需做相应修改
        ShardingContext shardingContext = shardingDataSource.getShardingContext();
        ShardingRuleConfiguration shardingRuleConfig = shardingContext.getShardingRule().getShardingRuleConfig();

        // shardingContext -> ShardingRule -> shardingRuleConfig
        flushShardingRuleConfig(shardingRuleConfig, logicTable, physicsTable);

        // shardingContext -> shardingRule
        ShardingRule newShardingRule = new ShardingRule(shardingRuleConfig, dataSourceMap.keySet());

        // shardingContext -> shardingRule -> tableRules
        TableRule newTableRule = newShardingRule.getTableRule(logicTable);
        Collection<TableRule> tableRules = shardingContext.getShardingRule().getTableRules();
        tableRules.add(newTableRule);
        Iterator<TableRule> it = tableRules.iterator();
        while (it.hasNext()) {
            TableRule each = it.next();
            if (each.getLogicTable().equals(logicTable) && each != newTableRule) {
                it.remove();
                break;
            }
        }
        // shardingContext -> meta -> table -> tables
        ShardingDataSourceMetaData shardingDataSourceMetaData = new ShardingDataSourceMetaData(
                ShardingUtil.getDataSourceURLs(dataSourceMap), newShardingRule,
                shardingContext.getDatabaseType());
        Map<String, TableMetaData> newTables = newTableMetaDataInitializer(shardingDataSourceMetaData)
                .load(newShardingRule);
        Map<String, TableMetaData> tables = shardingContext.getMetaData().getTable().getTables();
        tables.put(physicsTable, newTables.get(physicsTable));

        // shardingContext -> cachedDatabaseMetaData
        DatabaseMetaData cachedDatabaseMetaData = shardingContext.getCachedDatabaseMetaData();
        Field[] declaredFields = DatabaseMetaData.class.getDeclaredFields();
        for (int i = 0; i < declaredFields.length; i++) {
            Field declaredField = declaredFields[i];
            if (ShardingRule.class.getName().equals(declaredField.getDeclaringClass())) {
                declaredField.setAccessible(true);
                declaredField.set(cachedDatabaseMetaData, newShardingRule);
                break;
            }
        }
    }

    /**
     * 将新建物理表刷新到shardingRuleConfig对象
     *
     * @param shardingRuleConfig shardingRuleConfig
     * @param logicTable logicTable
     * @param physicsTable new physicsTable
     * @return void
     * @author z0043y5h
     * @date 2019/11/1 16:56
     **/
    private void flushShardingRuleConfig(ShardingRuleConfiguration shardingRuleConfig, String logicTable,
            String physicsTable) {
        Collection<TableRuleConfiguration> tableRuleConfigs = shardingRuleConfig.getTableRuleConfigs();
        Iterator<TableRuleConfiguration> it = tableRuleConfigs.iterator();
        while (it.hasNext()) {
            TableRuleConfiguration each = it.next();
            if (each.getLogicTable().equals(logicTable)) {
                String tableNodesStr = new StringBuilder(each.getActualDataNodes()).append(ShardingConstant.SHARDING_TABLE_SEPARATOR)
                        .append(druidDataSourceConfig.getDsname()).append(ShardingConstant.DB_TABLE_SEPARATOR)
                        .append(physicsTable).toString();
                TableRuleConfiguration newTableRuleConfig = new TableRuleConfiguration(logicTable, tableNodesStr);
                newTableRuleConfig.setTableShardingStrategyConfig(each.getTableShardingStrategyConfig());
                it.remove();
                tableRuleConfigs.add(newTableRuleConfig);
                break;
            }
        }
    }

    /**
     * newTableMetaDataInitializer
     *
     * @param shardingDataSourceMetaData shardingDataSourceMetaData
     * @return org.apache.shardingsphere.core.execute.metadata.TableMetaDataInitializer
     * @author z0043y5h
     * @date 2019/11/4 10:16
     **/
    private TableMetaDataInitializer newTableMetaDataInitializer(
            ShardingDataSourceMetaData shardingDataSourceMetaData) {
        ShardingContext shardingContext = shardingDataSource.getShardingContext();
        return new TableMetaDataInitializer(shardingDataSourceMetaData, shardingContext.getExecuteEngine(),
                new JDBCTableMetaDataConnectionManager(dataSourceMap),
                shardingContext.getShardingProperties().<Integer>getValue(
                        ShardingPropertiesConstant.MAX_CONNECTIONS_SIZE_PER_QUERY),
                shardingContext.getShardingProperties().<Boolean>getValue(
                        ShardingPropertiesConstant.CHECK_TABLE_METADATA_ENABLED));
    }


}
