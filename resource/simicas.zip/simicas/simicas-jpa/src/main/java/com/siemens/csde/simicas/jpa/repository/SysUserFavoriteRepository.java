package com.siemens.csde.simicas.jpa.repository;

import com.siemens.csde.simicas.jpa.entity.SysUserFavoriteEntity;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

/**
 * SysUserFavoriteRepository UserFavorite的Dao接口
 *
 * @author z0043y5h
 * @version 1.0-SNAPSHOT
 * @date 2020/3/19 17:55
 **/
@Repository
public interface SysUserFavoriteRepository extends JpaRepository<SysUserFavoriteEntity, String>,
        JpaSpecificationExecutor<SysUserFavoriteEntity> {

    Optional<SysUserFavoriteEntity> findByIdAndCreateUser(String id, String createUser);

    List<SysUserFavoriteEntity> findByCreateUserOrderByPageTypeAscCreateTimeDesc(String createUser);
}
