package com.siemens.csde.simicas.jpa.repository;

import com.siemens.csde.simicas.jpa.entity.CfgKpiEntity;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface CfgKpiRepository extends JpaRepository<CfgKpiEntity,String>, JpaSpecificationExecutor<CfgKpiEntity> {

    String NSQL_ALL_KPI_BY_PID = new StringBuffer("WITH RECURSIVE r AS \n")
            .append("(SELECT * FROM tb_cfg_kpi WHERE p_id = :pid AND station = :station AND line_id = :lineId AND status=1 \n")
            .append(" UNION ALL \n")
            .append(" SELECT tb_cfg_kpi.* FROM tb_cfg_kpi,r WHERE tb_cfg_kpi.p_id = r.id AND tb_cfg_kpi.station = :station AND tb_cfg_kpi.line_id = :lineId AND tb_cfg_kpi.status=1)\n")
            .append("SELECT * FROM r ORDER BY id ").toString();

    @Query(value = "SELECT ck.* FROM tb_cfg_kpi ck   WHERE ck.line_id= :lineId  AND status=1  ",nativeQuery = true)
    List<CfgKpiEntity> findByLineId(@Param("lineId") String lineId);

    @Query(value = "SELECT * FROM tb_cfg_kpi tck WHERE tck .line_id = :lineId AND tck .station != 'LINE' AND tck .status = 1", nativeQuery = true)
    List<CfgKpiEntity> findStationKpiByLineId(@Param("lineId") String lineId);


}
