package com.siemens.csde.simicas.jpa.entity;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.GenericGenerator;

@Entity
@Setter
@Getter
@Table(name = "tb_alarm_hi_notice", schema = "public")
public class AlarmHiNoticeEntity {

    @Id
    @GenericGenerator(name = "idGenerator", strategy = "uuid")
    @GeneratedValue(generator = "idGenerator")
    private String id;

    @Column(name = "tenant",length = 50)
    private String tenant;

    @Column(name = "notify_type")
    private Integer notifyType;

    @Column(name = "alarm_id",length = 50)
    private String alarmId;

    @Column(name = "biz_type",length = 50)
    private Integer bizType;

    @Column(name = "status")
    private Integer status;

    @Column(name = "notify_time")
    private Date notifyTime;


}