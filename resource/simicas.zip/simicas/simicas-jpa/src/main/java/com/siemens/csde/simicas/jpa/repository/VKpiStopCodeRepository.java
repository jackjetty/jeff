package com.siemens.csde.simicas.jpa.repository;

import com.siemens.csde.simicas.jpa.entity.VKpiStopCodeEntity;
import java.util.Date;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;


@Repository
public interface VKpiStopCodeRepository extends JpaRepository<VKpiStopCodeEntity, String>,
        JpaSpecificationExecutor<VKpiStopCodeEntity> {

    @Query(value = " SELECT * FROM  v_kpi_stopcode WHERE  line_id= :lineId AND station_id= :stationId AND data_time> :from  ORDER BY data_time ASC LIMIT 8000", nativeQuery = true)
    List<VKpiStopCodeEntity> findSectionByLineIdAndStationId(@Param("lineId") String lineId, @Param("stationId") String stationId, @Param("from") Date from );




}