package com.siemens.csde.simicas.jpa.entity;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.hibernate.annotations.GenericGenerator;

@Entity
@Setter
@Getter
@ToString
@Table(name = "tb_data_handle_ngreason", schema = "public")
public class DataHandleNGReasonEntity {

    @Id
    @GenericGenerator(name = "idGenerator", strategy = "uuid")
    @GeneratedValue(generator = "idGenerator")
    private String id;

    @Column(name = "line_id", length = 64)
    private String lineId;

    @Column(name = "station_id", length = 64)
    private String stationId;

    @Column(name = "data_value", length = 64)
    private String dataValue;

    @Column(name = "data_time")
    private Date dataTime;

    @Column(name = "product_id",length = 64)
    private String productId;

    @Column(name = "order_id",length = 64)
    private String orderId;

    @Column(name = "batch_id",length = 64)
    private String batchId;

}
