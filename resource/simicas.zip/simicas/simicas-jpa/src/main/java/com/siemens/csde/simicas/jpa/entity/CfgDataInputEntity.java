package com.siemens.csde.simicas.jpa.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.hibernate.annotations.GenericGenerator;

@Entity
@Setter
@Getter
@ToString
@Table(name = "tb_cfg_data_input", schema = "public")
public class CfgDataInputEntity {

    @Id
    @GenericGenerator(name = "idGenerator", strategy = "uuid")
    @GeneratedValue(generator = "idGenerator")
    private String id;

    @Column(name = "kpi_id",length = 64)
    private String kpiId;

    @Column(name = "name",length = 64)
    private String name;

    @Column(name = "data_key",length = 64)
    private String dataKey;

    @Column(name = "data_type",length = 64)
    private String dataType;




}
