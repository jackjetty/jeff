package com.siemens.csde.simicas.jpa.entity;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@ToString
@Entity
@Setter
@Getter
@Table(name="tb_cfg_line",schema = "public")
public class CfgLineEntity {

    @Id
    @Column(name = "id",length = 50)
    private String id;

    @Column(name = "asset_id",length = 50)
    private String assetId;

    @Column(name = "name",length = 50)
    private String name;

    @Column(name = "workstation_model",columnDefinition="text")
    private String workstationModel;

    @Column(name = "version",length = 50)
    private String version;

    @Column(name = "tenant",length = 50)
    private String tenant;

    @Column(name = "index"  )
    private Integer index;

    @Column(name = "create_user",length = 50)
    private String createUser;

    @Column(name = "create_time"  )
    private Date createTime;

    @Column(name = "update_user",length = 50)
    private String updateUser;

    @Column(name = "update_time"  )
    private Date updateTime;

    @Column(name = "status")
    private Integer status;



}