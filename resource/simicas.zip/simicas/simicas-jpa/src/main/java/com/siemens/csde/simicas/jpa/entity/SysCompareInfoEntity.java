package com.siemens.csde.simicas.jpa.entity;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Index;
import javax.persistence.Table;
import javax.persistence.Transient;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.hibernate.annotations.GenericGenerator;

@ToString
@Entity
@Setter
@Getter
@Table(name = "tb_sys_compare_info", schema = "public", indexes = {@Index(columnList = "compare_id")})
public class SysCompareInfoEntity {

    @Id
    @GenericGenerator(name = "idGenerator", strategy = "uuid")
    @GeneratedValue(generator = "idGenerator")
    private String id;

    @Column(name = "compare_id")    //tb_sys_user_compare(id)
    private String compareId;

    @Column(name = "line_id")
    private String lineId;

    @Column(name = "station_id")
    private String stationId;

    @Column(name = "product_id")
    private String productId;

    @Column(name = "active")
    private Boolean active;

    @Column(name = "kpi")
    private String kpi;

    @Column(name = "start_time")
    private Date startTime;

    @Column(name = "end_time")
    private Date endTime;

    @Column(name = "create_user")   //tb_sys_user(id)
    private String createUser;

    @Column(name = "create_time")
    private Date createTime;

    @Column(name = "update_user")
    private String updateUser;

    @Column(name = "update_time")
    private Date updateTime;

    @Transient
    private String lineName;

    @Transient
    private String productName;
}
