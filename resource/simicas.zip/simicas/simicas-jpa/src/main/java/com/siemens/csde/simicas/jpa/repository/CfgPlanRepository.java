package com.siemens.csde.simicas.jpa.repository;

import com.siemens.csde.simicas.jpa.entity.CfgPlanEntity;
import java.util.Date;
import java.util.List;
import javax.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

/**
 * CfgPlanRepository 接口
 *
 * @author z0043y5h
 * @version 1.0-SNAPSHOT
 * @date 2020/2/23 21:21
 **/
@Repository
public interface CfgPlanRepository extends JpaRepository<CfgPlanEntity, String>,
        JpaSpecificationExecutor<CfgPlanEntity> {


    String NSQL_STPLAN = new StringBuffer("SELECT TO_CHAR(p.plan_date + interval '{timeZone} hour','{timeFormat}') AS \"statisticTime\",SUM(p.quantity) AS \"quantityCount\"")
            .append(" FROM tb_cfg_plan p")
            .append(" WHERE  p.plan_date BETWEEN :from AND :to")
            .append(" AND p.product_id IN (:productIds) AND p.status=1 ")
            .append(" AND p.line_id IN (:lineIds) AND p.quantity >= 0 ")
            .append(" GROUP BY TO_CHAR(p.plan_date + interval '{timeZone} hour','{timeFormat}')")
            .append(" ORDER BY TO_CHAR(p.plan_date + interval '{timeZone} hour','{timeFormat}')").toString();


    List<CfgPlanEntity> findByStatusAndLineId(Integer status, String lineId);

    CfgPlanEntity findByStatusAndLineIdAndPlanDateAndProductIdAndIdNot(Integer status, String lineId, Date planDate,
            String productId, String id);

    @Transactional
    @Modifying
    @Query(value = "UPDATE tb_cfg_plan SET status=0,update_time=:updateTime,update_user_id=:updateUserId WHERE status=1 AND line_id=:lineId AND id=:id", nativeQuery = true)
    void deleteByLineIdAndId(@Param("updateTime") Date updateTime, @Param("updateUserId") String updateUserId,
            @Param("lineId") String lineId, @Param("id") String Id);

    CfgPlanEntity findByStatusAndId(Integer status, String id);

    @Query(value="SELECT SUM(quantity) FROM tb_cfg_plan WHERE status=1 AND line_id= :lineId AND plan_date BETWEEN :planDateFrom AND :planDateTo ",nativeQuery=true)
    Integer sumPlanQuantity(@Param("lineId") String lineId,@Param("planDateFrom") Date planDateFrom,@Param("planDateTo") Date planDateTo);

}
