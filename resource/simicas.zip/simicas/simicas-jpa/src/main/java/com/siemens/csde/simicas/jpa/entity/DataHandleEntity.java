package com.siemens.csde.simicas.jpa.entity;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.hibernate.annotations.GenericGenerator;

/**
 * DataOriginalMainEntity
 *
 * @author z004267r
 * @version 1.0-SNAPSHOT
 * @date 3/17/2020 3:28 PM
 **/
@Entity
@Setter
@Getter
@ToString
@Table(name = "tb_data_handle", schema = "public")
public class DataHandleEntity {
    @Id
    @GenericGenerator(name="idGenerator", strategy="uuid")
    @GeneratedValue(generator="idGenerator")
    private String id;

    @Column(name = "line_id",  length = 64 )
    private String lineId;

    @Column(name = "station_id",  length = 64 )
    private String stationId;

    @Column(name = "kpi")
    private String kpi;

    @Column(name = "data_value")
    private String dataValue;

    @Column(name = "data_time"   )
    private Date dataTime;

    @Column(name = "save_time"   )
    private Date saveTime;

}
