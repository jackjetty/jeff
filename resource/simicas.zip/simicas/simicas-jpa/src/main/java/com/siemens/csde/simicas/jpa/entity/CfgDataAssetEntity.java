package com.siemens.csde.simicas.jpa.entity;

import java.time.Instant;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.hibernate.annotations.GenericGenerator;

@ToString
@Entity
@Setter
@Getter
@Table(name="tb_cfg_data_asset")
public class CfgDataAssetEntity {

    @Id
    @GenericGenerator(name = "idGenerator", strategy = "uuid")
    @GeneratedValue(generator = "idGenerator")
    private String id;

    @Column(name = "aspect_name", nullable = false, length = 80)
    private String aspectName;

    @Column(name = "asset_id", length = 80)
    private String assetId;

    @Column(name = "part")
    private Integer part;

    @Column(name = "tenant_id", length = 80)
    private String tenantId;

    @Column(name = "last_process_time")
    private Instant lastProcessTime;

    @Column(name = "status")
    private Integer status;

    @Column(name = "collection_type",length = 80)
    private String collectionType;

    @Column(name = "collection_method")
    private String collectionMethod;

    @Column(name = "url",length = 180)
    private String url;

    @Column(name = "user_name",length = 50)
    private String userName;

    @Column(name = "password",length = 80)
    private String password;

    @Transient
    private String lineId;

    @Transient
    private String lineName;

    @Transient
    private Integer createIndex;
}