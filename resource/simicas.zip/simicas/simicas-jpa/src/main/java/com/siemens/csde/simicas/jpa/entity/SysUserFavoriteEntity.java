package com.siemens.csde.simicas.jpa.entity;

import com.siemens.csde.simicas.common.constant.enums.PageTypeEnum;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Index;
import javax.persistence.Table;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.hibernate.annotations.GenericGenerator;

@ToString
@Entity
@Setter
@Getter
@Table(name = "tb_sys_user_favorite", schema = "public", indexes = {@Index(columnList = "create_user")})
public class SysUserFavoriteEntity {

    @Id
    @GenericGenerator(name = "idGenerator", strategy = "uuid")
    @GeneratedValue(generator = "idGenerator")
    private String id;

    @Column(name = "title")
    private String title;

    @Column(name = "page_type")
    @Enumerated(EnumType.ORDINAL)
    private PageTypeEnum pageType;

    @Column(name = "page_url")
    private String pageUrl;

    @Column(name = "page_info", columnDefinition = "text")
    private String pageInfo;

    @Column(name = "create_time")
    private Date createTime;

    @Column(name = "create_user")   //tb_sys_user(id)
    private String createUser;

    @Column(name = "update_time")
    private Date updateTime;

    @Column(name = "update_user")
    private String updateUser;
}
