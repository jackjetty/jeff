package com.siemens.csde.simicas.jpa.entity;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.GenericGenerator;
@Entity
@Setter
@Getter
@Table(name="tb_alarm_cfg_rule2email",schema = "public")
public class AlarmCfgRule2EmailEntity {

    @Id
    @GenericGenerator(name = "idGenerator", strategy = "uuid")
    @GeneratedValue(generator = "idGenerator")
    private String id;

    @Column(name = "rule_id", nullable = false,length = 50)
    private String ruleId;

    @Column(name = "email_address", nullable = false,length = 50)
    private String emailAddress;

    @Column(name = "create_time"  )
    private Date createTime;


}