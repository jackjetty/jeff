package com.siemens.csde.simicas.jpa.entity;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.GenericGenerator;

@Entity
@Setter
@Getter
@Table(name="tb_cfg_merge_kpi")
public class CfgMergeKpiEntity {

    @Id
    @GenericGenerator(name = "idGenerator", strategy = "uuid")
    @GeneratedValue(generator = "idGenerator")
    private String id;

    @Column(name = "line_id", nullable = false, length = 50)
    private String lineId;

    @Column(name = "tenant", length = 80)
    private String tenant;

    @Column(name = "last_process_time")
    private Date lastProcessTime;

    @Column(name = "status")
    private Integer status;

    @Column(name = "kpi_name",length = 80)
    private String kpiName;

    @Column(name = "station_id",length = 50)
    private String stationId;
}