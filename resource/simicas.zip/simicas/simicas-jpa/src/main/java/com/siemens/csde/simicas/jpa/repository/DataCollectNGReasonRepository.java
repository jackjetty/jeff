package com.siemens.csde.simicas.jpa.repository;

import com.siemens.csde.simicas.jpa.entity.DataCollectNGReasonEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;


@Repository
public interface DataCollectNGReasonRepository extends JpaRepository<DataCollectNGReasonEntity, String>,
        JpaSpecificationExecutor<DataCollectNGReasonEntity> {


    String NSQL_STNGREASONS=new StringBuffer( "SELECT MIN(id) AS   \"id\",line_id AS  \"lineId\", product_id AS  \"productId\", station_id AS  \"stationId\",TO_CHAR(statistic_time + interval '{timeZone} hour','{timeFormat}')  AS  \"statisticTime\" , COUNT(1) AS  \"ngReasonCount\", ng_reason AS  \"ngReason\"   FROM tb_data_collect_ngreason    \n")
            .append("  WHERE     statistic_time>= :from AND statistic_time<= :to AND   line_id IN (:lineIds) AND  product_id IN (:productIds)  AND station_id IN (:stationIds)     \n")
            .append(" GROUP BY TO_CHAR(statistic_time + interval '{timeZone} hour','{timeFormat}') ,  product_id, line_id,station_id,ng_reason   \n")
            .append(" ORDER BY TO_CHAR(statistic_time + interval '{timeZone} hour','{timeFormat}') ,  product_id, line_id,station_id,ng_reason ").toString();


    String NSQL_STNGREASON=new StringBuffer( "SELECT MIN(id) AS   \"id\",line_id AS  \"lineId\", product_id AS  \"productId\", station_id AS  \"stationId\",TO_CHAR(statistic_time + interval '{timeZone} hour','{timeFormat}')  AS  \"statisticTime\" , COUNT(1) AS  \"ngReasonCount\", ng_reason AS  \"ngReason\"   FROM tb_data_collect_ngreason    \n")
            .append("  WHERE     statistic_time>= :from AND statistic_time<= :to AND   line_id IN (:lineIds) AND  product_id IN (:productIds)  AND station_id IN (:stationIds) AND ng_reason= :ngReason    \n")
            .append(" GROUP BY TO_CHAR(statistic_time + interval '{timeZone} hour','{timeFormat}') , product_id, line_id,station_id,ng_reason   \n")
            .append(" ORDER BY TO_CHAR(statistic_time + interval '{timeZone} hour','{timeFormat}') , product_id, line_id,station_id,ng_reason ").toString();

}