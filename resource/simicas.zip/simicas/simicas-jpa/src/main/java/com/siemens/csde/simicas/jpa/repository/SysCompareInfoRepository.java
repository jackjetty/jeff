package com.siemens.csde.simicas.jpa.repository;

import com.siemens.csde.simicas.jpa.entity.SysCompareInfoEntity;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

/**
 * SysCompareInfoRepository CompareInfo的Dao接口
 *
 * @author z0043y5h
 * @version 1.0-SNAPSHOT
 * @date 2020/3/26 11:51
 **/
@Repository
public interface SysCompareInfoRepository extends JpaRepository<SysCompareInfoEntity, String>,
        JpaSpecificationExecutor<SysCompareInfoEntity> {

    void deleteByCompareId(String compareId);

    List<SysCompareInfoEntity> findByCompareId(String compareId);
}