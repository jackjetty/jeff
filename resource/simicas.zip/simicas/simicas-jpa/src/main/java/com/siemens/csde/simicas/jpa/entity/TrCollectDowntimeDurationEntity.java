package com.siemens.csde.simicas.jpa.entity;

import lombok.Getter;
import lombok.Setter;
@Getter
@Setter
public class TrCollectDowntimeDurationEntity {

    private String id;
    private String lineId;
    private String stationId;
    private String statisticTime;
    private Long durationTime;
    private String stopCode;
}