package com.siemens.csde.simicas.jpa.entity;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@ToString
@Entity
@Table(name="tb_sys_tenant")
@Setter
@Getter
public class SysTenantEntity {

    @Id
    @Column(name = "id",length = 50)
    private String id;

    @Column(name = "client_id",length = 50)
    private String clientId;

    @Column(name = "name")
    private String name;

    @Column(name = "secret",length = 1024)
    private String secret;

    @Column(name = "token",length = 2048)
    private String token;

    @Column(name = "parent_tenant",length = 50)
    private String parentTenant;

    @Column(name = "create_time"  )
    private Date createTime;

    @Column(name = "create_user",length = 50)
    private String createUser;

    @Column(name = "update_time"  )
    private Date updateTime;

    @Column(name = "update_user",length = 50)
    private String updateUser;

    @Column(name = "status"  )
    private Integer status;

    @Column(name = "type"  )
    private String type;
}
