package com.siemens.csde.simicas.jpa.repository;

import com.siemens.csde.simicas.jpa.entity.CfgDataInputEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface CfgDataInputRepository extends JpaRepository<CfgDataInputEntity,String>, JpaSpecificationExecutor<CfgDataInputEntity> {

    @Modifying
    void deleteByKpiId(@Param("kpiId") String kpiId);

}
