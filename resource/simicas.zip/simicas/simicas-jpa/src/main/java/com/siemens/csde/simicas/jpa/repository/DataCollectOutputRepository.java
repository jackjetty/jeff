package com.siemens.csde.simicas.jpa.repository;

import com.siemens.csde.simicas.jpa.entity.DataCollectOutputEntity;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

/**
 * Workstation Status的Dao接口
 *
 * @author z0043y5h
 * @version 1.0-SNAPSHOT
 * @date 2020/2/11 17:21
 **/
@Repository
public interface DataCollectOutputRepository extends JpaRepository<DataCollectOutputEntity, String>,
        JpaSpecificationExecutor<DataCollectOutputEntity> {

    String NSQL_STOUTPUTS = new StringBuffer( "SELECT MIN(co.id) AS   \"id\",co.line_id AS  \"lineId\",co.product_id AS  \"productId\",co.station_id AS  \"stationId\",TO_CHAR(co.statistic_time + interval '{timeZone} hour','{timeFormat}')  AS  \"statisticTime\" ,SUM(co.end_output-co.start_output+1) AS  \"outputCount\"   FROM tb_data_collect_output co   \n")
            .append("  WHERE     co.statistic_time>= :from AND co.statistic_time<= :to AND co.product_id IN (:productIds)  AND co.line_id IN (:lineIds) AND co.station_id IN (:stationIds)  AND co.end_output >=0 AND co.start_output >=0  \n")
            .append(" GROUP BY TO_CHAR(co.statistic_time + interval '{timeZone} hour','{timeFormat}') ,co.product_id,co.line_id,co.station_id   \n")
            .append(" ORDER BY TO_CHAR(co.statistic_time + interval '{timeZone} hour','{timeFormat}') ,co.product_id,co.line_id,co.station_id  ").toString();

    String NSQL_STLTHS = new StringBuffer( "SELECT MIN(id) AS   \"id\",line_id AS  \"lineId\", product_id AS  \"productId\",station_id AS  \"stationId\",TO_CHAR(statistic_time + interval '{timeZone} hour','{timeFormat}')  AS  \"statisticTime\" ,SUM(end_output-start_output+1) AS  \"outputCount\"  ,SUM(extract(epoch from  end_time )-extract(epoch from  start_time )) AS  \"durationTime\"   FROM tb_data_collect_output    \n")
            .append("  WHERE     statistic_time>= :from AND statistic_time<= :to AND  product_id IN (:productIds)  AND  line_id IN (:lineIds) AND station_id IN (:stationIds)  AND end_output >=0 AND start_output >=0   \n")
            .append(" GROUP BY TO_CHAR(statistic_time + interval '{timeZone} hour','{timeFormat}') ,  product_id, line_id,station_id   \n")
            .append(" ORDER BY TO_CHAR(statistic_time + interval '{timeZone} hour','{timeFormat}') ,  product_id, line_id,station_id ").toString();



    @Query(value = "SELECT * FROM tb_data_collect_output WHERE  line_id= :lineId AND station_id= :stationId AND pb_id= :pbId  ORDER BY  statistic_time,save_time DESC LIMIT 1", nativeQuery = true)
    Optional<DataCollectOutputEntity> findLastByLineIdAndStationIdAndPbId(@Param("lineId") String lineId,@Param("stationId") String stationId,@Param("pbId") String pbId);



}