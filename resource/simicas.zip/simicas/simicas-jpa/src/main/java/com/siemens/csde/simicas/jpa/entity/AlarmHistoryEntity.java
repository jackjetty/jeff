package com.siemens.csde.simicas.jpa.entity;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.Type;
@Entity
@Setter
@Getter
@Table(name = "tb_alarm_history", schema = "public")
public class AlarmHistoryEntity {

    @Id
    @Column(name = "id",length = 50)
    private String id;

    @Column(name = "line_id", nullable = false,length = 50)
    private String lineId;

    @Column(name = "product_id",length = 50)
    private String productId;

    @Transient
    private String productName;

    @Column(name = "order_id")
    private String orderId;

    @Column(name = "kpi",length = 50)
    private String kpi;

    @Column(name = "tenant",length = 50)
    private String tenant;

    @Column(name = "alarm_level")
    private String alarmLevel;

    @Column(name = "expression")
    private String expression;

    @Column(name = "alarm_time")
    private Date alarmTime;

    @Column(name = "alarm_value")
    private String alarmValue;


    @Column(name = "status")
    private Integer status;
    @Column(name = "update_time")
    private Date updateTime;

    @Column(name = "update_user_id")
    private String updateUserId;

    @Column(name = "highlight")
    @Type(type = "org.hibernate.type.NumericBooleanType")
    private Boolean highlight;


    @Column(name = "notify_web")
    @Type(type = "org.hibernate.type.NumericBooleanType")
    private Boolean notifyWeb;

    @Column(name = "notify_email")
    @Type(type = "org.hibernate.type.NumericBooleanType")
    private Boolean notifyEmail;

    @Column(name = "notify_sms")
    @Type(type = "org.hibernate.type.NumericBooleanType")
    private Boolean notifySms;

    @Column(name = "active_time")
    private Date activeTime;

    @Column(name = "recovery_time")
    private Date recoveryTime;

    @Transient
    private String lineName;

    @Transient
    private String ruleId;


}

