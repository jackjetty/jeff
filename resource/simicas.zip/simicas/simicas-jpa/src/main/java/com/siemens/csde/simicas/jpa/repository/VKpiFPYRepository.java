package com.siemens.csde.simicas.jpa.repository;

import com.siemens.csde.simicas.jpa.entity.VKpiFPYEntity;
import java.util.Date;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;


@Repository
public interface VKpiFPYRepository extends JpaRepository<VKpiFPYEntity, String>,
        JpaSpecificationExecutor<VKpiFPYEntity> {

    @Query(value = " SELECT * FROM  v_kpi_fpy WHERE  line_id= :lineId AND station_id= :stationId AND data_time> :from  ORDER BY data_time ASC LIMIT 8000", nativeQuery = true)
    List<VKpiFPYEntity> findSectionByLineIdAndStationId(@Param("lineId") String lineId, @Param("stationId") String stationId, @Param("from") Date from );




}