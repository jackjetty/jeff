package com.siemens.csde.simicas.jpa.repository;

import com.siemens.csde.simicas.jpa.entity.DataHandleUsageEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

/**
 * DataHandleUsageRepository    Usage处理数据的Dao接口
 *
 * @author z0043y5h
 * @version 1.0-SNAPSHOT
 * @date 2020/3/20 11:47
 **/
@Repository
public interface DataHandleUsageRepository extends JpaRepository<DataHandleUsageEntity, String>,
        JpaSpecificationExecutor<DataHandleUsageEntity> {

    String INSERT_SQL = new StringBuffer("INSERT INTO tb_data_handle_usage\n")
            .append("(id, data_time, end_time, line_id, metric_type, start_time)\n")
            .append("VALUES(:id, :dataTime, :endTime, :lineId, :metricType, :startTime)").toString();

}