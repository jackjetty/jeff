package com.siemens.csde.simicas.jpa.repository;

import com.siemens.csde.simicas.jpa.entity.CfgProductEntity;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import javax.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

/**
 * CfgProductRepository 接口
 *
 * @author z0043y5h
 * @version 1.0-SNAPSHOT
 * @date 2020/2/22 14:50
 **/
@Repository
public interface CfgProductRepository extends JpaRepository<CfgProductEntity, String>,
        JpaSpecificationExecutor<CfgProductEntity> {

    Optional<CfgProductEntity> findByTenantIdAndProductIdAndStatus(String tenantId, String productId, Integer status);

    Optional<CfgProductEntity> findByTenantIdAndProductNameAndStatus(String tenantId, String productName,
            Integer status);

    List<CfgProductEntity> findByTenantIdAndStatus(String tenantId, Integer status);

    Optional<CfgProductEntity> findByTenantIdAndIdAndStatus(String tenantId, String id, Integer status);

    @Transactional
    @Modifying
    @Query(value = "UPDATE tb_cfg_product SET status=0,update_time=:updateTime,update_user_id=:updateUserId WHERE status=1 AND tenant_id=:tenantId AND product_id=:productId", nativeQuery = true)
    void deleteByTenantIdAndProductId(@Param("updateTime") Date updateTime, @Param("updateUserId") String updateUserId,
            @Param("tenantId") String tenantId, @Param("productId") String productId);

    @Transactional
    @Modifying
    @Query(value = "UPDATE tb_cfg_product SET status=0,update_time=:updateTime,update_user_id=:updateUserId WHERE status=1 AND tenant_id=:tenantId", nativeQuery = true)
    void deleteByTenantId(@Param("updateTime") Date updateTime, @Param("updateUserId") String updateUserId,
            @Param("tenantId") String tenantId);

    List<CfgProductEntity> findByTenantIdAndStatusOrderByProductName(String tenantId, Integer status);

    @Query(value = "SELECT * FROM tb_cfg_product WHERE status=1 AND tenant_id=:tenantId AND (product_id=:filter OR product_name=:filter)", nativeQuery = true)
    List<CfgProductEntity> findByTenantIdAndStatusAndIdOrNameEqual(@Param("tenantId") String tenantId,
            @Param("filter") String filter);
}