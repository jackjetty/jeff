package com.siemens.csde.simicas.jpa.entity;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Type;

@Entity
@Setter
@Getter
@Table(name = "tb_cfg_workstation_status", schema = "public")
public class CfgWorkstationStatusEntity {

    @Id
    @GenericGenerator(name = "idGenerator", strategy = "uuid")
    @GeneratedValue(generator = "idGenerator")
    @Column(name = "id", length = 50)
    private String id;

    @Column(name = "station_id",length = 50)
    private String stationId;

    @Column(name = "station_name",length = 50)
    private String stationName;

    @Column(name = "station_status",length = 50)
    private String stationStatus;

    @Column(name = "label",length = 50)
    private String label;

    @Column(name = "visual",length = 50)
    private String visual;

    @Column(name = "downtime_category"  )
    @Type(type="org.hibernate.type.NumericBooleanType")
    private Boolean downtimeCategory;

    @Column(name = "line_id", nullable = false,length = 50)
    private String lineId;

    @Column(name = "create_time"  )
    private Date createTime;

    @Column(name = "create_user"  ,length = 50 )
    private String createUser;

    @Column(name = "update_time"  )
    private Date updateTime;

    @Column(name = "update_user" ,length = 50  )
    private String updateUser;

    @Column(name = "status"  )
    private Integer status;
}