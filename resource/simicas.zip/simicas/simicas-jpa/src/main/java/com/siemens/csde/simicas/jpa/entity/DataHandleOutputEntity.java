package com.siemens.csde.simicas.jpa.entity;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.hibernate.annotations.GenericGenerator;

@ToString
@Entity
@Setter
@Getter
@Table(name = "tb_data_handle_output", schema = "public")
public class DataHandleOutputEntity {

    @Id
    @GenericGenerator(name = "idGenerator", strategy = "uuid")
    @GeneratedValue(generator = "idGenerator")
    private String id;

    @Column(name = "line_id", length = 64)
    private String lineId;

    @Column(name = "station_id", length = 64)
    private String stationId;

    @Column(name = "data_value")
    private Integer dataValue;

    @Column(name = "product_name")
    private String productName;

    @Column(name = "total")
    private Integer total;

    @Column(name = "data_time")
    private Date dataTime;

    @Column(name = "start_time")
    private Date startTime;

    @Column(name = "end_time")
    private Date endTime;

    @Column(name = "first_time")
    private Date firstTime;

    @Column(name = "product_id",length = 64)
    private String productId;

    @Column(name = "order_id",length = 64)
    private String orderId;

    @Column(name = "batch_id",length = 64)
    private String batchId;

}
