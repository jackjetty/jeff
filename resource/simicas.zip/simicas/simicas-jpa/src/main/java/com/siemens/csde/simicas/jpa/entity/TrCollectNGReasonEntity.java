package com.siemens.csde.simicas.jpa.entity;

import lombok.Getter;
import lombok.Setter;
@Getter
@Setter
public class TrCollectNGReasonEntity {

    private String id;
    private String productId;
    private String lineId;
    private String stationId;
    private String statisticTime;
    private Long ngReasonCount;
    private String ngReason;


}