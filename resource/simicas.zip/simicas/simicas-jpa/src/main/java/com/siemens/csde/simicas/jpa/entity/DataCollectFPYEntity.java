package com.siemens.csde.simicas.jpa.entity;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.hibernate.annotations.GenericGenerator;

@Entity
@Setter
@Getter
@ToString
@Table(name = "tb_data_collect_fpy", schema = "public")
public class DataCollectFPYEntity {

    @Id
    @GenericGenerator(name="idGenerator", strategy="uuid")
    @GeneratedValue(generator="idGenerator")
    private String id;

    @Column(name = "line_id",  length = 50 )
    private String lineId;

    @Column(name = "product_id",  length = 50 )
    private String productId;

    @Column(name = "order_id",  length = 50 )
    private String orderId;

    @Column(name = "station_id",  length = 50 )
    private String stationId;

    @Column(name = "batch_id",  length = 50 )
    private String batchId;

    @Column(name = "statistic_time" )
    private Date statisticTime;

    @Column(name = "save_time" )
    private Date saveTime;

    @Column(name = "start_defect" )
    private Integer startDefect;

    @Column(name = "start_total" )
    private Integer startTotal;

    @Column(name = "start_time" )
    private Date startTime;

    @Column(name = "end_defect" )
    private Integer endDefect;

    @Column(name = "end_total" )
    private Integer endTotal;

    @Column(name = "end_time" )
    private Date endTime;

    @Column(name = "pb_id" ,length = 50)
    private String pbId;

}