package com.siemens.csde.simicas.jpa.shardingjdbc.algorithm;


//import com.siemens.csde.simicas.jpa.config.datasource.DruidConfig;
import com.siemens.csde.simicas.jpa.shardingjdbc.constant.ShardingConstant;
import com.siemens.csde.simicas.jpa.util.ShardingUtil;
import java.util.Collection;
import lombok.extern.slf4j.Slf4j;
import org.apache.shardingsphere.api.sharding.standard.PreciseShardingAlgorithm;
import org.apache.shardingsphere.api.sharding.standard.PreciseShardingValue;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

/**
 * PreciseModuloShardingTableAlgorithm
 *
 * @author z0043y5h
 * @version 1.0-SNAPSHOT
 * @date 2019/11/1 16:43
 **/
@Slf4j
@Component
public class PreciseModuloShardingTableAlgorithm implements PreciseShardingAlgorithm<String> {


    @Autowired
    private ShardingUtil shardingUtil;


    /**
     * 分表逻辑实现。根据分表规则，计算可用表名称并返回。如果计算结果不在可用表集合中，需创建该表并刷新分表资源对象。
     *
     * @param availableTables 可用物理表
     * @param shardingValue   分表字段值
     * @return java.lang.String
     * @author z0043y5h
     * @date 2019/11/4 10:33
     **/
    @Override
    public String doSharding(final Collection<String> availableTables,
            final PreciseShardingValue<String> shardingValue) {
        if (CollectionUtils.isEmpty(availableTables)) {
            throw new UnsupportedOperationException("availableTableNames is empty.");
        }
        String logicTableName = shardingValue.getLogicTableName();


        String tenant = shardingUtil.getTenant(shardingValue.getValue());
        if (tenant == null) {
            throw new UnsupportedOperationException("no tenant found. tenant=" + tenant);
        }
        String physicsTable = logicTableName + ShardingConstant.TABLE_TENANT_SEPARATOR + tenant;


        return physicsTable;
    }
}
