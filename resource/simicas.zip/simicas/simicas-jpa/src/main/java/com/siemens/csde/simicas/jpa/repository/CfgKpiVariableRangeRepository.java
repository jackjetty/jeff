package com.siemens.csde.simicas.jpa.repository;

import com.siemens.csde.simicas.jpa.entity.CfgKpiVariableRangeEntity;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface CfgKpiVariableRangeRepository extends JpaRepository<CfgKpiVariableRangeEntity,String>, JpaSpecificationExecutor<CfgKpiVariableRangeEntity> {

    String SQL_LINE_STATION_STAUSRANGE =  new StringBuffer("SELECT ckvr.value AS \"range\",ck.station AS \"station\" FROM  tb_cfg_kpi_variable_range ckvr   LEFT JOIN tb_cfg_kpi_variable ckv ON ckv.id=ckvr.variable_id "
            +"  LEFT JOIN tb_cfg_kpi ck ON ck.id=ckv.kpi_id \n "
            +"  WHERE ck.name = 'Status' AND ckv.name='Status' AND ck.station !='LINE' AND  and ck.line_id= :lineId ").toString();


    @Query(value = "SELECT ckvr.* FROM tb_cfg_kpi_variable_range ckvr LEFT JOIN tb_cfg_kpi_variable ckv ON ckv.id=ckvr.variable_id \n"
            + " LEFT JOIN tb_cfg_kpi ck ON ck.id=ckv.kpi_id \n"
            + " WHERE ck.line_id= :lineId  AND ckvr.status=1  ",nativeQuery = true)
    List<CfgKpiVariableRangeEntity> findByLineId (@Param("lineId") String lineId  );

    @Query(value = "SELECT ckvr.* FROM tb_cfg_kpi_variable_range ckvr LEFT JOIN tb_cfg_kpi_variable ckv ON ckv.id=ckvr.variable_id \n"
            + " LEFT JOIN tb_cfg_kpi ck ON ck.id=ckv.kpi_id \n"
            + " WHERE ck.line_id= :lineId AND ck.id=:kpiId AND ckvr.status=1  ",nativeQuery = true)
    List<CfgKpiVariableRangeEntity> findByLineIdAndKpiId (@Param("lineId") String lineId,@Param("kpiId") String kpiId  );


    @Query(value = "SELECT  ckvr.value FROM  tb_cfg_kpi_variable_range ckvr   LEFT JOIN tb_cfg_kpi_variable ckv ON ckv.id=ckvr.variable_id "
            + " LEFT JOIN tb_cfg_kpi ck ON ck.id=ckv.kpi_id \n"
            + " WHERE ck.name = 'Status' AND ckv.name='Status' AND ck.station='LINE' AND  ck.line_id= :lineId", nativeQuery = true)
    String findLineStatusRangeValue(@Param("lineId") String lineId);



    List<CfgKpiVariableRangeEntity> findByVariableIdAndStatus(@Param("variableId") String variableId,@Param("status") Integer status);


}
