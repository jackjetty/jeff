package com.siemens.csde.simicas.jpa.repository;

import com.siemens.csde.simicas.jpa.entity.DataCollectFPYEntity;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;


@Repository
public interface DataCollectFPYRepository extends JpaRepository<DataCollectFPYEntity, String>,
        JpaSpecificationExecutor<DataCollectFPYEntity> {


    String NSQL_STFPYS = new StringBuffer( "SELECT  MIN(id) AS   \"id\",line_id AS  \"lineId\",product_id AS  \"productId\",station_id AS  \"stationId\",TO_CHAR(statistic_time + interval '{timeZone} hour','{timeFormat}')  AS  \"statisticTime\" ,SUM(end_total-start_total) AS  \"sumTotal\" ,SUM(end_defect-start_defect) AS  \"sumDefect\"  FROM tb_data_collect_fpy    \n")
            .append("  WHERE     statistic_time>= :from AND statistic_time<= :to AND  product_id IN (:productIds)  AND  line_id IN (:lineIds) AND station_id IN (:stationIds)  AND start_total >=0 AND end_total >=0  \n")
            .append(" GROUP BY TO_CHAR(statistic_time + interval '{timeZone} hour','{timeFormat}') , product_id, line_id,station_id    \n")
            .append(" ORDER BY TO_CHAR(statistic_time + interval '{timeZone} hour','{timeFormat}') , product_id, line_id,station_id  ").toString();


    String NSQL_STDEFECTS = new StringBuffer( "SELECT  MIN(id) AS   \"id\",line_id AS  \"lineId\",station_id AS  \"stationId\",product_id AS  \"productId\",TO_CHAR(statistic_time + interval '{timeZone} hour','{timeFormat}')  AS  \"statisticTime\" ,SUM(end_defect-start_defect) AS  \"defect\"  FROM tb_data_collect_fpy    \n")
            .append("  WHERE     statistic_time>= :from AND statistic_time<= :to AND  product_id IN (:productIds)  AND  line_id IN (:lineIds) AND station_id IN (:stationIds)  AND start_total >=0 AND end_total >=0  \n")
            .append(" GROUP BY TO_CHAR(statistic_time + interval '{timeZone} hour','{timeFormat}') , product_id, line_id,station_id    \n")
            .append(" ORDER BY TO_CHAR(statistic_time + interval '{timeZone} hour','{timeFormat}') , product_id, line_id,station_id  ").toString();




    @Query(value = "SELECT * FROM tb_data_collect_fpy WHERE  line_id= :lineId AND station_id= :stationId AND pb_id= :pbId  ORDER BY  statistic_time,save_time DESC LIMIT 1", nativeQuery = true)
    Optional<DataCollectFPYEntity> findLastByLineIdAndStationIdAndPbId(@Param("lineId") String lineId,@Param("stationId") String stationId,@Param("pbId") String pbId );



}