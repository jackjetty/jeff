package com.siemens.csde.simicas.jpa.repository;

import com.siemens.csde.simicas.jpa.entity.CfgMergeKpiEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

@Repository
public interface CfgMergeKpiRepository extends JpaRepository<CfgMergeKpiEntity, String>, JpaSpecificationExecutor<CfgMergeKpiEntity> {

}
