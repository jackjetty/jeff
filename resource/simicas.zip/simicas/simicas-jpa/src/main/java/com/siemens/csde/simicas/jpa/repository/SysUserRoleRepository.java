package com.siemens.csde.simicas.jpa.repository;

import com.siemens.csde.simicas.jpa.entity.SysUserRoleEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

/**
 * SysUserRoleRepository UserRole的Dao接口
 *
 * @author z0043y5h
 * @version 1.0-SNAPSHOT
 * @date 2020/3/19 17:55
 **/
@Repository
public interface SysUserRoleRepository extends JpaRepository<SysUserRoleEntity, String>,
        JpaSpecificationExecutor<SysUserRoleEntity> {

}
