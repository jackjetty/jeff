package com.siemens.csde.simicas.jpa.entity;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.hibernate.annotations.GenericGenerator;

@Entity
@Setter
@Getter
@ToString
@Table(name = "tb_data_collect_ngreason", schema = "public")
public class DataCollectNGReasonEntity {

    @Id
    @GenericGenerator(name="idGenerator", strategy="uuid")
    @GeneratedValue(generator="idGenerator")
    private String id;

    @Column(name = "line_id",  length = 50 )
    private String lineId;

    @Column(name = "product_id",  length = 50 )
    private String productId;

    @Column(name = "order_id",  length = 50 )
    private String orderId;

    @Column(name = "station_id",  length = 50 )
    private String stationId;

    @Column(name = "batch_id",  length = 50 )
    private String batchId;

    @Column(name = "statistic_time" )
    private Date statisticTime;

    @Column(name = "save_time" )
    private Date saveTime;

    @Column(name = "ng_reason",length = 50)
    private String ngReason;

    @Column(name = "data_time" )
    private Date dataTime;

    @Column(name = "pb_id" ,length = 50)
    private String pbId;

}