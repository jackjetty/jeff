package com.siemens.csde.simicas.jpa.repository;

import com.siemens.csde.simicas.jpa.entity.CfgWorkstationStatusEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

/**
 * Workstation Status的Dao接口
 *
 * @author z0043y5h
 * @version 1.0-SNAPSHOT
 * @date 2020/2/11 17:21
 **/
@Repository
public interface CfgWorkstationStatusRepository extends JpaRepository<CfgWorkstationStatusEntity, String>,
        JpaSpecificationExecutor<CfgWorkstationStatusEntity> {

}