package com.siemens.csde.simicas.jpa.entity;

import com.siemens.csde.simicas.common.constant.enums.SubTypeEnum;
import java.sql.Timestamp;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.hibernate.annotations.GenericGenerator;

@ToString
@Entity
@Setter
@Getter
@Table(name = "tb_subscription_detail", schema = "public")
public class SubscriptionEntity {

    @Id
    @GenericGenerator(name = "idGenerator", strategy = "uuid")
    @GeneratedValue(generator = "idGenerator")
    private String id;

    @Column(name = "instance_id", nullable = false)
    private String instanceId;

    @Column(name = "user_id", nullable = false)
    private String userId;

    @Column(name = "tenant", nullable = false)
    private String tenant;

    @Column(name = "line_id")
    private String lineId;

    @Column(name = "destination", nullable = false)
    private String destination;

    @Column(name = "subscription_content", length = 20480)
    private String subscriptionContent;

    @Column(name = "sub_type")
    @Enumerated(EnumType.STRING)
    private SubTypeEnum subType;

    @Column(name = "update_time")
    private Timestamp updateTime;
}
