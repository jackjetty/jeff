package com.siemens.csde.simicas.jpa.repository;

import com.siemens.csde.simicas.jpa.entity.SysRoleResourceEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

/**
 * SysRoleResourceRepository RoleResource的Dao接口
 *
 * @author z0043y5h
 * @version 1.0-SNAPSHOT
 * @date 2020/3/19 18:02
 **/
@Repository
public interface SysRoleResourceRepository extends JpaRepository<SysRoleResourceEntity, String>,
        JpaSpecificationExecutor<SysRoleResourceEntity> {

}