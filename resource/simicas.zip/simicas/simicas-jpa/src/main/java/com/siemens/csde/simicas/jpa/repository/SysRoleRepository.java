package com.siemens.csde.simicas.jpa.repository;

import com.siemens.csde.simicas.jpa.entity.SysRoleEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

/**
 * SysRoleRepository Role的Dao接口
 *
 * @author z0043y5h
 * @version 1.0-SNAPSHOT
 * @date 2020/3/19 18:03
 **/
@Repository
public interface SysRoleRepository extends JpaRepository<SysRoleEntity, String>,
        JpaSpecificationExecutor<SysRoleEntity> {

}
