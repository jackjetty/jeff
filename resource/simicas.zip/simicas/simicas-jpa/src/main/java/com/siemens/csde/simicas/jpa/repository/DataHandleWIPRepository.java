package com.siemens.csde.simicas.jpa.repository;

import com.siemens.csde.simicas.jpa.entity.DataHandleWIPEntity;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

/**
 * DataHandleWIPRepository  WIP处理数据的Dao接口
 *
 * @author z0043y5h
 * @version 1.0-SNAPSHOT
 * @date 2020/3/20 11:49
 **/
@Repository
public interface DataHandleWIPRepository extends JpaRepository<DataHandleWIPEntity, String>,
        JpaSpecificationExecutor<DataHandleWIPEntity> {

    String INSERT_SQL = new StringBuffer("INSERT INTO tb_data_handle_wip\n")
            .append("(id, batch_id, data_time, data_value, line_id, order_id, product_id, station_id)\n")
            .append("VALUES(id, :batchId, :dataTime, :dataValue, :lineId, :orderId, :productId, :stationId)").toString();

    @Query(value = "SELECT * FROM tb_data_handle_eff WHERE line_id= :lineId  AND station_id = :stationId  ORDER BY data_time DESC LIMIT 1", nativeQuery = true)
    Optional<DataHandleWIPEntity> findLastEntity(@Param("lineId") String lineId, @Param("stationId") String stationId);

}