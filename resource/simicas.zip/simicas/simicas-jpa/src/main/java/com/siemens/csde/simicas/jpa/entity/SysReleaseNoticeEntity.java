package com.siemens.csde.simicas.jpa.entity;

import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.GenericGenerator;

/**
 * SysReleaseNoticeEntity
 *
 * @author z0043y5h
 * @version 1.0-SNAPSHOT
 * @date 2020/3/24 15:50
 **/
@Entity
@Setter
@Getter
@Table(name = "tb_sys_release_notice", schema = "public")
public class SysReleaseNoticeEntity {

    @Id
    @GenericGenerator(name = "idGenerator", strategy = "uuid")
    @GeneratedValue(generator = "idGenerator")
    @Column(name = "id", length = 50)
    private String id;

    @Column(name = "title", length = 150)
    private String title;

    @Basic(fetch= FetchType.LAZY)
    @Column(name="content",columnDefinition="TEXT")
    private String content;

    @Column(name = "start_time")
    private Date startTime;

    @Column(name = "end_time")
    private Date endTime;

    @Column(name = "create_user",length = 50)
    private String createUser;

    @Column(name = "create_time")
    private Date createTime;

    @Column(name = "status")
    private Integer status;
}
