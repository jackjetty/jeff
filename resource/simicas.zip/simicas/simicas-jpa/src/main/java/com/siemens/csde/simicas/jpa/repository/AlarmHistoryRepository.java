package com.siemens.csde.simicas.jpa.repository;

import com.siemens.csde.simicas.jpa.entity.AlarmHistoryEntity;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

/**
 * AlarmHistoryRepository HiAlarm的Dao接口
 *
 * @author z0040m9s
 * @version 1.0-SNAPSHOT
 * @date 1/8/2019 10:09 AM
 **/
@Repository
public interface AlarmHistoryRepository extends JpaRepository<AlarmHistoryEntity, String>,
        JpaSpecificationExecutor<AlarmHistoryEntity> {

    @Modifying
    void deleteById(@Param("id") String id);

    @Query(value = "SELECT a.* FROM tb_alarm_history a WHERE a.line_id = :lineId AND a.kpi= :kpi AND status = 1 ORDER BY a.alarm_time DESC LIMIT 1", nativeQuery = true)
    Optional<AlarmHistoryEntity> findLastAlarmHi(@Param("lineId") String lineId, @Param("kpi") String kpi);

    List<AlarmHistoryEntity> findByLineIdAndKpiAndStatus(String lineId, String kpi, Integer status);

    @Query(value = "SELECT COUNT(1) FROM AlarmHistoryEntity ha WHERE ha.notifyEmail=1 AND ha.alarmTime>= :from AND ha.alarmTime< :to AND ha.lineId IN( :lineIds)")
    int countEmailNotify(@Param("from") Date from, @Param("to") Date to, @Param("lineIds") List<String> lineIds);

    @Query(value = "SELECT COUNT(1) FROM AlarmHistoryEntity ha WHERE ha.notifyWeb=1 AND ha.alarmTime>= :from AND ha.alarmTime< :to AND ha.lineId IN( :lineIds)")
    int countWebNotify(@Param("from") Date from, @Param("to") Date to, @Param("lineIds") List<String> lineIds);


    @Query(value = "SELECT a.* FROM tb_alarm_history a WHERE a.line_id = :lineId AND ( (a.active_time BETWEEN :from AND :to) OR (a.recovery_time BETWEEN :from AND :to) )  AND status != 0 ORDER BY a.active_time   ", nativeQuery = true)
    List<AlarmHistoryEntity> findAlarmSectionHistory(@Param("lineId") String lineId, @Param("from") Date from, @Param("to") Date to);



    @Query(value = "SELECT a.* FROM tb_alarm_history a WHERE a.line_id = :lineId   AND a.status != 0 AND EXISTS"
            + "(  SELECT n.alarm_id  FROM tb_alarm_hi_notice n WHERE n.alarm_id=a.id AND n.status=1 AND n.biz_type = :bizType AND n.notify_type = :notifyType AND n.notify_time BETWEEN :from AND :to )  ORDER BY a.active_time   ", nativeQuery = true)
    List<AlarmHistoryEntity> findNoticeSectionHistory(@Param("lineId") String lineId, @Param("bizType") Integer bizType,@Param("notifyType") Integer notifyType,@Param("from") Date from, @Param("to") Date to);


}