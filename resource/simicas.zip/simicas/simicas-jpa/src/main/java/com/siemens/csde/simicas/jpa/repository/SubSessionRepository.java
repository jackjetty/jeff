package com.siemens.csde.simicas.jpa.repository;

import com.siemens.csde.simicas.jpa.entity.SubSessionEntity;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
public interface SubSessionRepository extends JpaRepository<SubSessionEntity, String>,
        JpaSpecificationExecutor<SubSessionEntity> {

    @Query(value = "DELETE FROM tb_subscription_session WHERE connection_id=:connectionId AND sub_id =:subId", nativeQuery = true)
    @Modifying
    @Transactional
    void deleteByConnectionIdAndSubId(@Param("connectionId") String connectionId, @Param("subId") String subId);

    @Query(value = "DELETE FROM tb_subscription_session WHERE connection_id=:connectionId", nativeQuery = true)
    @Modifying
    void deleteByConnectionId(@Param("connectionId") String connectionId);

    List<SubSessionEntity> findByConnectionId(String connectionId);

    List<SubSessionEntity> findByConnectionIdAndSubId(String connectionId, String subId);

    boolean existsByTbSubscriptionDetailId(@Param("tbSubscriptionDetailId") String tbStreamSubscriptionId);

}
