package com.siemens.csde.simicas.api.feign.config;

import com.google.gson.Gson;
import com.siemens.csde.simicas.api.constant.ServiceNameConstant;
import com.siemens.csde.simicas.api.pojo.qo.config.plan.AddPlansQo;
import com.siemens.csde.simicas.api.pojo.qo.config.plan.PlanQo;
import com.siemens.csde.simicas.api.pojo.vo.config.plan.PlanCountVo;
import com.siemens.csde.simicas.api.pojo.vo.config.plan.PlanVo;
import com.siemens.csde.simicas.common.base.BasePageVo;
import com.siemens.csde.simicas.common.base.BaseResult;
import com.siemens.csde.simicas.common.constant.enums.ResultEnum;
import java.util.Date;
import javax.validation.constraints.Pattern;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

/**
 * 计划配置api 异常处理类
 *
 * @author z0043y5h
 * @version 1.0-SNAPSHOT
 * @date 2020/2/24 0:25
 **/
@Component
@Slf4j
public class PlanServiceApiFallback implements PlanServiceApi {

    @Override
    public BaseResult addPlan(String lineId, AddPlansQo addPlansQo) {
        log.error(new Gson().toJson(new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_CONFIG + " " + ResultEnum.ERROR.getInfo())));
        return new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_CONFIG + " " + ResultEnum.ERROR.getInfo());
    }

    @Override
    public BaseResult validatePlan(String lineId, AddPlansQo addPlansQo) {
        log.error(new Gson().toJson(new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_CONFIG + " " + ResultEnum.ERROR.getInfo())));
        return new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_CONFIG + " " + ResultEnum.ERROR.getInfo());
    }

    @Override
    public BaseResult updatePlan(String lineId, String id, PlanQo planQo) {
        log.error(new Gson().toJson(new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_CONFIG + " " + ResultEnum.ERROR.getInfo())));
        return new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_CONFIG + " " + ResultEnum.ERROR.getInfo());
    }

    @Override
    public BaseResult deletePlan(String lineId, String planId) {
        log.error(new Gson().toJson(new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_CONFIG + " " + ResultEnum.ERROR.getInfo())));
        return new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_CONFIG + " " + ResultEnum.ERROR.getInfo());
    }

    @Override
    public BaseResult<BasePageVo<PlanVo>> listPlan(String lineId, Integer index, Integer size, Date planDate,
            String filter, String orderByColumn, @Pattern(regexp = "ASC|DESC") String orderByType) {
        log.error(new Gson().toJson(new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_CONFIG + " " + ResultEnum.ERROR.getInfo())));
        return new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_CONFIG + " " + ResultEnum.ERROR.getInfo());
    }

    @Override
    public BaseResult<PlanCountVo> countQuantity(String lineId, Date from, Date to) {
        log.error(new Gson().toJson(new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_CONFIG + " " + ResultEnum.ERROR.getInfo())));
        return new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_CONFIG + " " + ResultEnum.ERROR.getInfo());
    }
}
