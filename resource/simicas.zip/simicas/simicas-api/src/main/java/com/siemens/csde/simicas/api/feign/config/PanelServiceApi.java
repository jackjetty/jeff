package com.siemens.csde.simicas.api.feign.config;

import com.siemens.csde.simicas.api.constant.ServiceNameConstant;
import com.siemens.csde.simicas.api.pojo.qo.config.panel.PanelQo;
import com.siemens.csde.simicas.api.pojo.vo.config.panel.PanelVo;
import com.siemens.csde.simicas.common.base.BaseResult;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

/**
 * 面板配置 api
 *
 * @author z0043y5h
 * @version 1.0-SNAPSHOT
 * @date 2020/3/12 14:41
 **/
@FeignClient(
        name = ServiceNameConstant.SERVICE_CONFIG,
        url = "${service.config}",
        fallback = PanelServiceApiFallback.class)
@Component
public interface PanelServiceApi {

    /**
     * 编辑一条panel信息
     *
     * @param panelQo panelQo
     * @return com.siemens.csde.simicas.common.base.BaseResult<com.siemens.csde.simicas.api.pojo.vo.config.panel.PanelVo>
     * @author z0043y5h
     * @date 2020/3/12 14:25
     **/
    @PutMapping(value = "/panel/updatePanel", produces = MediaType.APPLICATION_JSON_VALUE)
    BaseResult<PanelVo> updatePanel(@RequestBody PanelQo panelQo);

    /**
     * 查询一条panel信息
     *
     * @param panelId panelId
     * @return com.siemens.csde.simicas.common.base.BaseResult<com.siemens.csde.simicas.api.pojo.vo.config.panel.PanelVo>
     * @author z0043y5h
     * @date 2020/3/12 14:35
     **/
    @GetMapping(value = "/panel/getPanel/{panelId}", produces = MediaType.APPLICATION_JSON_VALUE)
    BaseResult<PanelVo> getPanel(@PathVariable(value = "panelId") String panelId);
}
