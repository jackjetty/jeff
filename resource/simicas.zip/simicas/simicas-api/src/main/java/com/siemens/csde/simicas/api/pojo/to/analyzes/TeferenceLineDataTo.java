package com.siemens.csde.simicas.api.pojo.to.analyzes;

import com.siemens.csde.simicas.common.base.BaseTo;
import java.util.List;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

/**
 * 产线参考数据To
 *
 * @author z0043y5h
 * @version 1.0-SNAPSHOT
 * @date 2020/3/23 14:34
 **/
@Slf4j
@Getter
@Setter
public class TeferenceLineDataTo extends BaseTo {

    private static final long serialVersionUID = 5040047349132934517L;

    private Number min;

    private Number max;

    private Number avg;

    private List<TeferenceLineDataDetail> datas;

    @Getter
    @Setter
    @Builder
    public static class TeferenceLineDataDetail {

        private Number data;

        private String time;
    }
}
