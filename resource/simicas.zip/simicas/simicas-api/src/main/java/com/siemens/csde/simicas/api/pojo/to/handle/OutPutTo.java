package com.siemens.csde.simicas.api.pojo.to.handle;

import com.google.gson.annotations.SerializedName;
import com.siemens.csde.simicas.common.base.BaseTo;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

/**
 * OutPutTo
 *
 * @author z004267r
 * @version 1.0-SNAPSHOT
 * @date 3/24/2020 2:56 PM
 **/
@Setter
@Getter
@Builder
public class OutPutTo extends BaseTo {

    private static final long serialVersionUID = 1824903237258043055L;

    @SerializedName(value = "Output")
    private Integer dataValue;

    @SerializedName(value = "ChangeOver")
    private Boolean changeOver;


}
