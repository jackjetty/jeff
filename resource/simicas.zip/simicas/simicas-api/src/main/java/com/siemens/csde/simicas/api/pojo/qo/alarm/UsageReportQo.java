package com.siemens.csde.simicas.api.pojo.qo.alarm;

import com.siemens.csde.simicas.common.base.BaseQo;
import java.util.Date;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Getter
@Setter
public class UsageReportQo extends BaseQo {

    private static final long serialVersionUID = 7013087421397516404L;
    private String tenantId;
    private String timeZone;
    private Date from;
    private Date to;
}
