package com.siemens.csde.simicas.api.feign.handle;

import com.google.gson.Gson;
import com.siemens.csde.simicas.api.constant.ServiceNameConstant;
import com.siemens.csde.simicas.api.pojo.vo.config.status.LineStatusVo;
import com.siemens.csde.simicas.api.pojo.vo.handle.kpi.OverallKpiVo;
import com.siemens.csde.simicas.common.base.BaseResult;
import com.siemens.csde.simicas.common.constant.enums.ResultEnum;
import java.util.Date;
import java.util.List;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

/**
 * 总览业务api 异常处理类
 *
 * @author z0043y5h
 * @version 1.0-SNAPSHOT
 * @date 2020/2/27 1:27
 **/
@Component("handleOverallServiceApiFallback")
@Slf4j
public class OverallServiceApiFallback implements OverallServiceApi {

    @Override
    public BaseResult<List<LineStatusVo>> lineStatus(Date from, Date to) {
        log.error(new Gson().toJson(new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_CONFIG + " " + ResultEnum.ERROR.getInfo())));
        return new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_CONFIG + " " + ResultEnum.ERROR.getInfo());
    }

    @Override
    public BaseResult<OverallKpiVo> listKpi(String kpiName, Date from, Date to) {
        log.error(new Gson().toJson(new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_CONFIG + " " + ResultEnum.ERROR.getInfo())));
        return new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_CONFIG + " " + ResultEnum.ERROR.getInfo());
    }
}
