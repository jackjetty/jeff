package com.siemens.csde.simicas.api.pojo.to;

import com.siemens.csde.simicas.common.base.BaseTo;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Builder
public class DemoTo extends BaseTo {

    private static final long serialVersionUID = 5363342232258180057L;

    private String name;

    private int age;

}
