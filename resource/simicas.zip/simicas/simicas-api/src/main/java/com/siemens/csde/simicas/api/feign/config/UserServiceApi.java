package com.siemens.csde.simicas.api.feign.config;

import com.siemens.csde.simicas.api.constant.ServiceNameConstant;
import com.siemens.csde.simicas.api.pojo.vo.config.user.UserInfoVo;
import com.siemens.csde.simicas.common.base.BaseResult;
import java.util.List;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

/**
 * 用户信息api
 *
 * @author z0043y5h
 * @version 1.0-SNAPSHOT
 * @date 2020/3/20 16:30
 **/
@FeignClient(
        name = ServiceNameConstant.SERVICE_CONFIG,
        url = "${service.config}",
        fallback = UserServiceApiFallBack.class)
@Component
public interface UserServiceApi {

    /**
     * 获取用户的详细信息
     *
     * @return com.siemens.csde.simicas.common.base.BaseResult<com.siemens.csde.simicas.api.pojo.vo.config.user.UserInfoVo>
     * @author z0043y5h
     * @date 2020/3/20 16:51
     **/
    @GetMapping(value = "/user/info", produces = MediaType.APPLICATION_JSON_VALUE)
    BaseResult<UserInfoVo> getInfo();

    /**
     * 查询前缀匹配的用户邮箱
     *
     * @param prefix prefix
     * @return com.siemens.csde.simicas.common.base.BaseResult<java.util.List < java.lang.String>>
     * @author z0043y5h
     * @date 2020/3/20 16:43
     **/
    @GetMapping(value = "/user/emailAddresses", produces = MediaType.APPLICATION_JSON_VALUE)
    BaseResult<List<String>> getEmailAddresses(@RequestParam(value = "prefix") String prefix);
}
