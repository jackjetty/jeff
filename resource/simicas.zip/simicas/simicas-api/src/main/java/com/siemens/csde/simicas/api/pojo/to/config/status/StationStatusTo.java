package com.siemens.csde.simicas.api.pojo.to.config.status;

import com.siemens.csde.simicas.common.base.BaseTo;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
/**
 *  工站状态列表传输类
 * @author Z0040M9S
 * @version 1.0-SNAPSHOT
 * @date 2/12/2020 4:28 PM
 **/
@Slf4j
@Getter
@Setter
public class StationStatusTo extends BaseTo {

    private static final long serialVersionUID = 5935388038703158207L;
    private String id;

    private String workstationId;

    private String name;

    private String label;

    private String value;

    private String visual;

    private Boolean downtimeCategory;
}