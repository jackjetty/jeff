package com.siemens.csde.simicas.api.pojo.qo.config.plan;

import com.siemens.csde.simicas.common.base.BasePageQo;
import java.util.Date;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

/**
 * PlanPageQo
 *
 * @author z0043y5h
 * @version 1.0-SNAPSHOT
 * @date 2020/2/23 23:34
 **/
@Getter
@Setter
@Slf4j
public class PlanPageQo extends BasePageQo {

    private String filter;

    private String lineId;

    private Date planDate;
}
