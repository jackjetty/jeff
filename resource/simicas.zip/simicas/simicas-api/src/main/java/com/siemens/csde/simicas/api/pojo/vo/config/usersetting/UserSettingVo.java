package com.siemens.csde.simicas.api.pojo.vo.config.usersetting;

import com.siemens.csde.simicas.common.base.BaseVo;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

/**
 * UserSettingVo
 *
 * @author z0043y5h
 * @version 1.0-SNAPSHOT
 * @date 2020/3/14 0:13
 **/
@Slf4j
@Getter
@Setter
@Builder
public class UserSettingVo extends BaseVo {

    private static final long serialVersionUID = 3100139194344372158L;

    private String id;

    private String settingType;

    private String parentId;

    private String code;

    private String value;
}
