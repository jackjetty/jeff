package com.siemens.csde.simicas.api.feign.handle;

import com.siemens.csde.simicas.api.constant.ServiceNameConstant;
import com.siemens.csde.simicas.common.base.BaseResult;
import java.util.Date;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;

/**
 * 产线指标展示Api
 *
 * @author z0043y5h
 * @version 1.0-SNAPSHOT
 * @date 2020/3/22 22:17
 **/
@FeignClient(
        name = ServiceNameConstant.SERVICE_HANDLE,
        url = "${service.handle}",
        fallback = LineDetailServiceApiFallback.class)
@Component
public interface LineDetailServiceApi {

    /**
     * 获取默认指标数据
     *
     * @param lineId lineId
     * @param kpi    kpi
     * @param from   from
     * @param to     to
     * @return com.siemens.csde.simicas.common.base.BaseResult
     * @author z0043y5h
     * @date 2020/3/22 22:21
     **/
    @GetMapping("/lineDetail/defaultKpi/line/{lineId}/{kpi}")
    BaseResult defaultKpi(@PathVariable(value = "lineId") String lineId, @PathVariable(value = "kpi") String kpi,
            @RequestParam(value = "from") Date from, @RequestParam(value = "to") Date to);

    /**
     * 获取自定义指标数据
     *
     * @param kpi    kpi
     * @param lineId lineId
     * @param from   from
     * @param to     to
     * @return com.siemens.csde.simicas.common.base.BaseResult
     * @author z0043y5h
     * @date 2020/3/22 22:21
     **/
    @GetMapping("/lineDetail/customKpi/{kpi}/line/{lineId}")
    BaseResult customKpi(@PathVariable(value = "kpi") String kpi, @PathVariable(value = "lineId") String lineId,
            @RequestParam(value = "from") Date from, @RequestParam(value = "to") Date to);
}
