package com.siemens.csde.simicas.api.feign.mindsphere;

import com.siemens.csde.simicas.common.model.TenantBean;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@FeignClient(
        name = "tenant-client",
        url = "${service.advance.tenant-management:https://gateway.cn1.mindsphere-in.cn/api/tenantmanagement/v4}",
        fallback = TenantServiceApiFallback.class)
public interface TenantServiceApi {

    /**
     * 获取TechnicalUser数据
     *
     * @param token token
     * @return java.util.List<com.siemens.csde.macb.common.model.stream.IotTimeSeriesItem>
     * @author z0043y5h
     * @date 8/23/2019 5:49 PM
     */
    @RequestMapping(value = "/tenantInfo", method = RequestMethod.GET)
    TenantBean getTenantInfo(@RequestHeader("Authorization") String token);
}
