package com.siemens.csde.simicas.api.pojo.to.alarm;

import com.siemens.csde.simicas.common.base.BaseDto;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
/**
 *  告警通知策略列表传输类
 * @author Z0040M9S
 * @version 1.0-SNAPSHOT
 * @date 2/12/2020 4:28 PM
 **/
@Slf4j
@Getter
@Setter
public class AlarmCfgNotifyPolicyTo extends BaseDto {

    private static final long serialVersionUID = -6143285731629515525L;

    private String id;

    private String tenant;

    private String kpi;

    private Integer policyType;

    private Integer webLimit;

    private Integer emailLimit;

}