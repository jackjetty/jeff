package com.siemens.csde.simicas.api.pojo.qo.config.status;

import com.siemens.csde.simicas.common.base.BaseQo;
import lombok.Getter;
import lombok.Setter;

/**
 * LineStatusConfigQo
 *
 * @author z0043y5h
 * @version 1.0-SNAPSHOT
 * @date 2020/2/22 15:19
 **/
@Getter
@Setter
public class LineStatusConfigQo extends BaseQo {

    private static final long serialVersionUID = -2410767964749215138L;
    private String status;
    private String value;
    private String visual;
    private Boolean downtimeCategory;
}