package com.siemens.csde.simicas.api.pojo.to.config.kpi;

import com.google.gson.annotations.SerializedName;
import com.siemens.csde.simicas.common.base.BaseTo;
import java.util.Date;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
/**
 *  KPI 传输类
 * @author Z0040M9S
 * @version 1.0-SNAPSHOT
 * @date 2/12/2020 4:28 PM
 **/
@Setter
@Getter
public class KpiTo extends BaseTo {

    private static final long serialVersionUID = -2551657199606665455L;
    private String id;
    private String parentId;
    private Integer level;
    private String name;
    private String formula;
    private Integer type;
    private String unit;
    private List<KpiTo> children;
    private String value;
    private String visual;
    private String label;
    private Boolean downtimeCategory;
    private Integer errorCode;
    @SerializedName(value = "_time", alternate = "time")
    private Date time;
}