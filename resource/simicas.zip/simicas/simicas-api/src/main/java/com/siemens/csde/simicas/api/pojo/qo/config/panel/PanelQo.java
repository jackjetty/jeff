package com.siemens.csde.simicas.api.pojo.qo.config.panel;

import com.siemens.csde.simicas.common.base.BaseQo;
import lombok.Getter;
import lombok.Setter;

/**
 * PanelQo
 *
 * @author z0043y5h
 * @version 1.0-SNAPSHOT
 * @date 2020/3/12 14:31
 **/
@Getter
@Setter
public class PanelQo extends BaseQo {

    private static final long serialVersionUID = 3381993706670239072L;

    private String panelId;

    private String title;

    private String url;
}
