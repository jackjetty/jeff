package com.siemens.csde.simicas.api.pojo.qo.config.usersetting;

import com.siemens.csde.simicas.common.base.BaseQo;
import lombok.Getter;
import lombok.Setter;

/**
 * UserSettingQo
 *
 * @author z0043y5h
 * @version 1.0-SNAPSHOT
 * @date 2020/3/13 23:57
 **/
@Getter
@Setter
public class UserSettingQo extends BaseQo {

    private static final long serialVersionUID = 6166874831613647154L;

    private String id;

    private String parentId;

    private String settingType;

    private String value;

    private String code;

    private String packageType;
}
