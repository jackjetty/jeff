package com.siemens.csde.simicas.api.pojo.to.analyzes;

import com.siemens.csde.simicas.common.base.BaseTo;
import java.util.List;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

/**
 * 产线数据To
 *
 * @author z0043y5h
 * @version 1.0-SNAPSHOT
 * @date 2020/3/23 14:37
 **/
@Setter
@Getter
@Builder
@Slf4j
public class LineDataTo extends BaseTo {

    private static final long serialVersionUID = -5389593500924834815L;

    private String lineId;

    private String lineName;

    private List<LineDataDetail> datas;

    private List<ProductDataByLineTo> products;

    @Getter
    @Setter
    @Builder
    public static class LineDataDetail {

        private Number data;

        private String type;

        private String time;

        private String from;

        private String to;

        private String unit;

        private String format;
    }
}
