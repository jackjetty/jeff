package com.siemens.csde.simicas.api.pojo.to.analyzes;

import com.siemens.csde.simicas.api.pojo.to.analyzes.ProductDataByLineTo.ProductDataDetail;
import com.siemens.csde.simicas.common.base.BaseTo;
import java.util.List;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

/**
 * 产品数据 by station To
 *
 * @author z0043y5h
 * @version 1.0-SNAPSHOT
 * @date 2020/3/23 14:37
 **/
@Slf4j
@Builder
@Getter
@Setter
public class ProductDataByStationTo extends BaseTo {

    private static final long serialVersionUID = -6708429072953140073L;

    private String productId;

    private String productName;

    private List<StationDataTo> stations;

    private List<ProductDataDetail> datas;


}