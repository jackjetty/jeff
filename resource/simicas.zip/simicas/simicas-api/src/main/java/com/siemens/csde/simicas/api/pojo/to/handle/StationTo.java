package com.siemens.csde.simicas.api.pojo.to.handle;

import com.siemens.csde.simicas.common.base.BaseTo;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

/**
 * StationTo
 *
 * @author z004267r
 * @version 1.0-SNAPSHOT
 * @date 3/16/2020 12:01 PM
 **/
@Getter
@Setter
@Builder
public class StationTo extends BaseTo {

    private static final long serialVersionUID = -7696774503606757627L;

    private String stationId;

    private String stationName;

}
