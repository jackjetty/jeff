package com.siemens.csde.simicas.api.feign.alarm;

import com.google.gson.Gson;
import com.siemens.csde.simicas.api.constant.ServiceNameConstant;
import com.siemens.csde.simicas.api.pojo.qo.alarm.JudgeAlarmQo;
import com.siemens.csde.simicas.api.pojo.qo.alarm.NotifyPolicyQo;
import com.siemens.csde.simicas.api.pojo.qo.alarm.RuleQo;
import com.siemens.csde.simicas.api.pojo.to.alarm.AlarmCfgKpiTo;
import com.siemens.csde.simicas.api.pojo.to.alarm.AlarmCfgNotifyPolicyTo;
import com.siemens.csde.simicas.api.pojo.to.alarm.AlarmCfgRuleTo;
import com.siemens.csde.simicas.api.pojo.vo.alarm.AlarmDataVo;
import com.siemens.csde.simicas.api.pojo.vo.alarm.JudgeAlarmVo;
import com.siemens.csde.simicas.common.base.BaseResult;
import com.siemens.csde.simicas.common.constant.enums.ResultEnum;
import java.util.Date;
import java.util.List;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
/**
 *  告警失败处理类
 * @author Z0040M9S
 * @version 1.0-SNAPSHOT
 * @date 2/12/2020 4:28 PM
 **/
@Component
@Slf4j
public class AlarmServiceApiFallback implements AlarmServiceApi{
    

    @Override
    public BaseResult<JudgeAlarmVo> judgeAlarm( String kpi,JudgeAlarmQo judgeAlarmQo) {
        log.error(new Gson().toJson(new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_ALARM+" "+ ResultEnum.ERROR.getInfo())));
        return new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_ALARM+" "+ ResultEnum.ERROR.getInfo());
    }


    @Override
    public BaseResult<String> addNotifyPolicy(NotifyPolicyQo notifyPolicyQo) {
        log.error(new Gson().toJson(new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_ALARM+" "+ ResultEnum.ERROR.getInfo())));
        return new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_ALARM+" "+ ResultEnum.ERROR.getInfo());
    }


    @Override
    public BaseResult<String> updateNotifyPolicy(String id, NotifyPolicyQo notifyPolicyQo) {
        log.error(new Gson().toJson(new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_ALARM+" "+ ResultEnum.ERROR.getInfo())));
        return new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_ALARM+" "+ ResultEnum.ERROR.getInfo());
    }


    @Override
    public BaseResult<String> deleteNotifyPolicy( String id) {
        log.error(new Gson().toJson(new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_ALARM+" "+ ResultEnum.ERROR.getInfo())));
        return new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_ALARM+" "+ ResultEnum.ERROR.getInfo());
    }

    @Override
    public BaseResult<List<AlarmCfgNotifyPolicyTo>> listNotifyPolicy(String lineId) {
        log.error(new Gson().toJson(new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_ALARM+" "+ ResultEnum.ERROR.getInfo())));
        return new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_ALARM+" "+ ResultEnum.ERROR.getInfo());
    }

    @Override
    public BaseResult<String> addRule(RuleQo ruleQo) {
        log.error(new Gson().toJson(new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_ALARM+" "+ ResultEnum.ERROR.getInfo())));
        return new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_ALARM+" "+ ResultEnum.ERROR.getInfo());
    }

    @Override
    public BaseResult<String> updateRule(String id, RuleQo ruleQo) {
        log.error(new Gson().toJson(new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_ALARM+" "+ ResultEnum.ERROR.getInfo())));
        return new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_ALARM+" "+ ResultEnum.ERROR.getInfo());
    }

    @Override
    public BaseResult<String> deleteRule(String id) {
        log.error(new Gson().toJson(new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_ALARM+" "+ ResultEnum.ERROR.getInfo())));
        return new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_ALARM+" "+ ResultEnum.ERROR.getInfo());
    }

    @Override
    public BaseResult<List<AlarmCfgRuleTo>> listRule(String lineId) {
        log.error(new Gson().toJson(new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_ALARM+" "+ ResultEnum.ERROR.getInfo())));
        return new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_ALARM+" "+ ResultEnum.ERROR.getInfo());
    }
    @Override
    public BaseResult<List<AlarmCfgKpiTo>> listKpi(String lineId) {
        log.error(new Gson().toJson(new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_ALARM+" "+ ResultEnum.ERROR.getInfo())));
        return new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_ALARM+" "+ ResultEnum.ERROR.getInfo());
    }

    @Override
    public BaseResult<AlarmDataVo> alarmList(String lineId, Date from, Date to) {
        log.error(new Gson().toJson(new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_ALARM+" "+ ResultEnum.ERROR.getInfo())));
        return new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_ALARM+" "+ ResultEnum.ERROR.getInfo());
    }

    @Override
    public BaseResult<AlarmDataVo> noticeList(String lineId, Date from, Date to) {
        log.error(new Gson().toJson(new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_ALARM+" "+ ResultEnum.ERROR.getInfo())));
        return new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_ALARM+" "+ ResultEnum.ERROR.getInfo());
    }


}
