package com.siemens.csde.simicas.api.feign.hub;

import com.siemens.csde.simicas.api.constant.ServiceNameConstant;
import com.siemens.csde.simicas.api.pojo.vo.DemoVo;
import com.siemens.csde.simicas.common.base.BaseResult;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 * ScheduleServiceApi
 *
 * @author z004267r
 * @version 1.0-SNAPSHOT
 * @date 3/9/2020 5:04 PM
 **/
@FeignClient(
        name = ServiceNameConstant.SERVICE_HUB,
        url = "${service.hub}",
        fallback = ScheduleServiceApiFallback.class)
@Component
public interface ScheduleServiceApi {

    @RequestMapping(value = "/schedule/execute", method = RequestMethod.GET)
    BaseResult<DemoVo> execute();

}