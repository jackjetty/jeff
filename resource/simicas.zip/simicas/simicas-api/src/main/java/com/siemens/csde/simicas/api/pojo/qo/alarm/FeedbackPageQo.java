package com.siemens.csde.simicas.api.pojo.qo.alarm;

import com.siemens.csde.simicas.common.base.BasePageQo;
import java.util.Date;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

/**
 * 反馈分页查询Qo
 *
 * @author z0043y5h
 * @version 1.0-SNAPSHOT
 * @date 2020/3/23 14:13
 **/
@Slf4j
@Getter
@Setter
public class FeedbackPageQo extends BasePageQo {

    private static final long serialVersionUID = 8363053317271245827L;

    private Date from;

    private Date to;
}
