package com.siemens.csde.simicas.api.feign.analyzes;

import com.google.gson.Gson;
import com.siemens.csde.simicas.api.constant.ServiceNameConstant;
import com.siemens.csde.simicas.api.pojo.vo.analyzes.CollectLineByLineVo;
import com.siemens.csde.simicas.api.pojo.vo.analyzes.CollectProductByLineVo;
import com.siemens.csde.simicas.api.pojo.vo.analyzes.CollectStationByStationVo;
import com.siemens.csde.simicas.common.base.BaseResult;
import com.siemens.csde.simicas.common.constant.enums.ResultEnum;
import java.util.Date;
import java.util.List;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

/**
 * 绩效统计api 异常处理类
 *
 * @author z0043y5h
 * @version 1.0-SNAPSHOT
 * @date 2020/3/23 14:23
 **/
@Component
@Slf4j
public class PerformanceServiceApiFallback implements PerformanceServiceApi {


    @Override
    public BaseResult<CollectLineByLineVo> statisticLineEFF(List<String> lineIds, List<String> productIds, Date from, Date to, String dataUnit,
            Integer particleSize, Integer timeZone) {
        log.error(new Gson().toJson(new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_ANALYZES + " " + ResultEnum.ERROR.getInfo())));
        return new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_ANALYZES + " " + ResultEnum.ERROR.getInfo());
    }

    @Override
    public BaseResult<CollectStationByStationVo> statisticStationEFF(String lineId, List<String> stationIds, List<String> productIds, Date from,
            Date to, String dataUnit, Integer particleSize, Integer timeZone) {
        log.error(new Gson().toJson(new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_ANALYZES + " " + ResultEnum.ERROR.getInfo())));
        return new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_ANALYZES + " " + ResultEnum.ERROR.getInfo());
    }

    @Override
    public BaseResult<CollectLineByLineVo> statisticLineLTH(List<String> lineIds, List<String> productIds, Date from, Date to, String dataUnit,
            Integer particleSize, Integer timeZone) {
        log.error(new Gson().toJson(new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_ANALYZES + " " + ResultEnum.ERROR.getInfo())));
        return new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_ANALYZES + " " + ResultEnum.ERROR.getInfo());
    }

    @Override
    public BaseResult<CollectStationByStationVo> statisticStationLTH(String lineId, List<String> stationIds, List<String> productIds, Date from,
            Date to, String dataUnit, Integer particleSize, Integer timeZone) {
        log.error(new Gson().toJson(new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_ANALYZES + " " + ResultEnum.ERROR.getInfo())));
        return new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_ANALYZES + " " + ResultEnum.ERROR.getInfo());
    }

    @Override
    public BaseResult<CollectProductByLineVo> statisticOutput(List<String> lineIds, List<String> productIds, Date from, Date to, String dataUnit, Integer particleSize,
            Integer timeZone) {
        log.error(new Gson().toJson(new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_ANALYZES + " " + ResultEnum.ERROR.getInfo())));
        return new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_ANALYZES + " " + ResultEnum.ERROR.getInfo());
    }


}
