package com.siemens.csde.simicas.api.pojo.vo.alarm;

import com.siemens.csde.simicas.common.base.BaseVo;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

/**
 * 告警历史数据Vo
 *
 * @author z0043y5h
 * @version 1.0-SNAPSHOT
 * @date 2020/3/23 13:10
 **/
@Slf4j
@Getter
@Setter
public class AlarmHiVo extends BaseVo {

    private static final long serialVersionUID = -1427618910170651619L;

    private String lineId;

    private String lineName;

    private String productId;

    private String productName;

    private String orderId;

    private AlarmHiDetail detail;

    @Getter
    @Setter
    @Builder
    public static class AlarmHiDetail {

        private String id;

        private String value;

        private String rules;

        private Boolean highlight;

        private Boolean notifyWeb;

        private String alarmLevel;

        private String messageType;

        private String activeTime;

        private String recoveryTime;

        private String unit;

        private Boolean read;
    }
}
