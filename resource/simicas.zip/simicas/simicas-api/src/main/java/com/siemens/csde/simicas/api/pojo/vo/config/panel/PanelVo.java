package com.siemens.csde.simicas.api.pojo.vo.config.panel;

import com.siemens.csde.simicas.common.base.BaseVo;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

/**
 * PanelVo
 *
 * @author z0043y5h
 * @version 1.0-SNAPSHOT
 * @date 2020/3/14 0:38
 **/
@Slf4j
@Getter
@Setter
public class PanelVo extends BaseVo {

    private static final long serialVersionUID = 7095854043972882547L;

    private String panelId;

    private String title;

    private String url;
}
