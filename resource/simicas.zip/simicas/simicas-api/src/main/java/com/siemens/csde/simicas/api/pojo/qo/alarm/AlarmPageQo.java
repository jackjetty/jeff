package com.siemens.csde.simicas.api.pojo.qo.alarm;

import com.siemens.csde.simicas.common.base.BasePageQo;
import java.util.Date;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

/**
 * 告警分页Qo
 *
 * @author z0043y5h
 * @version 1.0-SNAPSHOT
 * @date 2020/3/23 11:52
 **/
@Slf4j
@Getter
@Setter
public class AlarmPageQo extends BasePageQo {

    private static final long serialVersionUID = -6848904525697963603L;

    private String lineId;

    private Integer type;

    private Date from;

    private Date to;

    private String filter;
}
