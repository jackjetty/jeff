package com.siemens.csde.simicas.api.feign.analyzes;

import com.siemens.csde.simicas.api.constant.ServiceNameConstant;
import com.siemens.csde.simicas.api.pojo.vo.analyzes.CollectLineByLineVo;
import com.siemens.csde.simicas.common.base.BaseResult;
import java.util.Date;
import java.util.List;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

/**
 * 维护统计Api
 *
 * @author z0043y5h
 * @version 1.0-SNAPSHOT
 * @date 2020/3/23 16:48
 **/
@FeignClient(
        name = ServiceNameConstant.SERVICE_ANALYZES,
        url = "${service.analyzes}",
        fallback = MaintenanceServiceApiFallback.class)
@Component
public interface MaintenanceServiceApi {


    /**
     * STOP COUNT top 统计
     * @author Z0040M9S
     * @param lineIds :
     * @param productIds :
     * @param from :
     * @param to :
     * @param dataUnit :
     * @param stopCode :
     * @param particleSize :
     * @param timeZone :
     * @return : com.siemens.csde.simicas.common.base.BaseResult<com.siemens.csde.simicas.api.pojo.vo.analyzes.CollectLineByLineVo>
     * @date   4/23/2020 3:18 PM
     */
    @RequestMapping(value = "/maintenance/stop/count/top", method = RequestMethod.GET )
    BaseResult<CollectLineByLineVo> statisticStopCountTop(@RequestParam(value = "lineIds", required = false) List<String> lineIds,
            @RequestParam(value = "productIds", required = false) List<String> productIds,
            @RequestParam(value = "from", required = false) Date from,
            @RequestParam(value = "to", required = false) Date to,
            @RequestParam(value = "dataUnit", required = false) String dataUnit,
            @RequestParam(value = "stopCode", required = false) String stopCode,
            @RequestParam(value = "particleSize", required = false) Integer particleSize,
            @RequestParam(value = "timeZone", required = false) Integer timeZone) ;

    /**
     * stop 时间top统计
     * @author Z0040M9S
     * @param lineIds :
     * @param productIds :
     * @param from :
     * @param to :
     * @param dataUnit :
     * @param stopCode :
     * @param particleSize :
     * @param timeZone :
     * @return : com.siemens.csde.simicas.common.base.BaseResult<com.siemens.csde.simicas.api.pojo.vo.analyzes.CollectLineByLineVo>
     * @date   4/23/2020 3:18 PM
     */
    @RequestMapping(value = "/maintenance/stop/min/top", method = RequestMethod.GET )
    BaseResult<CollectLineByLineVo> statisticStopMinTop(@RequestParam(value = "lineIds", required = false) List<String> lineIds,
            @RequestParam(value = "productIds", required = false) List<String> productIds,
            @RequestParam(value = "from", required = false) Date from,
            @RequestParam(value = "to", required = false) Date to,
            @RequestParam(value = "dataUnit", required = false) String dataUnit,
            @RequestParam(value = "stopCode", required = false) String stopCode,
            @RequestParam(value = "particleSize", required = false) Integer particleSize,
            @RequestParam(value = "timeZone", required = false) Integer timeZone);

    /**
     * 停机次数统计查询
     * @author Z0040M9S
     * @param lineIds :
     * @param productIds :
     * @param from :
     * @param to :
     * @param dataUnit :
     * @param stopCode :
     * @param particleSize :
     * @param timeZone :
     * @return : com.siemens.csde.simicas.common.base.BaseResult<com.siemens.csde.simicas.api.pojo.vo.analyzes.CollectLineByLineVo>
     * @date   4/23/2020 3:19 PM
     */
    @RequestMapping(value = "/maintenance/stop/count/info", method = RequestMethod.GET )
    BaseResult<CollectLineByLineVo> statisticStopCountInfo(@RequestParam(value = "lineIds", required = false) List<String> lineIds,
            @RequestParam(value = "productIds", required = false) List<String> productIds,
            @RequestParam(value = "from", required = false) Date from,
            @RequestParam(value = "to", required = false) Date to,
            @RequestParam(value = "dataUnit", required = false) String dataUnit,
            @RequestParam(value = "stopCode", required = false) String stopCode,
            @RequestParam(value = "particleSize", required = false) Integer particleSize,
            @RequestParam(value = "timeZone", required = false) Integer timeZone);

    /**
     * 停机时长查询
     * @author Z0040M9S
     * @param lineIds :
     * @param productIds :
     * @param from :
     * @param to :
     * @param dataUnit :
     * @param stopCode :
     * @param particleSize :
     * @param timeZone :
     * @return : com.siemens.csde.simicas.common.base.BaseResult<com.siemens.csde.simicas.api.pojo.vo.analyzes.CollectLineByLineVo>
     * @date   4/23/2020 3:19 PM
     */
    @RequestMapping(value = "/maintenance/stop/min/info", method = RequestMethod.GET )
    BaseResult<CollectLineByLineVo> statisticStopMinInfo(@RequestParam(value = "lineIds", required = false) List<String> lineIds,
            @RequestParam(value = "productIds", required = false) List<String> productIds,
            @RequestParam(value = "from", required = false) Date from,
            @RequestParam(value = "to", required = false) Date to,
            @RequestParam(value = "dataUnit", required = false) String dataUnit,
            @RequestParam(value = "stopCode", required = false) String stopCode,
            @RequestParam(value = "particleSize", required = false) Integer particleSize,
            @RequestParam(value = "timeZone", required = false) Integer timeZone);

    /**
     * mtbf 查询统计
     * @author Z0040M9S
     * @param lineIds :
     * @param productIds :
     * @param from :
     * @param to :
     * @param dataUnit :
     * @param stopCode :
     * @param particleSize :
     * @param timeZone :
     * @return : com.siemens.csde.simicas.common.base.BaseResult<com.siemens.csde.simicas.api.pojo.vo.analyzes.CollectLineByLineVo>
     * @date   4/23/2020 3:20 PM
     */
    @RequestMapping(value = "/maintenance/mtbf/info", method = RequestMethod.GET )
    BaseResult<CollectLineByLineVo> statisticMtbfInfo(@RequestParam(value = "lineIds", required = false) List<String> lineIds,
            @RequestParam(value = "productIds", required = false) List<String> productIds,
            @RequestParam(value = "from", required = false) Date from,
            @RequestParam(value = "to", required = false) Date to,
            @RequestParam(value = "dataUnit", required = false) String dataUnit,
            @RequestParam(value = "stopCode", required = false) String stopCode,
            @RequestParam(value = "particleSize", required = false) Integer particleSize,
            @RequestParam(value = "timeZone", required = false) Integer timeZone);
}
