package com.siemens.csde.simicas.api.feign.alarm;

import com.siemens.csde.simicas.api.constant.ServiceNameConstant;
import com.siemens.csde.simicas.api.pojo.vo.alarm.AlarmHiVo;
import com.siemens.csde.simicas.common.base.BasePageVo;
import com.siemens.csde.simicas.common.base.BaseResult;
import java.util.Date;
import javax.validation.constraints.Pattern;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;

/**
 * 历史数据Api
 *
 * @author z0043y5h
 * @version 1.0-SNAPSHOT
 * @date 2020/3/23 11:45
 **/
@FeignClient(
        name = ServiceNameConstant.SERVICE_ALARM,
        url = "${service.alarm}",
        fallback = com.siemens.csde.simicas.api.feign.alarm.HistoryServiceApiFallback.class)
@Component("alarmHistoryServiceApi")
public interface HistoryServiceApi {

    /**
     * 根据产线id和告警id删除告警
     *
     * @param lineId  产线id
     * @param alarmId 告警id
     * @return com.siemens.csde.simicas.common.base.BaseResult
     * @author z0043y5h
     * @date 2020/3/23 11:49
     **/
    @DeleteMapping(value = "/history/deleteAlarm/line/{lineId}/{alarmId}", produces = MediaType.APPLICATION_JSON_VALUE)
    BaseResult deleteAlarm(@PathVariable(value = "lineId") String lineId,
            @PathVariable(value = "alarmId") String alarmId);

    /**
     * 获取特定产线报警历史记录
     *
     * @param lineId        产线Id
     * @param from          from
     * @param to            to
     * @param type          type
     * @param index         index
     * @param size          size
     * @param filter        filter过滤
     * @param orderByColumn 排序字段
     * @param orderByType   排序类型
     * @return com.siemens.csde.simicas.common.base.BaseResult<com.siemens.csde.simicas.common.base.BasePageVo <
            * com.siemens.csde.simicas.api.pojo.vo.alarm.AlarmHiVo>>
     * @author z0043y5h
     * @date 2020/3/23 13:19
     **/
    @GetMapping(value = "/history/listAlarm/line/{lineId}", produces = MediaType.APPLICATION_JSON_VALUE)
    BaseResult<BasePageVo<AlarmHiVo>> listAlarm(@PathVariable(value = "lineId") String lineId,
            @RequestParam(value = "from", required = false) Date from,
            @RequestParam(value = "to", required = false) Date to,
            @RequestParam(value = "type", required = false) Integer type,
            @RequestParam(value = "index", required = false) Integer index,
            @RequestParam(value = "size", required = false) Integer size,
            @RequestParam(value = "filter", required = false) String filter,
            @RequestParam(value = "orderByColumn", required = false) String orderByColumn,
            @RequestParam(value = "orderByType", required = false) @Pattern(regexp = "ASC|DESC") String orderByType);
}
