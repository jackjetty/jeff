package com.siemens.csde.simicas.api.pojo.vo.analyzes;

import com.siemens.csde.simicas.api.pojo.to.analyzes.LineDataTo;
import com.siemens.csde.simicas.api.pojo.to.analyzes.TeferenceLineDataTo;
import com.siemens.csde.simicas.common.base.BaseVo;
import java.util.List;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CollectLineByLineVo extends BaseVo{

    private static final long serialVersionUID = 2065663193854550773L;

    private List<LineDataTo> lines;

    private TeferenceLineDataTo referenceLine;

    private Integer paticleSize;

    private String dataUnit;
}