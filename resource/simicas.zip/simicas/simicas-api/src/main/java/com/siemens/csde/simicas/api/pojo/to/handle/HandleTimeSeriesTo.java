package com.siemens.csde.simicas.api.pojo.to.handle;

import com.siemens.csde.simicas.common.base.BaseTo;
import com.siemens.csde.simicas.common.constant.enums.EntityEnum;
import com.siemens.csde.simicas.common.constant.enums.KpiModeEnum;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

/**
 * HandleIotTiemSeriesTo
 *
 * @author z004267r
 * @version 1.0-SNAPSHOT
 * @date 3/16/2020 11:47 AM
 **/
@Getter
@Setter
@Builder
public class HandleTimeSeriesTo extends BaseTo {

    private static final long serialVersionUID = 1217407808516627917L;

    private String tenant;
    private KpiModeEnum kpiMode;
    private EntityEnum entity;
    private String kpi;
    private String lineId;
    private String stationId;
    private String lineName;
    private String time;
    private String timeSeriesJson;

}
