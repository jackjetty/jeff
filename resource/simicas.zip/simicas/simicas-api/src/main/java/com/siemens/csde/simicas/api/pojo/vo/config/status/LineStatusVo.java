package com.siemens.csde.simicas.api.pojo.vo.config.status;

import com.google.gson.annotations.SerializedName;
import com.siemens.csde.simicas.common.base.BaseVo;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

/**
 * 产线状态Vo
 *
 * @author z0043y5h
 * @version 1.0-SNAPSHOT
 * @date 2020/3/24 22:01
 **/
@Slf4j
@Getter
@Setter
public class LineStatusVo extends BaseVo {

    private static final long serialVersionUID = -3739674332685570557L;

    private String id;

    private Boolean downtimeCategory;

    private String lineId;

    private String lineName;

    private String label;

    private String status;

    private Integer errorCode;

    private String value;

    private String visual;

    @SerializedName(value = "_time", alternate = "time")
    private String time;
}
