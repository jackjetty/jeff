package com.siemens.csde.simicas.api.pojo.vo.handle.kpi;

import com.google.gson.annotations.SerializedName;
import com.siemens.csde.simicas.common.base.BaseVo;
import java.util.List;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

/**
 * 总览指标Vo
 *
 * @author z0043y5h
 * @version 1.0-SNAPSHOT
 * @date 2020/3/21 23:19
 **/
@Setter
@Getter
@Builder
public class OverallKpiVo extends BaseVo {

    private static final long serialVersionUID = 6802074885303001610L;

    private String kpiName;

    private String total;

    private String value;

    private String unit;

    private Integer errorCode;

    private List<OverallDetail> detail;

    @Getter
    @Setter
    @Builder
    public static class OverallDetail {

        @SerializedName("_time")
        private String time;

        private String lineId;

        private String lineName;

        private String value;

        private String status;

        private String level;

        private String visual;

        private Integer errorCode;

    }
}
