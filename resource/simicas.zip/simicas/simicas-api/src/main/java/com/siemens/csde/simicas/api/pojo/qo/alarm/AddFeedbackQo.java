package com.siemens.csde.simicas.api.pojo.qo.alarm;

import com.siemens.csde.simicas.common.base.BaseQo;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

/**
 * 新增反馈Qo
 *
 * @author z0043y5h
 * @version 1.0-SNAPSHOT
 * @date 2020/3/23 14:02
 **/
@Slf4j
@Getter
@Setter
public class AddFeedbackQo extends BaseQo {

    private static final long serialVersionUID = -7312555512239798317L;

    private String type;

    private String title;

    private String content;
}
