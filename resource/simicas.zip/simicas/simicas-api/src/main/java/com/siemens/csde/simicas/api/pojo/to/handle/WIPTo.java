package com.siemens.csde.simicas.api.pojo.to.handle;

import com.google.gson.annotations.SerializedName;
import com.siemens.csde.simicas.common.base.BaseTo;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

/**
 * WIPTo
 *
 * @author z004267r
 * @version 1.0-SNAPSHOT
 * @date 3/24/2020 3:28 PM
 **/
@Setter
@Getter
@Builder
public class WIPTo extends BaseTo {

    private static final long serialVersionUID = 5611127370128515989L;

    @SerializedName(value = "WIP")
    private Integer dataValue;

    @SerializedName(value = "ChangeOver")
    private Boolean changeOver;

}
