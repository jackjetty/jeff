package com.siemens.csde.simicas.api.pojo.vo.analyzes;

import com.siemens.csde.simicas.common.base.BaseVo;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import lombok.extern.slf4j.Slf4j;

/**
 * 收藏数据Vo
 *
 * @author z0043y5h
 * @version 1.0-SNAPSHOT
 * @date 2020/3/23 17:59
 **/
@ToString
@Getter
@Setter
@Slf4j
@Builder
public class FavoriteVo extends BaseVo {

    private static final long serialVersionUID = -7901798962278160376L;

    private String id;

    private String pageUrl;

    private String pageInfo;

    private Integer pageType;

    private String title;

    private String time;
}
