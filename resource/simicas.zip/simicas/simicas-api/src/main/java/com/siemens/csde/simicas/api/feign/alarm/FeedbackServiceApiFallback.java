package com.siemens.csde.simicas.api.feign.alarm;

import com.google.gson.Gson;
import com.siemens.csde.simicas.api.constant.ServiceNameConstant;
import com.siemens.csde.simicas.api.pojo.qo.alarm.AddFeedbackQo;
import com.siemens.csde.simicas.api.pojo.vo.alarm.FeedbackVo;
import com.siemens.csde.simicas.common.base.BasePageVo;
import com.siemens.csde.simicas.common.base.BaseResult;
import com.siemens.csde.simicas.common.constant.enums.ResultEnum;
import java.util.Date;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

/**
 * FeedbackServiceApi 异常处理类
 *
 * @author z0043y5h
 * @version 1.0-SNAPSHOT
 * @date 2020/3/23 14:04
 **/
@Component
@Slf4j
public class FeedbackServiceApiFallback implements FeedbackServiceApi {

    @Override
    public BaseResult<String> addFeedback(AddFeedbackQo addFeedbackQo) {
        log.error(new Gson().toJson(new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_ALARM + " " + ResultEnum.ERROR.getInfo())));
        return new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_ALARM + " " + ResultEnum.ERROR.getInfo());
    }

    @Override
    public BaseResult<BasePageVo<FeedbackVo>> listFeedback(Date from, Date to, Integer index, Integer size) {
        log.error(new Gson().toJson(new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_ALARM + " " + ResultEnum.ERROR.getInfo())));
        return new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_ALARM + " " + ResultEnum.ERROR.getInfo());
    }
}
