package com.siemens.csde.simicas.api.feign.analyzes;

import com.google.gson.Gson;
import com.siemens.csde.simicas.api.constant.ServiceNameConstant;
import com.siemens.csde.simicas.api.pojo.qo.analyzes.CompareQo;
import com.siemens.csde.simicas.api.pojo.vo.analyzes.CompareVo;
import com.siemens.csde.simicas.common.base.BaseResult;
import com.siemens.csde.simicas.common.constant.enums.ResultEnum;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

/**
 * 比较api 异常处理类
 *
 * @author z0043y5h
 * @version 1.0-SNAPSHOT
 * @date 2020/3/23 17:47
 **/
@Component
@Slf4j
public class CompareServiceApiFallback implements CompareServiceApi {

    @Override
    public BaseResult addCompare(CompareQo compareQo) {
        log.error(new Gson().toJson(new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_ANALYZES + " " + ResultEnum.ERROR.getInfo())));
        return new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_ANALYZES + " " + ResultEnum.ERROR.getInfo());
    }

    @Override
    public BaseResult updateCompare(String id, CompareQo compareQo) {
        log.error(new Gson().toJson(new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_ANALYZES + " " + ResultEnum.ERROR.getInfo())));
        return new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_ANALYZES + " " + ResultEnum.ERROR.getInfo());
    }

    @Override
    public BaseResult deleteCompare(String id) {
        log.error(new Gson().toJson(new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_ANALYZES + " " + ResultEnum.ERROR.getInfo())));
        return new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_ANALYZES + " " + ResultEnum.ERROR.getInfo());
    }

    @Override
    public BaseResult<CompareVo> getCompare() {
        log.error(new Gson().toJson(new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_ANALYZES + " " + ResultEnum.ERROR.getInfo())));
        return new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_ANALYZES + " " + ResultEnum.ERROR.getInfo());
    }
}
