package com.siemens.csde.simicas.api.pojo.qo.alarm;

import com.siemens.csde.simicas.common.base.BaseQo;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

/**
 * 标记通知Qo
 *
 * @author z0043y5h
 * @version 1.0-SNAPSHOT
 * @date 2020/3/23 14:13
 **/
@Slf4j
@Getter
@Setter
public class MarkAlarmNoticesQo extends BaseQo {

    private static final long serialVersionUID = 6535059788569627067L;

    private List<MarkNoticeSubQo> alarms;

    private String userId;

    @Getter
    @Setter
    public static class MarkNoticeSubQo {

        private String id;

        private Boolean read;

    }
}