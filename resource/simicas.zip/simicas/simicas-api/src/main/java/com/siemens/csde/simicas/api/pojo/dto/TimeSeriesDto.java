package com.siemens.csde.simicas.api.pojo.dto;

import com.google.gson.annotations.SerializedName;
import com.siemens.csde.simicas.common.base.BaseDto;
import com.siemens.csde.simicas.common.model.IotTimeSeriesBean;
import java.util.List;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Builder
public class TimeSeriesDto extends BaseDto {

    public String tenant;

    private String assetId;

    private String lineId;

    private String lineName;

    private String aspectName;

    private Integer index;

    private Integer kpiType;

    @SerializedName("timeSeries")
    private List<IotTimeSeriesBean> iotTimeSeriesBeans;


}
