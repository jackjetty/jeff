package com.siemens.csde.simicas.api.pojo.to.handle;

import com.siemens.csde.simicas.common.base.BaseTo;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

/**
 * LineTo
 *
 * @author z004267r
 * @version 1.0-SNAPSHOT
 * @date 3/16/2020 12:00 PM
 **/
@Getter
@Setter
@Builder
public class LineTo extends BaseTo {

    private static final long serialVersionUID = 7389271129157651927L;

    private String tenant;

    private String lineId;

    private String lineName;

    private String assetId;

    private Integer index;

}
