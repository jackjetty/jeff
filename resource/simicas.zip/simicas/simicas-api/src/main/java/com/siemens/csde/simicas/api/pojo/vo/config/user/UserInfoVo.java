package com.siemens.csde.simicas.api.pojo.vo.config.user;

import com.siemens.csde.simicas.common.base.BaseVo;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

/**
 * 用户信息Vo
 *
 * @author z0043y5h
 * @version 1.0-SNAPSHOT
 * @date 2020/3/20 16:49
 **/
@Slf4j
@Getter
@Setter
public class UserInfoVo extends BaseVo {

    private static final long serialVersionUID = -7866968064417178386L;

    private String userId;

    private String userName;

    private String email;

    private String tenant;

    private String subTenant;
}
