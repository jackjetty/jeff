package com.siemens.csde.simicas.api.pojo.dto;

import com.siemens.csde.simicas.common.base.BaseDto;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

/**
 * Tech用户Dto
 *
 * @author z0043y5h
 * @version 1.0-SNAPSHOT
 * @date 2020/3/30 13:19
 **/
@Slf4j
@Getter
@Setter
public class TechnicalUserDto extends BaseDto {

    private static final long serialVersionUID = 834665534252376343L;

    private String id;

    private String userName;

    private Name name;

    private List<Group> groups;

    @Getter
    @Setter
    public static class Group {

        private String display;

        private String type;

        private String value;
    }

    @Getter
    @Setter
    public static class Name {

        private String familyName;

        private String givenName;
    }
}
