package com.siemens.csde.simicas.api.pojo.qo.alarm;

import com.siemens.csde.simicas.common.base.BaseQo;
import lombok.Getter;
import lombok.Setter;
/**
 *  告警策略请求类
 * @author Z0040M9S
 * @version 1.0-SNAPSHOT
 * @date 2/12/2020 4:28 PM
 **/
@Setter
@Getter
public class NotifyPolicyQo extends BaseQo {


    private static final long serialVersionUID = 7968578410939264752L;

    private String lineId;

    private String kpi;

    private int policyType;

    private int webLimit;

    private int emailLimit;



}
