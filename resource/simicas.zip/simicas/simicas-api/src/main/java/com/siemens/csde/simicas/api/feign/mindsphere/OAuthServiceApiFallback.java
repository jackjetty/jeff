package com.siemens.csde.simicas.api.feign.mindsphere;

import com.google.gson.Gson;
import com.siemens.csde.simicas.api.constant.ServiceNameConstant;
import com.siemens.csde.simicas.common.base.BaseResult;
import com.siemens.csde.simicas.common.constant.enums.ResultEnum;
import com.siemens.csde.simicas.common.model.TokenBean;
import java.net.URI;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@Component
@Slf4j
public class OAuthServiceApiFallback implements OAuthServiceApi {

    @Override
    public TokenBean getToken(URI baseUrl, String token, String grantType) {
        log.error(new Gson().toJson(new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_MINDSPHERE+" "+ ResultEnum.ERROR.getInfo())));
        return null;
    }
}
