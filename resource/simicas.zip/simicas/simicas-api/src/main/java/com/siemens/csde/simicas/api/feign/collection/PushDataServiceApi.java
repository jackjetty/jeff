package com.siemens.csde.simicas.api.feign.collection;

import com.siemens.csde.simicas.api.constant.ServiceNameConstant;
import com.siemens.csde.simicas.api.pojo.qo.collection.PushDataQo;
import com.siemens.csde.simicas.common.base.BaseResult;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
/**
 *  第三方 push api
 * @author Z0040M9S
 * @version 1.0-SNAPSHOT
 * @date 2/12/2020 4:28 PM
 **/
@FeignClient(
        name = ServiceNameConstant.SERVICE_COLLECTION,
        url = "${service.collection}",
        fallback = PushDataServiceApiFallback.class)
@Component
public interface PushDataServiceApi {

    @RequestMapping(value = "/pushData/push", method = RequestMethod.POST)
    BaseResult push(@RequestBody PushDataQo pushDataQo);

}
