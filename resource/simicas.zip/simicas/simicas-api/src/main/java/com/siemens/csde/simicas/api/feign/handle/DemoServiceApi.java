package com.siemens.csde.simicas.api.feign.handle;

import com.siemens.csde.simicas.api.constant.ServiceNameConstant;
import com.siemens.csde.simicas.api.pojo.vo.DemoVo;
import com.siemens.csde.simicas.common.base.BaseResult;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;


@FeignClient(
        name = ServiceNameConstant.SERVICE_HANDLE,
        url = "${service.handle}",
        fallback = DemoServiceApiFallback.class)
@Component
public interface DemoServiceApi {


    @RequestMapping(value = "/demo/test", method = RequestMethod.GET)
    BaseResult<DemoVo> test();


}
