package com.siemens.csde.simicas.api.feign.handle;

import com.google.gson.Gson;
import com.siemens.csde.simicas.api.constant.ServiceNameConstant;
import com.siemens.csde.simicas.common.base.BaseResult;
import com.siemens.csde.simicas.common.constant.enums.ResultEnum;
import java.util.Date;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

/**
 * 历史数据Api 异常处理类
 *
 * @author z0043y5h
 * @version 1.0-SNAPSHOT
 * @date 2020/3/23 10:08
 **/
@Component("handleHistoryServiceApiFallback")
@Slf4j
public class HistoryServiceApiFallback implements HistoryServiceApi {

    @Override
    public BaseResult listData(String lineId, String kpi, Date from, Date to) {
        log.error(new Gson().toJson(new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_HANDLE + " " + ResultEnum.ERROR.getInfo())));
        return new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_HANDLE + " " + ResultEnum.ERROR.getInfo());
    }
}
