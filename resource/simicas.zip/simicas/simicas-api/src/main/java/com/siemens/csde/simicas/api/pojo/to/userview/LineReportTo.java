package com.siemens.csde.simicas.api.pojo.to.userview;

import com.siemens.csde.simicas.common.base.BaseTo;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Getter
@Setter
public class LineReportTo extends BaseTo {

    private static final long serialVersionUID = 5916885739433824564L;

    private String lineName;

    private String startDate;

    private int duration;

}
