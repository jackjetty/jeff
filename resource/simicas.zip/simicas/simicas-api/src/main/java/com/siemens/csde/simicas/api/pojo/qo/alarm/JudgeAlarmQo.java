package com.siemens.csde.simicas.api.pojo.qo.alarm;

import com.siemens.csde.simicas.common.base.BaseQo;
import java.util.Date;
import lombok.Getter;
import lombok.Setter;
/**
 *  判断告警请求类
 * @author Z0040M9S
 * @version 1.0-SNAPSHOT
 * @date 2/12/2020 4:28 PM
 **/
@Setter
@Getter
public class JudgeAlarmQo extends BaseQo {

    private static final long serialVersionUID = -6185893622984073090L;
    private String tenent;
    private String lineId;
    private String lineName;
    private String productId;
    private String productName;
    private String orderId;
    private String data;
    private Date time;

}