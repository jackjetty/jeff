package com.siemens.csde.simicas.api.pojo.to.handle;

import com.google.gson.annotations.SerializedName;
import com.siemens.csde.simicas.common.base.BaseTo;
import com.siemens.csde.simicas.common.constant.enums.EntityEnum;
import com.siemens.csde.simicas.common.constant.enums.KpiModeEnum;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * BaseKpiTo
 *
 * @author z004267r
 * @version 1.0-SNAPSHOT
 * @date 3/18/2020 1:16 PM
 **/
@Setter
@Getter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class BaseKpiTo<T> extends BaseTo {

    private static final long serialVersionUID = 7394114973322945620L;

    @SerializedName("_time")
    private String time;

    private String tenant;

    private KpiModeEnum kpiMode;

    private EntityEnum entityEnum;

    private String kpi;

    private String lineId;

    private String stationId;

    private String lineName;

    private String unit;

    @SerializedName(value = "ProductID")
    private String productId;

    @SerializedName(value = "ProductName")
    private String productName;

    @SerializedName(value = "OrderID")
    private String orderId;

    @SerializedName(value = "BatchID")
    private String batchId;

    private T data;

}
