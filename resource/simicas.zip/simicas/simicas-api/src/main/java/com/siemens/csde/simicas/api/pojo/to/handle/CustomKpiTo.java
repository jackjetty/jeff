package com.siemens.csde.simicas.api.pojo.to.handle;

import com.google.gson.annotations.SerializedName;
import com.siemens.csde.simicas.common.base.BaseTo;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

/**
 * CostomKpiTo
 *
 * @author z004267r
 * @version 1.0-SNAPSHOT
 * @date 3/26/2020 3:06 PM
 **/
@Setter
@Getter
@Builder
public class CustomKpiTo extends BaseTo {

    private static final long serialVersionUID = 1763908419838647828L;

    @SerializedName(value = "value")
    private String dataValue;

    private String unit;

}
