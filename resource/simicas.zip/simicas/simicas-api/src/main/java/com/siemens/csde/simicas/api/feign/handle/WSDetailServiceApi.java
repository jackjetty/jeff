package com.siemens.csde.simicas.api.feign.handle;

import com.siemens.csde.simicas.api.constant.ServiceNameConstant;
import com.siemens.csde.simicas.api.pojo.vo.handle.line.WorkSpaceModelVo;
import com.siemens.csde.simicas.api.pojo.vo.handle.station.StationKpiVo;
import com.siemens.csde.simicas.common.base.BaseResult;
import java.util.Date;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;

/**
 * 工站指标展示api
 *
 * @author z0043y5h
 * @version 1.0-SNAPSHOT
 * @date 2020/3/22 23:24
 **/
@FeignClient(
        name = ServiceNameConstant.SERVICE_HANDLE,
        url = "${service.handle}",
        fallback = WSDetailServiceApiFallback.class)
@Component
public interface WSDetailServiceApi {

    /**
     * 获取产线的workstation
     *
     * @param lineId lineId
     * @return com.siemens.csde.simicas.common.base.BaseResult<com.siemens.csde.simicas.api.pojo.vo.handle.line.WorkSpaceModelVo>
     * @author z0043y5h
     * @date 2020/3/22 23:43
     **/
    @GetMapping(value = "/workstationDetail/listWorkstation/line/{lineId}", produces = MediaType.APPLICATION_JSON_VALUE)
    BaseResult<WorkSpaceModelVo> getWorkstationInfo(@PathVariable(value = "lineId") String lineId);

    /**
     * 获取产线的station集合的状态
     *
     * @param lineId lineId
     * @param from   from
     * @param to     to
     * @return com.siemens.csde.simicas.common.base.BaseResult<com.siemens.csde.simicas.api.pojo.vo.handle.station.StationKpiVo>
     * @author z0043y5h
     * @date 2020/3/22 23:42
     **/
    @GetMapping(value = "/workstationDetail/stationKpi/line/{lineId}", produces = MediaType.APPLICATION_JSON_VALUE)
    BaseResult<StationKpiVo> stationKpi(@PathVariable(value = "lineId") String lineId,
            @RequestParam(value = "from") Date from, @RequestParam(value = "to") Date to);
}
