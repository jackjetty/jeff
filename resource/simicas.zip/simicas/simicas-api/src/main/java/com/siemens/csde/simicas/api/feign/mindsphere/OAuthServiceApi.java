package com.siemens.csde.simicas.api.feign.mindsphere;

import com.siemens.csde.simicas.common.model.TokenBean;
import java.net.URI;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

@FeignClient(
        name = "oauth-client",
        url = "${service.core.oauth:https://{tenant}.piam.cn1.mindsphere-in.cn/uaa}",
        fallback = OAuthServiceApiFallback.class)
public interface OAuthServiceApi {

    String PLACEHOLDER_TENANT = "{tenant}";
    String GRANT_TYPE = "client_credentials";

    /**
     * 获取token
     * @author z004267r
     * @param baseUrl  baseUrl
     * @param token  token
     * @param grantType  grantType
     * @return com.siemens.csde.macb.mdsp.api.pojo.vo.TokenBean
     * @date 8/23/2019 5:49 PM
     */
    @RequestMapping(value = "/oauth/token", method = RequestMethod.GET)
    TokenBean getToken(
            URI baseUrl,
            @RequestHeader("Authorization") String token,
            @RequestParam("grant_type") String grantType);


}
