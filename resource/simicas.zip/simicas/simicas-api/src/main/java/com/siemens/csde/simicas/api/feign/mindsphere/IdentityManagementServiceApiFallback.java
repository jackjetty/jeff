package com.siemens.csde.simicas.api.feign.mindsphere;

import com.alibaba.fastjson.JSONObject;
import com.google.gson.Gson;
import com.siemens.csde.simicas.api.constant.ServiceNameConstant;
import com.siemens.csde.simicas.common.base.BaseResult;
import com.siemens.csde.simicas.common.constant.enums.ResultEnum;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@Component
@Slf4j
public class IdentityManagementServiceApiFallback implements IdentityManagementServiceApi {

    @Override
    public JSONObject getUsers(String token) {
        log.error(new Gson().toJson(new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_MINDSPHERE+" "+ ResultEnum.ERROR.getInfo())));
        return null;
    }

    @Override
    public JSONObject getUsers(String token, String attributes, String filter) {
        log.error(new Gson().toJson(new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_MINDSPHERE+" "+ ResultEnum.ERROR.getInfo())));
        return null;
    }
}
