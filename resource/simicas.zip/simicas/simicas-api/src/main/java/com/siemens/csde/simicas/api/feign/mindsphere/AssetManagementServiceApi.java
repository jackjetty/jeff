package com.siemens.csde.simicas.api.feign.mindsphere;


import com.siemens.csde.simicas.api.pojo.dto.AspectDto;
import com.siemens.csde.simicas.common.model.AspectSchemaBean;
import com.siemens.csde.simicas.common.model.AssetBean;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

@FeignClient(
        name = "asset-client",
        url = "${service.advance.asset-management:https://gateway.cn1.mindsphere-in.cn/api/assetmanagement/v3}",
        fallback = AssetManagementServiceApiFallback.class)
public interface AssetManagementServiceApi {

    /**
     * 获取asset
     *
     * @param id id
     * @param token token
     * @return com.siemens.csde.macb.common.model.bean.asset.AssetBean
     * @author z004267r
     * @date 8/23/2019 5:48 PM
     */
    @RequestMapping(value = "/assets/{id}", method = RequestMethod.GET)
    AssetBean getAsset(
            @PathVariable("id") String id,
            @RequestHeader("Authorization") String token);

    /**
     * 获取asset对应的aspect
     *
     * @param id id
     * @param token token
     * @param size size
     * @return com.siemens.csde.macb.mdsp.api.pojo.vo.ResourceDto<com.siemens.csde.macb.common.model.bean.asset.AspectSchemaBean>
     * @author z004267r
     * @date 8/23/2019 5:48 PM
     */
    @RequestMapping(
            value = "/assets/{id}/aspects", method = RequestMethod.GET)
    AspectDto<AspectSchemaBean> getAspect(
            @PathVariable("id") String id,
            @RequestHeader("Authorization") String token,
            @RequestParam(value = "size", defaultValue = "100") Integer size);

}
