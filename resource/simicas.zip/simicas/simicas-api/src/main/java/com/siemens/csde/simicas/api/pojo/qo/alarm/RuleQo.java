package com.siemens.csde.simicas.api.pojo.qo.alarm;

import com.siemens.csde.simicas.common.base.BaseQo;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
/**
 *  报警规则请求类
 * @author Z0040M9S
 * @version 1.0-SNAPSHOT
 * @date 2/12/2020 4:28 PM
 **/
@Setter
@Getter
public class RuleQo extends BaseQo {


    private static final long serialVersionUID = 5915920471236797821L;
    private String lineId;
    private String kpi;
    private String alarmLevel;
    private String expression;
    private boolean highlight;
    private boolean notifyEmail;
    private boolean notifySMS;
    private boolean notifyWeb;
    private List<String> emailAddresses;


}
