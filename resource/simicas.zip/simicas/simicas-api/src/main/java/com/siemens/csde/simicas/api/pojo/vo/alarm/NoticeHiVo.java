package com.siemens.csde.simicas.api.pojo.vo.alarm;

import com.siemens.csde.simicas.common.base.BaseVo;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

/**
 * 通知历史数据Vo
 *
 * @author z0043y5h
 * @version 1.0-SNAPSHOT
 * @date 2020/3/23 13:10
 **/
@Slf4j
@Getter
@Setter
public class NoticeHiVo extends BaseVo {

    private static final long serialVersionUID = -4439594999385709960L;

    private String lineId;

    private String lineName;

    private List<AlarmHiVo> data;
}
