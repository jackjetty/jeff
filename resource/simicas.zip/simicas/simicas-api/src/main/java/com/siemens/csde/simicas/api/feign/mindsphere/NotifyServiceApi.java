package com.siemens.csde.simicas.api.feign.mindsphere;

import com.siemens.csde.simicas.common.model.NotifyBean;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@FeignClient(
        name = "notify-client",
        url = "${service.api.notification:https://gateway.cn1.mindsphere-in.cn/api/notification/v3}",
        fallback = NotifyServiceApiFallback.class)
public interface NotifyServiceApi {

    /**
     * 发送邮件
     * @author z004267r
     * @param token  token
     * @param notifyBean  notifyBean
     * @return void
     * @date 8/23/2019 5:49 PM
     */
    @RequestMapping(value = "/publisher/messages", method = RequestMethod.POST)
    void publishMessages(
            @RequestHeader("Authorization") String token,
            @RequestBody NotifyBean notifyBean);

}
