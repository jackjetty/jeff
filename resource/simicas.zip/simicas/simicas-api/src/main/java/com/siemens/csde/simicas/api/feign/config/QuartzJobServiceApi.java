package com.siemens.csde.simicas.api.feign.config;

import com.siemens.csde.simicas.api.constant.ServiceNameConstant;
import com.siemens.csde.simicas.api.pojo.qo.JobQo;
import com.siemens.csde.simicas.common.base.BaseResult;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@FeignClient(
        name = ServiceNameConstant.SERVICE_CONFIG,
        url = "${service.config}",
        fallback = QuartzJobServiceApiFallback.class)
@Component
public interface QuartzJobServiceApi {

    @RequestMapping(value = "/job/addJob", method = RequestMethod.POST)
    BaseResult addJob(@RequestBody JobQo jobQo);

    @RequestMapping(value = "/job/updateJob", method = RequestMethod.PUT)
    BaseResult updateJob(@RequestBody JobQo jobQo);

    @RequestMapping(value = "/job/deleteJob", method = RequestMethod.DELETE)
    BaseResult deleteJob(@RequestBody JobQo jobQo);

}
