package com.siemens.csde.simicas.api.pojo.to.handle;

import com.google.gson.annotations.SerializedName;
import com.siemens.csde.simicas.common.base.BaseTo;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

/**
 * NGReasonTo
 *
 * @author z004267r
 * @version 1.0-SNAPSHOT
 * @date 3/24/2020 3:21 PM
 **/
@Setter
@Getter
@Builder
public class NGReasonTo extends BaseTo {

    private static final long serialVersionUID = -6920127565790067807L;

    @SerializedName(value = "ChangeOver")
    private Boolean changeOver;

    @SerializedName(value = "NGReason")
    private String dataValue;

}
