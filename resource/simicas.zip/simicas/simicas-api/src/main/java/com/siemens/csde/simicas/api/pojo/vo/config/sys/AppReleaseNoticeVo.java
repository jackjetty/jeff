package com.siemens.csde.simicas.api.pojo.vo.config.sys;

import com.siemens.csde.simicas.common.base.BaseVo;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

/**
 * 应用发布通知Vo
 *
 * @author z0043y5h
 * @version 1.0-SNAPSHOT
 * @date 2020/3/20 17:40
 **/
@Slf4j
@Getter
@Setter
@Builder
public class AppReleaseNoticeVo extends BaseVo {

    private static final long serialVersionUID = 5776434213465089236L;

    private String title;

    private String detail;
}
