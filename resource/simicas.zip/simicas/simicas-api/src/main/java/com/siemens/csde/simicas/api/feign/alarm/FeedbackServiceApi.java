package com.siemens.csde.simicas.api.feign.alarm;

import com.siemens.csde.simicas.api.constant.ServiceNameConstant;
import com.siemens.csde.simicas.api.pojo.qo.alarm.AddFeedbackQo;
import com.siemens.csde.simicas.api.pojo.vo.alarm.FeedbackVo;
import com.siemens.csde.simicas.common.base.BasePageVo;
import com.siemens.csde.simicas.common.base.BaseResult;
import java.util.Date;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

/**
 * 反馈Api
 *
 * @author z0043y5h
 * @version 1.0-SNAPSHOT
 * @date 2020/3/23 14:03
 **/
@FeignClient(
        name = ServiceNameConstant.SERVICE_ALARM,
        url = "${service.alarm}",
        fallback = FeedbackServiceApiFallback.class)
@Component
public interface FeedbackServiceApi {
    /**
     * 新增feedback
     *
     * @param addFeedbackQo addFeedbackQo新增对象
     * @return com.siemens.csde.simicas.common.base.BaseResult<java.lang.String>
     * @author z0043y5h
     * @date 2020/3/23 14:09
     **/
    @PostMapping(value = "/feedback/addFeedback", produces = MediaType.APPLICATION_JSON_VALUE)
    BaseResult<String> addFeedback(@RequestBody AddFeedbackQo addFeedbackQo);
    /**
     * 分页获取feedback list
     *
     * @param from     from
     * @param to       to
     * @param index    index
     * @param size     size
     * @return com.siemens.csde.simicas.common.base.BaseResult<com.siemens.csde.simicas.common.base.BasePageVo <
            * com.siemens.csde.simicas.api.pojo.vo.alarm.FeedbackVo>>
     * @author z0043y5h
     * @date 2020/3/23 14:09
     **/
    @GetMapping(value = "/feedback/listFeedback", produces = MediaType.APPLICATION_JSON_VALUE)
    BaseResult<BasePageVo<FeedbackVo>> listFeedback(@RequestParam(value = "from", required = false) Date from,
            @RequestParam(value = "to", required = false) Date to,
            @RequestParam(value = "index", required = false) Integer index,
            @RequestParam(value = "size", required = false) Integer size);
}
