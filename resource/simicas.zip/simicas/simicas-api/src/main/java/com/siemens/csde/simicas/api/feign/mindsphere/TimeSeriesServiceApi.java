package com.siemens.csde.simicas.api.feign.mindsphere;

import com.siemens.csde.simicas.common.model.IotTimeSeriesBean;
import java.util.List;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

@FeignClient(
        name = "iot-client",
        //url = "${service.iot.timeseries:https://gateway.cn1.mindsphere-in.cn/api/iottimeseries/v3}")
        url = "${service.iot.timeseries:https://gateway.cn1.mindsphere-in.cn/api/iottimeseries/v3}",
        fallback = TimeSeriesServiceApiFallback.class)
public interface TimeSeriesServiceApi {

    int MAX_TIMESERIES_ITEMS_SIZE = 1000;

    /**
     * 获取TimeSeries数据
     *
     * @param entity entity
     * @param propertySetName propertySetName
     * @param from from
     * @param to to
     * @param limit limit
     * @param select select
     * @param token token
     * @return java.util.List<com.siemens.csde.macb.common.model.stream.IotTimeSeriesItem>
     * @author z004267r
     * @date 8/23/2019 5:49 PM
     */
    @RequestMapping(value = "/timeseries/{entity}/{propertysetname}",method = RequestMethod.GET)
    List<IotTimeSeriesBean> getIotTimeSeries(
            @PathVariable("entity") String entity,
            @PathVariable("propertysetname") String propertySetName,
            @RequestParam("from") String from,
            @RequestParam("to") String to,
            @RequestParam(value = "limit", defaultValue = "1000") Integer limit,
            @RequestParam("select") String select,
            @RequestHeader("Authorization") String token);


    /**
     * push TimeSeries 数据
     *
     * @param entity entity
     * @param propertySetName propertySetName
     * @param timeSeriesItems timeSeriesItems
     * @param token token
     * @return void
     * @author z004267r
     * @date 8/23/2019 5:50 PM
     */
    @RequestMapping(value = "/timeseries/{entity}/{propertysetname}",method = RequestMethod.PUT)
    void putTimeSeries(
            @PathVariable("entity") String entity,
            @PathVariable("propertysetname") String propertySetName,
            @RequestBody List<IotTimeSeriesBean> timeSeriesItems,
            @RequestHeader("Authorization") String token);


}

