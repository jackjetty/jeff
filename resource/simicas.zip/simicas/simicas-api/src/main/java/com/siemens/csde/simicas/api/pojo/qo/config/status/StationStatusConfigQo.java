package com.siemens.csde.simicas.api.pojo.qo.config.status;

import com.siemens.csde.simicas.common.base.BaseQo;
import lombok.Getter;
import lombok.Setter;

/**
 * StationStatusConfigQo
 *
 * @author z0043y5h
 * @version 1.0-SNAPSHOT
 * @date 2020/2/22 15:19
 **/
@Getter
@Setter
public class StationStatusConfigQo extends BaseQo {

    private static final long serialVersionUID = 6447662799504153487L;
    private String workstationId;
    private String label;
    private String value;
    private String name;
    private String visual;
    private Boolean downtimeCategory;
}