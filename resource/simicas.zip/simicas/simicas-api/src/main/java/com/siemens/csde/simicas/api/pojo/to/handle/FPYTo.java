package com.siemens.csde.simicas.api.pojo.to.handle;

import com.google.gson.annotations.SerializedName;
import com.siemens.csde.simicas.common.base.BaseTo;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

/**
 * FPYTo
 *
 * @author z004267r
 * @version 1.0-SNAPSHOT
 * @date 3/24/2020 3:14 PM
 **/
@Setter
@Getter
@Builder
public class FPYTo extends BaseTo {

    private static final long serialVersionUID = 1824903237258043055L;

    @SerializedName(value = "FPY")
    private Double dataValue;

    @SerializedName(value = "Defect")
    private Integer defect;

    @SerializedName(value = "Total")
    private Integer total;

    @SerializedName(value = "ChangeOver")
    private Boolean changeOver;

}
