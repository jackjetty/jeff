package com.siemens.csde.simicas.api.feign.handle;

import com.google.gson.Gson;
import com.siemens.csde.simicas.api.constant.ServiceNameConstant;
import com.siemens.csde.simicas.api.pojo.vo.handle.line.WorkSpaceModelVo;
import com.siemens.csde.simicas.api.pojo.vo.handle.station.StationKpiVo;
import com.siemens.csde.simicas.common.base.BaseResult;
import com.siemens.csde.simicas.common.constant.enums.ResultEnum;
import java.util.Date;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

/**
 * 工站指标展示api 异常处理类
 *
 * @author z0043y5h
 * @version 1.0-SNAPSHOT
 * @date 2020/3/22 23:24
 **/
@Component
@Slf4j
public class WSDetailServiceApiFallback implements WSDetailServiceApi {

    @Override
    public BaseResult<WorkSpaceModelVo> getWorkstationInfo(String lineId) {
        log.error(new Gson().toJson(new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_HANDLE + " " + ResultEnum.ERROR.getInfo())));
        return new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_HANDLE + " " + ResultEnum.ERROR.getInfo());
    }

    @Override
    public BaseResult<StationKpiVo> stationKpi(String lineId, Date from, Date to) {
        log.error(new Gson().toJson(new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_HANDLE + " " + ResultEnum.ERROR.getInfo())));
        return new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_HANDLE + " " + ResultEnum.ERROR.getInfo());
    }
}
