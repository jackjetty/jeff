package com.siemens.csde.simicas.api.pojo.to.alarm;
import com.siemens.csde.simicas.common.base.BaseDto;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
/**
 *  报警规则列表传输类
 * @author Z0040M9S
 * @version 1.0-SNAPSHOT
 * @date 2/12/2020 4:28 PM
 **/
@Slf4j
@Getter
@Setter
public class AlarmCfgRuleTo extends BaseDto {

    private static final long serialVersionUID = 839366186324573605L;

    private String id;

    private String alarmLevel;

    private String expression;

    private Boolean highlight;

    private Boolean notifyEmail;

    private Boolean notifyWeb;

    private Boolean notifySms;

    private String kpi;

    private String tenant;

    private String lineId;

    private List<String> emailAddresses;

}