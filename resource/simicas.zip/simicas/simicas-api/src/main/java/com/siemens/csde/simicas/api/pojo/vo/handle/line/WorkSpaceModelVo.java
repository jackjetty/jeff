package com.siemens.csde.simicas.api.pojo.vo.handle.line;

import com.google.gson.annotations.SerializedName;
import com.siemens.csde.simicas.common.base.BaseVo;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

/**
 * 作业模型Vo
 *
 * @author z0043y5h
 * @version 1.0-SNAPSHOT
 * @date 2020/3/25 13:52
 **/
@Setter
@Getter
@Slf4j
public class WorkSpaceModelVo extends BaseVo {

    private static final long serialVersionUID = -7178507827288554231L;

    @SerializedName("class")
    private String clazz;

    private List<NodeData> nodeDataArray;

    private List<LinkData> linkDataArray;

    @Getter
    @Setter
    public static class NodeData {

        private String text;

        private String disText;

        private String id;

        private Boolean isGroup;

        private String category;

        private List<String> containing;

        private String key;

        private String color;

        private Boolean config;

        private Boolean unConfig;

        private String group;

        private String loc;
    }

    @Getter
    @Setter
    public static class LinkData {

        private String from;

        private String to;
    }
}
