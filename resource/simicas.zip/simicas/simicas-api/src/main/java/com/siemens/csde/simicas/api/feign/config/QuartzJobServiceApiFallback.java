package com.siemens.csde.simicas.api.feign.config;

import com.google.gson.Gson;
import com.siemens.csde.simicas.api.constant.ServiceNameConstant;
import com.siemens.csde.simicas.api.pojo.qo.JobQo;
import com.siemens.csde.simicas.common.base.BaseResult;
import com.siemens.csde.simicas.common.constant.enums.ResultEnum;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@Component
@Slf4j
public class QuartzJobServiceApiFallback implements QuartzJobServiceApi {


    @Override
    public BaseResult addJob(JobQo jobQo) {
        log.error(new Gson().toJson(new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_CONFIG+" "+ ResultEnum.ERROR.getInfo())));
        return new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_CONFIG+" "+ ResultEnum.ERROR.getInfo());
    }

    @Override
    public BaseResult updateJob(JobQo jobQo) {
        log.error(new Gson().toJson(new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_CONFIG+" "+ ResultEnum.ERROR.getInfo())));
        return new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_CONFIG+" "+ ResultEnum.ERROR.getInfo());
    }

    @Override
    public BaseResult deleteJob(JobQo jobQo) {
        log.error(new Gson().toJson(new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_CONFIG+" "+ ResultEnum.ERROR.getInfo())));
        return new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_CONFIG+" "+ ResultEnum.ERROR.getInfo());
    }
}
