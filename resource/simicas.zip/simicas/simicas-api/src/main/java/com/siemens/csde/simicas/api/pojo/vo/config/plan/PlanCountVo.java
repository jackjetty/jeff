package com.siemens.csde.simicas.api.pojo.vo.config.plan;

import com.siemens.csde.simicas.common.base.BaseVo;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

/**
 * 计划数量统计Vo
 *
 * @author z0043y5h
 * @version 1.0-SNAPSHOT
 * @date 2020/3/27 13:31
 **/
@Slf4j
@Getter
@Setter
public class PlanCountVo extends BaseVo {

    private static final long serialVersionUID = -689487336082021445L;

    private Integer total;
}
