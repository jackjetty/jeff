package com.siemens.csde.simicas.api.feign.analyzes;

import com.siemens.csde.simicas.api.constant.ServiceNameConstant;
import com.siemens.csde.simicas.api.pojo.vo.analyzes.CollectProductByLineVo;
import com.siemens.csde.simicas.api.pojo.vo.analyzes.CollectProductByStationVo;
import com.siemens.csde.simicas.common.base.BaseResult;
import java.util.Date;
import java.util.List;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

/**
 * 质量统计api
 *
 * @author z0043y5h
 * @version 1.0-SNAPSHOT
 * @date 2020/3/23 16:10
 **/
@FeignClient(
        name = ServiceNameConstant.SERVICE_ANALYZES,
        url = "${service.analyzes}",
        fallback = QualityServiceApiFallback.class)
@Component
public interface QualityServiceApi {

    /**
     * fpy 产线统计
     * @author Z0040M9S
     * @return : com.siemens.csde.simicas.common.base.BaseResult<com.siemens.csde.simicas.api.pojo.vo.analyzes.CollectProductByLineVo>
     * @date   4/15/2020 9:50 AM
     */
    @RequestMapping(value = "/quality/fpy/info", method = RequestMethod.GET)
    BaseResult<CollectProductByLineVo> statisticLineFPY(@RequestParam(value = "lineIds", required = false) List<String> lineIds,
            @RequestParam(value = "productIds", required = false) List<String> productIds,
            @RequestParam(value = "from", required = false) Date from,
            @RequestParam(value = "to", required = false) Date to,
            @RequestParam(value = "dataUnit", required = false) String dataUnit,
            @RequestParam(value = "particleSize", required = false) Integer particleSize,
            @RequestParam(value = "timeZone", required = false) Integer timeZone);

    /**
     * fpy 工站统计
     * @author Z0040M9S
     * @param lineId :
     * @return : com.siemens.csde.simicas.common.base.BaseResult<com.siemens.csde.simicas.api.pojo.vo.analyzes.CollectProductByStationVo>
     * @date   4/15/2020 9:50 AM
     */
    @RequestMapping(value = "/quality/fpy/info/line/{lineId}", method = RequestMethod.GET)
    BaseResult<CollectProductByStationVo> statisticStationFPY(@PathVariable("lineId") String lineId, @RequestParam(value = "stationIds", required = false) List<String> stationIds,
            @RequestParam(value = "productIds", required = false) List<String> productIds,
            @RequestParam(value = "from", required = false) Date from,
            @RequestParam(value = "to", required = false) Date to,
            @RequestParam(value = "dataUnit", required = false) String dataUnit,
            @RequestParam(value = "ngReason", required = false) String ngReason,
            @RequestParam(value = "particleSize", required = false) Integer particleSize,
            @RequestParam(value = "timeZone", required = false) Integer timeZone);

    /**
     * failed defect 产线统计
     * @author Z0040M9S
     * @return : com.siemens.csde.simicas.common.base.BaseResult<com.siemens.csde.simicas.api.pojo.vo.analyzes.CollectProductByLineVo>
     * @date   4/15/2020 9:51 AM
     */
    @RequestMapping(value = "/quality/failed/info", method = RequestMethod.GET)
    BaseResult<CollectProductByLineVo> statisticLineDefect(@RequestParam(value = "lineIds", required = false) List<String> lineIds,
            @RequestParam(value = "productIds", required = false) List<String> productIds,
            @RequestParam(value = "from", required = false) Date from,
            @RequestParam(value = "to", required = false) Date to,
            @RequestParam(value = "dataUnit", required = false) String dataUnit,
            @RequestParam(value = "particleSize", required = false) Integer particleSize,
            @RequestParam(value = "timeZone", required = false) Integer timeZone);
    /**
     * failed defect 工站统计
     * @author Z0040M9S
     * @param lineId :
     * @return : com.siemens.csde.simicas.common.base.BaseResult<com.siemens.csde.simicas.api.pojo.vo.analyzes.CollectProductByStationVo>
     * @date   4/15/2020 9:51 AM
     */
    @RequestMapping(value = "/quality/failed/info/line/{lineId}", method = RequestMethod.GET)
    BaseResult<CollectProductByStationVo> statisticStationDefect(@PathVariable("lineId") String lineId, @RequestParam(value = "stationIds", required = false) List<String> stationIds,
            @RequestParam(value = "productIds", required = false) List<String> productIds,
            @RequestParam(value = "from", required = false) Date from,
            @RequestParam(value = "to", required = false) Date to,
            @RequestParam(value = "dataUnit", required = false) String dataUnit,
            @RequestParam(value = "ngReason", required = false) String ngReason,
            @RequestParam(value = "particleSize", required = false) Integer particleSize,
            @RequestParam(value = "timeZone", required = false) Integer timeZone) ;

    /**
     * ng reason 产线统计
     * @author Z0040M9S
     * @return : com.siemens.csde.simicas.common.base.BaseResult<com.siemens.csde.simicas.api.pojo.vo.analyzes.CollectProductByLineVo>
     * @date   4/15/2020 9:54 AM
     */
    @RequestMapping(value = "/quality/ngreason/info", method = RequestMethod.GET)
    BaseResult<CollectProductByLineVo> statisticLineNGReason(@RequestParam(value = "lineIds", required = false) List<String> lineIds,
            @RequestParam(value = "productIds", required = false) List<String> productIds,
            @RequestParam(value = "from", required = false) Date from,
            @RequestParam(value = "to", required = false) Date to,
            @RequestParam(value = "dataUnit", required = false) String dataUnit,
            @RequestParam(value = "ngReason", required = false) String ngReason,
            @RequestParam(value = "particleSize", required = false) Integer particleSize,
            @RequestParam(value = "timeZone", required = false) Integer timeZone);

    /**
     * ng reason 工站统计
     * @author Z0040M9S
     * @param lineId :
     * @return : com.siemens.csde.simicas.common.base.BaseResult<com.siemens.csde.simicas.api.pojo.vo.analyzes.CollectProductByStationVo>
     * @date   4/15/2020 9:55 AM
     */
    @RequestMapping(value = "/quality/ngreason/info/line/{lineId}", method = RequestMethod.GET)
    BaseResult<CollectProductByStationVo> statisticStationNGReason(@PathVariable("lineId") String lineId, @RequestParam(value = "stationIds", required = false) List<String> stationIds,
            @RequestParam(value = "productIds", required = false) List<String> productIds,
            @RequestParam(value = "from", required = false) Date from,
            @RequestParam(value = "to", required = false) Date to,
            @RequestParam(value = "dataUnit", required = false) String dataUnit,
            @RequestParam(value = "ngReason", required = false) String ngReason,
            @RequestParam(value = "particleSize", required = false) Integer particleSize,
            @RequestParam(value = "timeZone", required = false) Integer timeZone);

}
