package com.siemens.csde.simicas.api.feign.analyzes;

import com.siemens.csde.simicas.api.constant.ServiceNameConstant;
import com.siemens.csde.simicas.api.pojo.vo.analyzes.CollectLineByLineVo;
import com.siemens.csde.simicas.api.pojo.vo.analyzes.CollectProductByLineVo;
import com.siemens.csde.simicas.api.pojo.vo.analyzes.CollectStationByStationVo;
import com.siemens.csde.simicas.common.base.BaseResult;
import java.util.Date;
import java.util.List;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

/**
 * 绩效统计api
 *
 * @author z0043y5h
 * @version 1.0-SNAPSHOT
 * @date 2020/3/23 14:23
 **/
@FeignClient(
        name = ServiceNameConstant.SERVICE_ANALYZES,
        url = "${service.analyzes}",
        fallback = PerformanceServiceApiFallback.class)
@Component
public interface PerformanceServiceApi {

    /**
     * eff  line 统计
     * @author Z0040M9S
     * @return : com.siemens.csde.simicas.common.base.BaseResult<com.siemens.csde.simicas.api.pojo.vo.analyzes.CollectLineByLineVo>
     * @date   4/15/2020 9:49 AM
     */
    @RequestMapping(value = "/performance/eff/info", method = RequestMethod.GET )
    BaseResult<CollectLineByLineVo> statisticLineEFF(@RequestParam(value = "lineIds", required = false) List<String> lineIds,
            @RequestParam(value = "productIds", required = false) List<String> productIds,
            @RequestParam(value = "from", required = false) Date from,
            @RequestParam(value = "to", required = false) Date to,
            @RequestParam(value = "dataUnit", required = false) String dataUnit,
            @RequestParam(value = "particleSize", required = false) Integer particleSize,
            @RequestParam(value = "timeZone", required = false) Integer timeZone);

    /**
     * eff station 统计
     * @author Z0040M9S
     * @param lineId :
     * @return : com.siemens.csde.simicas.common.base.BaseResult<com.siemens.csde.simicas.api.pojo.vo.analyzes.CollectStationByStationVo>
     * @date   4/15/2020 9:49 AM
     */
    @RequestMapping(value = "/performance/eff/info/line/{lineId}", method = RequestMethod.GET )
    BaseResult<CollectStationByStationVo> statisticStationEFF(@PathVariable("lineId") String lineId,  @RequestParam(value = "stationIds", required = false) List<String> stationIds,
            @RequestParam(value = "productIds", required = false) List<String> productIds,
            @RequestParam(value = "from", required = false) Date from,
            @RequestParam(value = "to", required = false) Date to,
            @RequestParam(value = "dataUnit", required = false) String dataUnit,
            @RequestParam(value = "particleSize", required = false) Integer particleSize,
            @RequestParam(value = "timeZone", required = false) Integer timeZone);

    /**
     * lth 产线统计
     * @author Z0040M9S
     * @return : com.siemens.csde.simicas.common.base.BaseResult<com.siemens.csde.simicas.api.pojo.vo.analyzes.CollectLineByLineVo>
     * @date   4/15/2020 9:49 AM
     */
    @RequestMapping(value = "/performance/lth/info", method = RequestMethod.GET )
    BaseResult<CollectLineByLineVo> statisticLineLTH(@RequestParam(value = "lineIds", required = false) List<String> lineIds,
            @RequestParam(value = "productIds", required = false) List<String> productIds,
            @RequestParam(value = "from", required = false) Date from,
            @RequestParam(value = "to", required = false) Date to,
            @RequestParam(value = "dataUnit", required = false) String dataUnit,
            @RequestParam(value = "particleSize", required = false) Integer particleSize,
            @RequestParam(value = "timeZone", required = false) Integer timeZone);

    /**
     * lth 工站统计
     * @author Z0040M9S
     * @param lineId :
     * @return : com.siemens.csde.simicas.common.base.BaseResult<com.siemens.csde.simicas.api.pojo.vo.analyzes.CollectStationByStationVo>
     * @date   4/15/2020 9:49 AM
     */
    @RequestMapping(value = "/performance/lth/info/line/{lineId}", method = RequestMethod.GET )
    BaseResult<CollectStationByStationVo> statisticStationLTH(@PathVariable("lineId") String lineId,  @RequestParam(value = "stationIds", required = false) List<String> stationIds,
            @RequestParam(value = "productIds", required = false) List<String> productIds,
            @RequestParam(value = "from", required = false) Date from,
            @RequestParam(value = "to", required = false) Date to,
            @RequestParam(value = "dataUnit", required = false) String dataUnit,
            @RequestParam(value = "particleSize", required = false) Integer particleSize,
            @RequestParam(value = "timeZone", required = false) Integer timeZone);

    /**
     * output 统计
     * @author Z0040M9S
     * @return : com.siemens.csde.simicas.common.base.BaseResult<com.siemens.csde.simicas.api.pojo.vo.analyzes.CollectProductByLineVo>
     * @date   4/15/2020 9:50 AM
     */
    @RequestMapping(value = "/performance/output/info", method = RequestMethod.GET )
    BaseResult<CollectProductByLineVo> statisticOutput(
            @RequestParam(value = "lineIds", required = false) List<String> lineIds,
            @RequestParam(value = "productIds", required = false) List<String> productIds,
            @RequestParam(value = "from", required = false) Date from,
            @RequestParam(value = "to", required = false) Date to,
            @RequestParam(value = "dataUnit", required = false) String dataUnit,
            @RequestParam(value = "particleSize", required = false) Integer particleSize,
            @RequestParam(value = "timeZone", required = false) Integer timeZone);
}
