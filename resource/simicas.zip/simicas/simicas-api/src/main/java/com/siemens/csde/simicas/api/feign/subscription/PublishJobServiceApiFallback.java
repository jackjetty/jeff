package com.siemens.csde.simicas.api.feign.subscription;


import com.google.gson.Gson;
import com.siemens.csde.simicas.api.constant.ServiceNameConstant;
import com.siemens.csde.simicas.common.base.BaseResult;
import com.siemens.csde.simicas.common.constant.enums.ResultEnum;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

/**
 * PublishJobServiceApiFallback 推送任务api的fallback
 *
 * @author z0043y5h
 * @version 1.0-SNAPSHOT
 * @date 2020/2/19 13:17
 **/
@Component
@Slf4j
public class PublishJobServiceApiFallback implements PublishJobServiceApi {

    @Override
    public BaseResult<String> publish(String subtype) {
        log.error(new Gson().toJson(new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_SUBSCRIPTION + " " + ResultEnum.ERROR.getInfo())));
        return new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_SUBSCRIPTION + " " + ResultEnum.ERROR.getInfo());
    }
}

