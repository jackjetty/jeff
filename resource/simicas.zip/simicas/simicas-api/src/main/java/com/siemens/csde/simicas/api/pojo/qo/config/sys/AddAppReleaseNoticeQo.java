package com.siemens.csde.simicas.api.pojo.qo.config.sys;

import com.siemens.csde.simicas.common.base.BaseQo;
import com.siemens.csde.simicas.common.valid.AddValidGroup;
import java.util.Date;
import javax.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;

/**
 * 新增应用发布通知Qo
 *
 * @author z0043y5h
 * @version 1.0-SNAPSHOT
 * @date 2020/3/20 17:43
 **/
@Getter
@Setter
public class AddAppReleaseNoticeQo extends BaseQo {

    private static final long serialVersionUID = -6521172715889621845L;

    @NotNull(message = "新增title 不能为空", groups = {AddValidGroup.class})
    private String title;

    @NotNull(message = "新增detail 不能为空", groups = {AddValidGroup.class})
    private String detail;

    private Date noticeStartTime;

    private Date noticeEndTime;
}
