package com.siemens.csde.simicas.api.feign.collection;

import com.siemens.csde.simicas.api.constant.ServiceNameConstant;
import com.siemens.csde.simicas.common.base.BaseResult;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

@FeignClient(
        name = ServiceNameConstant.SERVICE_COLLECTION,
        url = "${service.collection}",
        fallback = CollectDataServiceApiFallback.class)
@Component
public interface CollectDataServiceApi {

    @RequestMapping(value = "/collectData/collect", method = RequestMethod.GET)
    BaseResult collectData(@RequestParam("factoryType") String factoryType);

}
