package com.siemens.csde.simicas.api.feign.analyzes;

import com.google.gson.Gson;
import com.siemens.csde.simicas.api.constant.ServiceNameConstant;
import com.siemens.csde.simicas.api.pojo.vo.analyzes.CollectLineByLineVo;
import com.siemens.csde.simicas.common.base.BaseResult;
import com.siemens.csde.simicas.common.constant.enums.ResultEnum;
import java.util.Date;
import java.util.List;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

/**
 * 维护统计Api 异常处理类
 *
 * @author z0043y5h
 * @version 1.0-SNAPSHOT
 * @date 2020/3/23 16:48
 **/
@Component
@Slf4j
public class MaintenanceServiceApiFallback implements MaintenanceServiceApi {

    @Override
    public BaseResult<CollectLineByLineVo> statisticStopCountTop(List<String> lineIds, List<String> productIds, Date from, Date to, String dataUnit,
            String stopCode, Integer particleSize, Integer timeZone) {
        log.error(new Gson().toJson(new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_ANALYZES + " " + ResultEnum.ERROR.getInfo())));
        return new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_ANALYZES + " " + ResultEnum.ERROR.getInfo());
    }

    @Override
    public BaseResult<CollectLineByLineVo> statisticStopMinTop(List<String> lineIds, List<String> productIds, Date from, Date to, String dataUnit,
            String stopCode, Integer particleSize, Integer timeZone) {
        log.error(new Gson().toJson(new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_ANALYZES + " " + ResultEnum.ERROR.getInfo())));
        return new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_ANALYZES + " " + ResultEnum.ERROR.getInfo());
    }

    @Override
    public BaseResult<CollectLineByLineVo> statisticStopCountInfo(List<String> lineIds, List<String> productIds, Date from, Date to, String dataUnit,
            String stopCode, Integer particleSize, Integer timeZone) {
        log.error(new Gson().toJson(new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_ANALYZES + " " + ResultEnum.ERROR.getInfo())));
        return new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_ANALYZES + " " + ResultEnum.ERROR.getInfo());
    }

    @Override
    public BaseResult<CollectLineByLineVo> statisticStopMinInfo(List<String> lineIds, List<String> productIds, Date from, Date to, String dataUnit,
            String stopCode, Integer particleSize, Integer timeZone) {
        log.error(new Gson().toJson(new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_ANALYZES + " " + ResultEnum.ERROR.getInfo())));
        return new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_ANALYZES + " " + ResultEnum.ERROR.getInfo());
    }

    @Override
    public BaseResult<CollectLineByLineVo> statisticMtbfInfo(List<String> lineIds, List<String> productIds, Date from, Date to, String dataUnit,
            String stopCode, Integer particleSize, Integer timeZone) {
        log.error(new Gson().toJson(new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_ANALYZES + " " + ResultEnum.ERROR.getInfo())));
        return new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_ANALYZES + " " + ResultEnum.ERROR.getInfo());
    }



}
