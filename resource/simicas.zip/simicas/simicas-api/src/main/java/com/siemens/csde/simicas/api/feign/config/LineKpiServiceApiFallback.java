package com.siemens.csde.simicas.api.feign.config;

import com.google.gson.Gson;
import com.siemens.csde.simicas.api.constant.ServiceNameConstant;
import com.siemens.csde.simicas.api.pojo.qo.config.kpi.KpiQo;
import com.siemens.csde.simicas.api.pojo.to.config.kpi.KpiTo;
import com.siemens.csde.simicas.common.base.BaseResult;
import com.siemens.csde.simicas.common.constant.enums.ResultEnum;
import java.util.List;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
/**
 *  产线KPI 配置异常处理类
 * @author Z0040M9S
 * @version 1.0-SNAPSHOT
 * @date 2/12/2020 4:28 PM
 **/
@Component
@Slf4j
public class LineKpiServiceApiFallback implements LineKpiServiceApi{

    @Override
    public BaseResult<String> addKpi(String lineId, KpiQo kpiQo) {
        log.error(new Gson().toJson(new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_CONFIG+" "+ ResultEnum.ERROR.getInfo())));
        return new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_CONFIG+" "+ ResultEnum.ERROR.getInfo());
    }

    @Override
    public BaseResult<String> updateKpi(String lineId, String kpiId, KpiQo kpiQo) {
        log.error(new Gson().toJson(new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_CONFIG+" "+ ResultEnum.ERROR.getInfo())));
        return new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_CONFIG+" "+ ResultEnum.ERROR.getInfo());
    }

    @Override
    public BaseResult<List<KpiTo>> listKpi(String lineId) {
        log.error(new Gson().toJson(new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_CONFIG+" "+ ResultEnum.ERROR.getInfo())));
        return new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_CONFIG+" "+ ResultEnum.ERROR.getInfo());
    }

    @Override
    public BaseResult<String> deleteKpi(String lineId, String kpiId) {
        log.error(new Gson().toJson(new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_CONFIG+" "+ ResultEnum.ERROR.getInfo())));
        return new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_CONFIG+" "+ ResultEnum.ERROR.getInfo());
    }
}