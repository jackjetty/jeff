package com.siemens.csde.simicas.api.feign.config;

import com.google.gson.Gson;
import com.siemens.csde.simicas.api.constant.ServiceNameConstant;
import com.siemens.csde.simicas.api.pojo.qo.config.sys.AddAppReleaseNoticeQo;
import com.siemens.csde.simicas.api.pojo.vo.config.sys.AppReleaseInfoVo;
import com.siemens.csde.simicas.api.pojo.vo.config.sys.AppReleaseNoticeVo;
import com.siemens.csde.simicas.common.base.BaseResult;
import com.siemens.csde.simicas.common.constant.enums.ResultEnum;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

/**
 * 系統信息api 异常处理类
 *
 * @author z0043y5h
 * @version 1.0-SNAPSHOT
 * @date 2020/3/20 17:15
 **/
@Component
@Slf4j
public class SysServiceApiFallBack implements SysServiceApi {

    @Override
    public BaseResult<String> addReleaseNotice(AddAppReleaseNoticeQo addAppReleaseNoticeQo) {
        log.error(new Gson().toJson(new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_CONFIG + " " + ResultEnum.ERROR.getInfo())));
        return new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_CONFIG + " " + ResultEnum.ERROR.getInfo());
    }

    @Override
    public BaseResult<AppReleaseInfoVo> getVersion() {
        log.error(new Gson().toJson(new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_CONFIG + " " + ResultEnum.ERROR.getInfo())));
        return new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_CONFIG + " " + ResultEnum.ERROR.getInfo());
    }

    @Override
    public BaseResult<AppReleaseNoticeVo> listReleaseNotice() {
        log.error(new Gson().toJson(new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_CONFIG + " " + ResultEnum.ERROR.getInfo())));
        return new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_CONFIG + " " + ResultEnum.ERROR.getInfo());
    }
}
