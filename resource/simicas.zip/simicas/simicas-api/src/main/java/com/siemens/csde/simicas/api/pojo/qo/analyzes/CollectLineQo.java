package com.siemens.csde.simicas.api.pojo.qo.analyzes;

import com.siemens.csde.simicas.common.base.BaseQo;
import java.util.Date;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

/**
 * 产线统计数据Qo
 *
 * @author z0043y5h
 * @version 1.0-SNAPSHOT
 * @date 2020/3/23 16:55
 **/
@Slf4j
@Getter
@Setter
public class CollectLineQo extends BaseQo {

    private static final long serialVersionUID = -8124216741942423467L;

    private List<String> productIds;

    private List<String> lineIds;

    private Date from;

    private Date to;

    private Integer particleSize;

    private Integer timeZone;

    private String dataUnit;

    private String stopCode;

    private String ngReason;
}
