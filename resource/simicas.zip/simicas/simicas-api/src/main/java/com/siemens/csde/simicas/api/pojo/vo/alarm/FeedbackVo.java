package com.siemens.csde.simicas.api.pojo.vo.alarm;

import com.siemens.csde.simicas.common.base.BaseVo;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

/**
 * 反馈数据Vo
 *
 * @author z0043y5h
 * @version 1.0-SNAPSHOT
 * @date 2020/3/23 14:07
 **/
@Slf4j
@Getter
@Setter
@Builder
public class FeedbackVo extends BaseVo {

    private static final long serialVersionUID = -3574396919212968674L;

    private String id;

    private String content;

    private String email;

    private Integer status;

    private String submitTime;

    private String submmitter;

    private String title;

    private String type;

    private String userName;
}
