package com.siemens.csde.simicas.api.pojo.qo.config.product;

import com.siemens.csde.simicas.common.base.BaseQo;
import lombok.Getter;
import lombok.Setter;

/**
 * Product请求类
 *
 * @author z0043y5h
 * @version 1.0-SNAPSHOT
 * @date 2020/2/22 12:48
 **/
@Setter
@Getter
public class ProductQo extends BaseQo {

    private static final long serialVersionUID = 4639164187793857117L;

    private String id;

    private String productFamily;

    private String productGroup;

    private String productId;

    private String productName;

    private Double ict;
}
