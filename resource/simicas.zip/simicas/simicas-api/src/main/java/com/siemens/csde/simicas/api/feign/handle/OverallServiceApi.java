package com.siemens.csde.simicas.api.feign.handle;

import com.siemens.csde.simicas.api.constant.ServiceNameConstant;
import com.siemens.csde.simicas.api.pojo.vo.config.status.LineStatusVo;
import com.siemens.csde.simicas.api.pojo.vo.handle.kpi.OverallKpiVo;
import com.siemens.csde.simicas.common.base.BaseResult;
import java.util.Date;
import java.util.List;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;

/**
 * 总览业务api
 *
 * @author z0043y5h
 * @version 1.0-SNAPSHOT
 * @date 2020/2/27 1:27
 **/
@FeignClient(
        name = ServiceNameConstant.SERVICE_HANDLE,
        url = "${service.handle}",
        fallback = com.siemens.csde.simicas.api.feign.handle.OverallServiceApiFallback.class)
@Component("handleOverallServiceApi")
public interface OverallServiceApi {

    /**
     * 查询所有产线不同指标的最新值
     *
     * @param from from
     * @param to   to
     * @return com.siemens.csde.simicas.common.base.BaseResult<java.util.List < com.siemens.csde.simicas.api.pojo.vo.config.status.LineStatusVo>>
     * @author z0043y5h
     * @date 2020/3/23 10:43
     **/
    @GetMapping(value = "/overall/lineStatus", produces = MediaType.APPLICATION_JSON_VALUE)
    BaseResult<List<LineStatusVo>> lineStatus(@RequestParam(value = "from") Date from,
            @RequestParam(value = "to") Date to);

    /**
     * 获取overall kpi信息
     *
     * @param kpiName kpiName
     * @param from    from
     * @param to      to
     * @return com.siemens.csde.simicas.common.base.BaseResult< com.siemens.csde.simicas.api.pojo.vo.handle.kpi.OverallKpiVo>
     * @author z0043y5h
     * @date 2020/3/23 10:51
     **/
    @GetMapping(value = "/overall/kpi/{kpiName}", produces = MediaType.APPLICATION_JSON_VALUE)
    BaseResult<OverallKpiVo> listKpi(@PathVariable(value = "kpiName") String kpiName,
            @RequestParam(value = "from") Date from, @RequestParam(value = "to") Date to);
}
