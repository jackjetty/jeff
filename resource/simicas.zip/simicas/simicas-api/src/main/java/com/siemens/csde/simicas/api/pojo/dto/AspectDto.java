package com.siemens.csde.simicas.api.pojo.dto;

import com.google.gson.annotations.SerializedName;
import com.siemens.csde.simicas.common.base.BaseDto;
import com.siemens.csde.simicas.common.model.AssetBean.LinksBean;
import com.siemens.csde.simicas.common.model.PageBean;
import java.util.List;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AspectDto<T> extends BaseDto {

    private static final long serialVersionUID = 2726574084618340094L;

    @SerializedName("_embedded")
    private Embedded<T> embedded;

    @SerializedName("_links")
    private LinksBean linksBean;

    @SerializedName("page")
    private PageBean pageBean;

    @Getter
    @Setter
    public static class Embedded<T> {

        @SerializedName(value = "resources", alternate = {"aspects"})
        private List<T> resources;
    }

}
