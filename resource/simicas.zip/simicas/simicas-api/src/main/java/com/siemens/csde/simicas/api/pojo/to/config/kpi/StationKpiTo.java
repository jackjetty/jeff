package com.siemens.csde.simicas.api.pojo.to.config.kpi;

import com.siemens.csde.simicas.common.base.BaseTo;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
/**
 *  KPI 传输类
 * @author Z0040M9S
 * @version 1.0-SNAPSHOT
 * @date 2/12/2020 4:28 PM
 **/
@Setter
@Getter
public class StationKpiTo extends BaseTo {

    private static final long serialVersionUID = 1111170705983944244L;
    private String stationId;
    private String stationName;
    private List<KpiTo> kpis;
}