package com.siemens.csde.simicas.api.pojo.to.userview;

import com.siemens.csde.simicas.common.base.BaseTo;
import lombok.Getter;
import lombok.Setter;

/**
 * NoticeStatisticTo
 *
 * @author z0043y5h
 * @version 1.0-SNAPSHOT
 * @date 2020/2/14 21:35
 **/
@Getter
@Setter
public class NoticeStatisticTo extends BaseTo {

    private int webNum;

    private int emailNum;
}
