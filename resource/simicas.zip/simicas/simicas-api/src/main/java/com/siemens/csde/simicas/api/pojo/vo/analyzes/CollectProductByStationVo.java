package com.siemens.csde.simicas.api.pojo.vo.analyzes;

import com.siemens.csde.simicas.api.pojo.to.analyzes.ProductDataByStationTo;
import com.siemens.csde.simicas.api.pojo.to.analyzes.TeferenceLineDataTo;
import com.siemens.csde.simicas.common.base.BaseVo;
import java.util.List;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CollectProductByStationVo extends BaseVo {

    private static final long serialVersionUID = -6714331375591031597L;

    private List<ProductDataByStationTo> products;

    private TeferenceLineDataTo referenceLine;

    private Integer paticleSize;

    private String lineId;

    private String lineName;
}