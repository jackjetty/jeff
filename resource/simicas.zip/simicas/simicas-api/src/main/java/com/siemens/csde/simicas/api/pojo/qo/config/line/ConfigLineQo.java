package com.siemens.csde.simicas.api.pojo.qo.config.line;

import com.siemens.csde.simicas.common.base.BaseQo;
import com.siemens.csde.simicas.common.model.WorkSpaceModel;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
/**
 *  产线请求类
 * @author Z0040M9S
 * @version 1.0-SNAPSHOT
 * @date 2/12/2020 4:28 PM
 **/
@Setter
@Getter
public class ConfigLineQo extends BaseQo {

    private static final long serialVersionUID = -3988456568894301438L;

    private Basic basic;
    private List<MessageType> messageTypes;
    private String version;
    private WorkSpaceModel workSpaceModel;
    private List<ChangeOver> changeOvers;

    @Getter
    @Setter
    public static class ChangeOver {
        private String station;
        private List<ChangeOverType> inputs;
    }

    @Getter
    @Setter
    public static class ChangeOverType {
        private String name;
        private String dataKey;
        private List<String> values;
    }


    @Getter
    @Setter
    public static class Basic {

        private String assetId;
        private String description;
        private String productionLineId;
        private String productionLineName;
        private MSClient msClient;

    }

    @Getter
    @Setter
    public static class MSClient {

        private String tenantName;
        private String host;
        private String region;
        private String clientId;
        private String clientSecret;

    }


    @Getter
    @Setter
    public static class MessageType {

        private String description;
        private String displayName;
        private String name;
        private String station;
        private String type;
        private Option options;
        private List<Output> outputs;
        private Input inputs;
        private String version;
        //方便计算 ，对应的数据库存储id
        public transient String  kpiId;

    }


    @Getter
    @Setter
    public static class Input {

        private String apiType;
        private String apiProtocol;
        private String apiUrl;
        private String apiUser;
        private String apiPassword;
        private List<InputVariable> variable;


    }

    @Getter
    @Setter
    public static class InputVariable {

        private String name;
        private String dataKey;
        private String dataType;


    }


    @Getter
    @Setter
    public static class Option {
        private boolean defaultKpi;
        private boolean defaultExpr;
        private boolean extendIoUsed;
        private boolean supportChangeOver;


    }

    @Getter
    @Setter
    public static class Output {

        private String expression;
        private String aspectName;
        private String dataType;
        private String defaultValue;
        private Integer length;
        private String name;
        private String unit;
        private List<Range> ranges;
    }
    @Getter
    @Setter
    public static class Range {

        private String type;
        private String value;
    }


}