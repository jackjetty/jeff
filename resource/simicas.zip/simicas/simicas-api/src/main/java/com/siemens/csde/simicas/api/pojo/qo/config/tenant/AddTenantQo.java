package com.siemens.csde.simicas.api.pojo.qo.config.tenant;

import com.siemens.csde.simicas.common.base.BaseQo;
import lombok.Getter;
import lombok.Setter;

/**
 * 新增租户Qo
 *
 * @author z0043y5h
 * @version 1.0-SNAPSHOT
 * @date 2020/3/21 23:11
 **/
@Setter
@Getter
public class AddTenantQo extends BaseQo {

    private static final long serialVersionUID = -5614708929580129244L;

    private String tenantName;

    private String clientId;

    private String secret;
}
