package com.siemens.csde.simicas.api.pojo.vo.config.line;

import com.siemens.csde.simicas.api.pojo.qo.config.line.ConfigLineQo.Basic;
import com.siemens.csde.simicas.api.pojo.qo.config.line.ConfigLineQo.MessageType;
import com.siemens.csde.simicas.common.base.BaseVo;
import com.siemens.csde.simicas.common.model.WorkSpaceModel;
import java.util.List;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
/**
 *  产线配置响应类
 * @author Z0040M9S
 * @version 1.0-SNAPSHOT
 * @date 2/12/2020 4:28 PM
 **/
@Setter
@Getter
@Builder
public class LineVo extends BaseVo {

    private static final long serialVersionUID = -7545452265365937925L;
    private Basic basic;
    private List<MessageType> messageTypes;
    private String version;
    private WorkSpaceModel workSpaceModel;

}