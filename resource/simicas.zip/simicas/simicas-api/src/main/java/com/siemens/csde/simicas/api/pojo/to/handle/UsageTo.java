package com.siemens.csde.simicas.api.pojo.to.handle;

import com.siemens.csde.simicas.common.base.BaseTo;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

/**
 * UsageTo
 *
 * @author z004267r
 * @version 1.0-SNAPSHOT
 * @date 3/24/2020 3:28 PM
 **/
@Setter
@Getter
@Builder
public class UsageTo extends BaseTo {

    private static final long serialVersionUID = 4306301544299211055L;

}
