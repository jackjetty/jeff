package com.siemens.csde.simicas.api.pojo.qo.config.plan;

import com.siemens.csde.simicas.common.base.BaseQo;
import java.util.List;
import lombok.Getter;
import lombok.Setter;

/**
 * AddPlansQo
 *
 * @author z0043y5h
 * @version 1.0-SNAPSHOT
 * @date 2020/2/23 21:42
 **/
@Getter
@Setter
public class AddPlansQo extends BaseQo {

    private static final long serialVersionUID = -1997936692427847177L;

    private List<PlanQo> plans;
}
