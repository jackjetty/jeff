package com.siemens.csde.simicas.api.feign.config;

import com.siemens.csde.simicas.api.constant.ServiceNameConstant;
import com.siemens.csde.simicas.api.pojo.qo.config.line.AddLineSettingQo;
import com.siemens.csde.simicas.api.pojo.qo.config.line.ConfigLineQo;
import com.siemens.csde.simicas.api.pojo.to.config.line.LineItemTo;
import com.siemens.csde.simicas.api.pojo.vo.config.line.LineInfoVo;
import com.siemens.csde.simicas.api.pojo.vo.config.line.LineVo;
import com.siemens.csde.simicas.common.base.BaseResult;
import com.siemens.csde.simicas.common.valid.AddValidGroup;
import java.util.List;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
/**
 *  产线配置api
 * @author Z0040M9S
 * @version 1.0-SNAPSHOT
 * @date 2/12/2020 4:28 PM
 **/
@FeignClient(
        name = ServiceNameConstant.SERVICE_CONFIG,
        url = "${service.config}",
        fallback = LineServiceApiFallback.class)
@Component
public interface LineServiceApi {

    /**
     * 新增 or 更新产线配置
     * @author Z0040M9S
     * @param lineId :
     * @param configLineQo :
     * @return : com.siemens.csde.simicas.common.base.BaseResult<java.lang.String>
     * @date   2/25/2020 11:03 AM
     */
    @RequestMapping(value = "/line/config/{lineId}", method = RequestMethod.POST)
    BaseResult<String> configLine(@PathVariable(value = "lineId") String lineId,
            @RequestBody ConfigLineQo configLineQo);

    /**
     * 获取产线的配置信息
     * @author Z0040M9S
     * @param lineId :
     * @param configType :
     * @return : com.siemens.csde.simicas.common.base.BaseResult<com.siemens.csde.simicas.api.pojo.vo.config.line.LineVo>
     * @date   2/25/2020 11:04 AM
     */
    @RequestMapping(value = "/line/getLine/{lineId}", method = RequestMethod.GET)
    BaseResult<LineVo> getLine(@PathVariable(value = "lineId") String lineId,
            @RequestParam(value = "configType", required = false) String configType);

    /**
     * 获取产线的item （id、name）
     * @author Z0040M9S
     * @param lineId :
     * @return : com.siemens.csde.simicas.common.base.BaseResult<com.siemens.csde.simicas.api.pojo.vo.config.line.LineInfoVo>
     * @date   2/25/2020 11:04 AM
     */
    @RequestMapping(value = "/line/getLineInfo/{lineId}", method = RequestMethod.GET)
    BaseResult<LineInfoVo> getLineInfo(@PathVariable(value = "lineId") String lineId);

    /**
     * 获取产线item list
     * @author Z0040M9S
     * @param filter :
     * @return : com.siemens.csde.simicas.common.base.BaseResult<java.util.List<com.siemens.csde.simicas.api.pojo.to.config.line.LineItemTo>>
     * @date   2/25/2020 11:04 AM
     */
    @RequestMapping(value = "/line/listLineItems", method = RequestMethod.GET )
    BaseResult<List<LineItemTo>> listLineItems(@RequestParam(value = "filter", required = false) String filter);

    /**
     * 删除产线配置 by id
     * @author Z0040M9S
     * @param lineId :
     * @param configType :
     * @return : com.siemens.csde.simicas.common.base.BaseResult<java.lang.String>
     * @date   2/25/2020 11:05 AM
     */
    @RequestMapping(value = "/line/deleteLine/{lineId}", method = RequestMethod.DELETE )
    BaseResult<String> deleteLine(@PathVariable(value = "lineId") String lineId,
            @RequestParam(value = "configType", required = false) String configType);

    /**
     * 删除产线配置 by asset id
     * @author Z0040M9S
     * @param assetId :
     * @return : com.siemens.csde.simicas.common.base.BaseResult<java.lang.String>
     * @date   2/25/2020 11:05 AM
     */
    @RequestMapping(value = "/line/deleteLineByAssetId/asset/{assetId}", method = RequestMethod.DELETE )
    BaseResult<String> deleteLineByAssetId(@PathVariable(value = "assetId") String assetId);

    /**
     * 批量设置产线配置
     *
     * @param lineId           :
     * @param addLineSettingQo :
     * @return com.siemens.csde.simicas.common.base.BaseResult
     * @author z0043y5h
     * @date 2020/3/22 22:15
     **/
    @PostMapping(value = "/line/settingBatch/{lineId}", produces = MediaType.APPLICATION_JSON_VALUE)
    BaseResult<String> settingBatch(@PathVariable(value = "lineId") String lineId, @RequestBody @Validated({
            AddValidGroup.class}) AddLineSettingQo addLineSettingQo);
}
