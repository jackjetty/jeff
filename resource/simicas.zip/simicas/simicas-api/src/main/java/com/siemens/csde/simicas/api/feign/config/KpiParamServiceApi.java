package com.siemens.csde.simicas.api.feign.config;

import com.siemens.csde.simicas.api.constant.ServiceNameConstant;
import com.siemens.csde.simicas.api.pojo.qo.config.kpi.KpiParamQo;
import com.siemens.csde.simicas.api.pojo.to.config.kpi.KpiParamTo;
import com.siemens.csde.simicas.common.base.BaseResult;
import java.util.List;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 *  kpi param api
 * @author Z0040M9S
 * @version 1.0-SNAPSHOT
 * @date 2/12/2020 4:28 PM
 **/
@FeignClient(
        name = ServiceNameConstant.SERVICE_CONFIG,
        url = "${service.config}",
        fallback = KpiParamServiceApiFallback.class)
@Component
public interface KpiParamServiceApi {

    /**
     * 新增 kpi param formula
     * @author Z0040M9S
     * @param kpiId :
     * @param kpiParamQo :
     * @return : com.siemens.csde.simicas.common.base.BaseResult<java.lang.String>
     * @date   3/2/2020 2:52 PM
     */
    @RequestMapping(value = "/kpiParam/addKpiParam/kpi/{kpiId}", method = RequestMethod.POST)
    BaseResult<String> addKpiParam(@PathVariable(value = "kpiId") String kpiId,
            @RequestBody KpiParamQo kpiParamQo);

    /**
     * 修改 kpi param formula
     * @author Z0040M9S
     * @param kpiId :
     * @param kpiParamId :
     * @param kpiParamQo :
     * @return : com.siemens.csde.simicas.common.base.BaseResult<java.lang.String>
     * @date   3/2/2020 2:52 PM
     */
    @RequestMapping(value = "/kpiParam/updateKpiParam/kpi/{kpiId}/{kpiParamId}", method = RequestMethod.PUT)
    BaseResult<String> updateKpiParam(@PathVariable(value = "kpiId") String kpiId,
            @PathVariable(value = "kpiParamId") String kpiParamId,
            @RequestBody KpiParamQo kpiParamQo) ;

    /**
     * 获取 kpi param formula list
     * @author Z0040M9S
     * @param kpiId :
     * @return : com.siemens.csde.simicas.common.base.BaseResult<java.util.List<com.siemens.csde.simicas.api.pojo.to.config.kpi.KpiParamTo>>
     * @date   3/2/2020 2:53 PM
     */
    @RequestMapping(value = "/kpiParam/listKpiParam/kpi/{kpiId}", method = RequestMethod.GET)
    BaseResult<List<KpiParamTo>> listKpiParam(@PathVariable(value = "kpiId") String kpiId);

    /**
     * 删除 kpi param formula
     * @author Z0040M9S
     * @param kpiId :
     * @param paramId :
     * @return : com.siemens.csde.simicas.common.base.BaseResult<java.lang.String>
     * @date   3/2/2020 2:53 PM
     */
    @RequestMapping(value = "/kpiParam/deleteKpiParam/kpi/{kpiId}/{paramId}", method = RequestMethod.DELETE)
    BaseResult<String> deleteKpiParam(@PathVariable(value = "kpiId") String kpiId,
            @PathVariable(value = "paramId") String paramId);

}