package com.siemens.csde.simicas.api.pojo.qo.config.product;

import com.siemens.csde.simicas.common.base.BasePageQo;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

/**
 * ProductPageQo
 *
 * @author z0043y5h
 * @version 1.0-SNAPSHOT
 * @date 2020/2/22 17:55
 **/
@Getter
@Setter
@Slf4j
public class ProductPageQo extends BasePageQo {

    private static final long serialVersionUID = 3835161106684792255L;

    private String productId;

    private String filter;
}
