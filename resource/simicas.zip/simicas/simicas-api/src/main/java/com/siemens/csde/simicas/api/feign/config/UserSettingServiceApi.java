package com.siemens.csde.simicas.api.feign.config;

import com.siemens.csde.simicas.api.constant.ServiceNameConstant;
import com.siemens.csde.simicas.api.pojo.qo.config.usersetting.UserSettingQo;
import com.siemens.csde.simicas.api.pojo.vo.config.usersetting.UserSettingVo;
import com.siemens.csde.simicas.common.base.BaseResult;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

/**
 * 个性化配置api
 *
 * @author z0043y5h
 * @version 1.0-SNAPSHOT
 * @date 2020/3/12 14:41
 **/
@FeignClient(
        name = ServiceNameConstant.SERVICE_CONFIG,
        url = "${service.config}",
        fallback = UserSettingServiceApiFallBack.class)
@Component
public interface UserSettingServiceApi {

    /**
     * 新增用户个性化配置
     *
     * @param packageType   packageType
     * @param userSettingQo userSettingQo
     * @return com.siemens.csde.simicas.common.base.BaseResult<java.lang.String>
     * @author z0043y5h
     * @date 2020/3/12 11:41
     **/
    @PostMapping(value = "/userSetting/addSetting/package/{packageType}", produces = MediaType.APPLICATION_JSON_VALUE)
    BaseResult<String> addSetting(@PathVariable(value = "packageType") String packageType,
            @RequestBody UserSettingQo userSettingQo);

    /**
     * 修改用户个性化配置
     *
     * @param packageType   packageType
     * @param userSettingQo userSettingQo
     * @return com.siemens.csde.simicas.common.base.BaseResult
     * @author z0043y5h
     * @date 2020/3/12 11:57
     **/
    @PutMapping(value = "/userSetting/updateSetting/package/{packageType}", produces = MediaType.APPLICATION_JSON_VALUE)
    BaseResult updateSetting(@PathVariable(value = "packageType") String packageType,
            @RequestBody UserSettingQo userSettingQo);

    /**
     * 查询一条UserSetting
     *
     * @param packageType packageType
     * @param settingType settingType
     * @return com.siemens.csde.simicas.common.base.BaseResult<com.siemens.csde.simicas.api.pojo.vo.config.usersetting.UserSettingVo>
     * @author z0043y5h
     * @date 2020/2/22 12:08
     **/
    @GetMapping(value = "/userSetting/getSetting/package/{packageType}/{settingType}", produces = MediaType.APPLICATION_JSON_VALUE)
    BaseResult<UserSettingVo> getSetting(@PathVariable(value = "packageType") String packageType,
            @PathVariable(value = "settingType") String settingType);
}
