package com.siemens.csde.simicas.api.feign.config;

import com.google.gson.Gson;
import com.siemens.csde.simicas.api.constant.ServiceNameConstant;
import com.siemens.csde.simicas.api.pojo.qo.config.line.AddLineSettingQo;
import com.siemens.csde.simicas.api.pojo.qo.config.line.ConfigLineQo;
import com.siemens.csde.simicas.api.pojo.to.config.line.LineItemTo;
import com.siemens.csde.simicas.api.pojo.vo.config.line.LineInfoVo;
import com.siemens.csde.simicas.api.pojo.vo.config.line.LineVo;
import com.siemens.csde.simicas.common.base.BaseResult;
import com.siemens.csde.simicas.common.constant.enums.ResultEnum;
import java.util.List;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
/**
 *  产线配置异常处理类
 * @author Z0040M9S
 * @version 1.0-SNAPSHOT
 * @date 2/12/2020 4:28 PM
 **/
@Component
@Slf4j
public class LineServiceApiFallback implements LineServiceApi{

    @Override
    public BaseResult<String> configLine(String lineId, ConfigLineQo configLineQo) {
        log.error(new Gson().toJson(new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_CONFIG+" "+ ResultEnum.ERROR.getInfo())));
        return new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_CONFIG+" "+ ResultEnum.ERROR.getInfo());
    }

    @Override
    public BaseResult<LineVo> getLine(String lineId, String configType) {
        log.error(new Gson().toJson(new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_CONFIG+" "+ ResultEnum.ERROR.getInfo())));
        return new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_CONFIG+" "+ ResultEnum.ERROR.getInfo());
    }

    @Override
    public BaseResult<LineInfoVo> getLineInfo(String lineId) {
        log.error(new Gson().toJson(new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_CONFIG+" "+ ResultEnum.ERROR.getInfo())));
        return new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_CONFIG+" "+ ResultEnum.ERROR.getInfo());
    }

    @Override
    public BaseResult<List<LineItemTo>> listLineItems(String filter) {
        log.error(new Gson().toJson(new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_CONFIG+" "+ ResultEnum.ERROR.getInfo())));
        return new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_CONFIG+" "+ ResultEnum.ERROR.getInfo());
    }

    @Override
    public BaseResult<String> deleteLine(String lineId, String configType) {
        log.error(new Gson().toJson(new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_CONFIG+" "+ ResultEnum.ERROR.getInfo())));
        return new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_CONFIG+" "+ ResultEnum.ERROR.getInfo());
    }

    @Override
    public BaseResult<String> deleteLineByAssetId(String assetId) {
        log.error(new Gson().toJson(new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_CONFIG + " " + ResultEnum.ERROR.getInfo())));
        return new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_CONFIG + " " + ResultEnum.ERROR.getInfo());
    }

    @Override
    public BaseResult<String> settingBatch(String lineId, AddLineSettingQo addLineSettingQo) {
        log.error(new Gson().toJson(new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_CONFIG+" "+ ResultEnum.ERROR.getInfo())));
        return new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_CONFIG+" "+ ResultEnum.ERROR.getInfo());
    }
}