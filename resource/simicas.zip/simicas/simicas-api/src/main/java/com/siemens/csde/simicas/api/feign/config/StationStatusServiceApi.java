package com.siemens.csde.simicas.api.feign.config;

import com.siemens.csde.simicas.api.constant.ServiceNameConstant;
import com.siemens.csde.simicas.api.pojo.qo.config.status.StationStatusConfigQo;
import com.siemens.csde.simicas.api.pojo.to.config.status.StationOptionTo;
import com.siemens.csde.simicas.api.pojo.to.config.status.StationStatusOptionTo;
import com.siemens.csde.simicas.api.pojo.to.config.status.StationStatusTo;
import com.siemens.csde.simicas.common.base.BaseResult;
import java.util.List;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 *  工站状态配置
 * @author Z0040M9S
 * @version 1.0-SNAPSHOT
 * @date 2/12/2020 4:28 PM
 **/
@FeignClient(
        name = ServiceNameConstant.SERVICE_CONFIG,
        url = "${service.config}",
        fallback = StationStatusServiceApiFallback.class)
@Component
public interface StationStatusServiceApi {

    /**
     * 获取工站选项
     * @author Z0040M9S
     * @param lineId :
     * @return : com.siemens.csde.simicas.common.base.BaseResult<java.util.List<com.siemens.csde.simicas.api.pojo.to.config.status.StationOptionTo>>
     * @date   2/28/2020 11:22 AM
     */
    @RequestMapping(value = "/stationStatus/listStationOptions/{lineId}", method = RequestMethod.GET)
    BaseResult<List<StationOptionTo>> listStationOptions(@PathVariable(value = "lineId") String lineId) ;

    /**
     * 获取工站状态的下拉选项
     * @author Z0040M9S
     * @param lineId :
     * @return : com.siemens.csde.simicas.common.base.BaseResult<java.util.List<com.siemens.csde.simicas.api.pojo.to.config.status.StationStatusOptionTo>>
     * @date   2/28/2020 11:23 AM
     */
    @RequestMapping(value = "/stationStatus/listStatusOptions/{lineId}", method = RequestMethod.GET)
    BaseResult<List<StationStatusOptionTo>> listStatusOptions(@PathVariable(value = "lineId") String lineId);

    /**
     * 新增工站状态配置
     * @author Z0040M9S
     * @param lineId :
     * @param stationStatusConfigQo :
     * @return : com.siemens.csde.simicas.common.base.BaseResult<java.lang.String>
     * @date   2/28/2020 11:23 AM
     */
    @RequestMapping(value = "/stationStatus/addStatusConfig/line/{lineId}", method = RequestMethod.POST)
    BaseResult<String> addStatusConfig(@PathVariable(value = "lineId") String lineId,
            @RequestBody StationStatusConfigQo stationStatusConfigQo);

    /**
     * 修改工站状态配置
     * @author Z0040M9S
     * @param lineId :
     * @param statusId :
     * @param stationStatusConfigQo :
     * @return : com.siemens.csde.simicas.common.base.BaseResult<java.lang.String>
     * @date   2/28/2020 11:23 AM
     */
    @RequestMapping(value = "/stationStatus/updateStatusConfig/line/{lineId}/{statusId}", method = RequestMethod.PUT)
    BaseResult<String> updateStatusConfig(@PathVariable(value = "lineId") String lineId,
            @PathVariable(value = "statusId") String statusId,
            @RequestBody StationStatusConfigQo stationStatusConfigQo);

    /**
     * 获取工站状态配置list
     * @author Z0040M9S
     * @param lineId :
     * @return : com.siemens.csde.simicas.common.base.BaseResult<java.util.List<com.siemens.csde.simicas.api.pojo.to.config.status.StationStatusTo>>
     * @date   2/28/2020 11:23 AM
     */
    @RequestMapping(value = "/stationStatus/listStatusConfig/line/{lineId}", method = RequestMethod.GET)
    BaseResult<List<StationStatusTo>> listStatusConfig(@PathVariable(value = "lineId") String lineId);

    /**
     * 删除工站状态配置
     * @author Z0040M9S
     * @param lineId :
     * @param statusId :
     * @return : com.siemens.csde.simicas.common.base.BaseResult<java.lang.String>
     * @date   2/28/2020 11:24 AM
     */
    @RequestMapping(value = "/stationStatus/deleteStatusConfig/line/{lineId}/{statusId}", method = RequestMethod.DELETE)
    BaseResult<String> deleteStatusConfig(@PathVariable(value = "lineId") String lineId,
            @PathVariable(value = "statusId") String statusId);
}