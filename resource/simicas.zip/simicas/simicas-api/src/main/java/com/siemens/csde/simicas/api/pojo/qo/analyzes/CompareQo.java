package com.siemens.csde.simicas.api.pojo.qo.analyzes;

import com.siemens.csde.simicas.api.pojo.to.analyzes.CompareDetailTo;
import com.siemens.csde.simicas.common.base.BaseQo;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

/**
 * 比较Qo
 *
 * @author z0043y5h
 * @version 1.0-SNAPSHOT
 * @date 2020/3/23 18:10
 **/
@Getter
@Setter
@Slf4j
public class CompareQo extends BaseQo {

    private static final long serialVersionUID = 842574722490375350L;

    private String compareId;

    private Integer compareMode;

    private Integer showMode;

    private List<CompareDetailTo> compareList;
}
