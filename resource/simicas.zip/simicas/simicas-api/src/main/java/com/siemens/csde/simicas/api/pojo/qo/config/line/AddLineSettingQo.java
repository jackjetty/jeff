package com.siemens.csde.simicas.api.pojo.qo.config.line;

import com.siemens.csde.simicas.api.pojo.qo.config.status.LineStatusConfigQo;
import com.siemens.csde.simicas.api.pojo.qo.config.status.StationStatusConfigQo;
import com.siemens.csde.simicas.common.base.BaseQo;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

/**
 * 新增产线设置Qo
 *
 * @author z0043y5h
 * @version 1.0-SNAPSHOT
 * @date 2020/3/22 21:54
 **/
@Slf4j
@Getter
@Setter
public class AddLineSettingQo extends BaseQo {

    private static final long serialVersionUID = -1344272532248837053L;

    private List<AlarmCategorySubQo> alarmConfig;

    private List<LineStatusConfigQo> statusConfig;

    private List<StationStatusConfigQo> wsStatusConfig;
}
