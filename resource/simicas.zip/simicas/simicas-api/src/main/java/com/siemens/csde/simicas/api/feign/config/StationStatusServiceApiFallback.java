package com.siemens.csde.simicas.api.feign.config;

import com.google.gson.Gson;
import com.siemens.csde.simicas.api.constant.ServiceNameConstant;
import com.siemens.csde.simicas.api.pojo.qo.config.status.StationStatusConfigQo;
import com.siemens.csde.simicas.api.pojo.to.config.status.StationOptionTo;
import com.siemens.csde.simicas.api.pojo.to.config.status.StationStatusOptionTo;
import com.siemens.csde.simicas.api.pojo.to.config.status.StationStatusTo;
import com.siemens.csde.simicas.common.base.BaseResult;
import com.siemens.csde.simicas.common.constant.enums.ResultEnum;
import java.util.List;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
/**
 *  工站状态配置异常处理类
 * @author Z0040M9S
 * @version 1.0-SNAPSHOT
 * @date 2/12/2020 4:28 PM
 **/
@Component
@Slf4j
public class StationStatusServiceApiFallback implements StationStatusServiceApi{

    @Override
    public BaseResult<List<StationOptionTo>> listStationOptions(String lineId) {
        log.error(new Gson().toJson(new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_CONFIG+" "+ ResultEnum.ERROR.getInfo())));
        return new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_CONFIG+" "+ ResultEnum.ERROR.getInfo());
    }

    @Override
    public BaseResult<List<StationStatusOptionTo>> listStatusOptions(String lineId) {
        log.error(new Gson().toJson(new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_CONFIG+" "+ ResultEnum.ERROR.getInfo())));
        return new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_CONFIG+" "+ ResultEnum.ERROR.getInfo());
    }

    @Override
    public BaseResult<String> addStatusConfig(String lineId, StationStatusConfigQo stationStatusConfigQo) {
        log.error(new Gson().toJson(new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_CONFIG+" "+ ResultEnum.ERROR.getInfo())));
        return new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_CONFIG+" "+ ResultEnum.ERROR.getInfo());
    }

    @Override
    public BaseResult<String> updateStatusConfig(String lineId, String statusId, StationStatusConfigQo stationStatusConfigQo) {
        log.error(new Gson().toJson(new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_CONFIG+" "+ ResultEnum.ERROR.getInfo())));
        return new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_CONFIG+" "+ ResultEnum.ERROR.getInfo());
    }

    @Override
    public BaseResult<List<StationStatusTo>> listStatusConfig(String lineId) {
        log.error(new Gson().toJson(new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_CONFIG+" "+ ResultEnum.ERROR.getInfo())));
        return new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_CONFIG+" "+ ResultEnum.ERROR.getInfo());
    }

    @Override
    public BaseResult<String> deleteStatusConfig(String lineId, String statusId) {
        log.error(new Gson().toJson(new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_CONFIG+" "+ ResultEnum.ERROR.getInfo())));
        return new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_CONFIG+" "+ ResultEnum.ERROR.getInfo());
    }
}