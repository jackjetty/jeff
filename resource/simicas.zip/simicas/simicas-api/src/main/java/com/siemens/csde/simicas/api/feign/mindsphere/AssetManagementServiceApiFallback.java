package com.siemens.csde.simicas.api.feign.mindsphere;

import com.google.gson.Gson;
import com.siemens.csde.simicas.api.constant.ServiceNameConstant;
import com.siemens.csde.simicas.api.pojo.dto.AspectDto;
import com.siemens.csde.simicas.common.base.BaseResult;
import com.siemens.csde.simicas.common.constant.enums.ResultEnum;
import com.siemens.csde.simicas.common.model.AspectSchemaBean;
import com.siemens.csde.simicas.common.model.AssetBean;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@Component
@Slf4j
public class AssetManagementServiceApiFallback implements AssetManagementServiceApi {

    @Override
    public AssetBean getAsset(String id, String token) {
        log.error(new Gson().toJson(new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_MINDSPHERE+" "+ ResultEnum.ERROR.getInfo())));
        return null;
    }

    @Override
    public AspectDto<AspectSchemaBean> getAspect(String id, String token, Integer size) {
        log.error(new Gson().toJson(new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_MINDSPHERE+" "+ ResultEnum.ERROR.getInfo())));
        return null;
    }
}
