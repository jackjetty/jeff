package com.siemens.csde.simicas.api.pojo.qo.analyzes;

import com.siemens.csde.simicas.common.base.BaseQo;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * 收藏Qo
 *
 * @author z0043y5h
 * @version 1.0-SNAPSHOT
 * @date 2020/3/23 18:00
 **/
@ToString
@Getter
@Setter
public class FavoriteQo extends BaseQo {

    private static final long serialVersionUID = 7106669782979908054L;

    private String id;

    private String title;

    private String pageUrl;

    private String pageInfo;

    private Integer pageType;
}
