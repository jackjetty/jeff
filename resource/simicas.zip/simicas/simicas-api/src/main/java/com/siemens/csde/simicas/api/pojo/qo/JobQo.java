package com.siemens.csde.simicas.api.pojo.qo;

import com.siemens.csde.simicas.common.base.BaseQo;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class JobQo extends BaseQo {

    private static final long serialVersionUID = -1116685432485472715L;

    //job名
    private String jobName;

    //任务组名
    private String jobGroupName;

    //触发器名
    private String triggerName;

    //触发器组名
    private String triggerGroupName;

    //时间设置，参考quartz说明文档
    private String cron;

    private String className;

}
