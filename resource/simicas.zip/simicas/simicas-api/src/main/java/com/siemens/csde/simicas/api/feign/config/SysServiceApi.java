package com.siemens.csde.simicas.api.feign.config;

import com.siemens.csde.simicas.api.constant.ServiceNameConstant;
import com.siemens.csde.simicas.api.pojo.qo.config.sys.AddAppReleaseNoticeQo;
import com.siemens.csde.simicas.api.pojo.vo.config.sys.AppReleaseInfoVo;
import com.siemens.csde.simicas.api.pojo.vo.config.sys.AppReleaseNoticeVo;
import com.siemens.csde.simicas.common.base.BaseResult;
import com.siemens.csde.simicas.common.valid.AddValidGroup;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

/**
 * 系統信息api
 *
 * @author z0043y5h
 * @version 1.0-SNAPSHOT
 * @date 2020/3/20 17:15
 **/
@FeignClient(
        name = ServiceNameConstant.SERVICE_CONFIG,
        url = "${service.config}",
        fallback = SysServiceApiFallBack.class)
@Component
public interface SysServiceApi {

    /**
     * 新增 app 发布通知
     *
     * @param addAppReleaseNoticeQo addAppReleaseNoticeQo
     * @return com.siemens.csde.simicas.common.base.BaseResult<java.lang.String>
     * @author z0043y5h
     * @date 2020/3/20 17:46
     **/
    @PostMapping(value = "/sys/addReleaseNotice", produces = MediaType.APPLICATION_JSON_VALUE)
    BaseResult<String> addReleaseNotice(
            @RequestBody @Validated({AddValidGroup.class}) AddAppReleaseNoticeQo addAppReleaseNoticeQo);

    /**
     * 获取 app 发布信息
     *
     * @return com.siemens.csde.simicas.common.base.BaseResult<com.siemens.csde.simicas.api.pojo.vo.config.sys.AppReleaseInfoVo>
     * @author z0043y5h
     * @date 2020/3/20 17:49
     **/
    @GetMapping(value = "/sys/version", produces = MediaType.APPLICATION_JSON_VALUE)
    BaseResult<AppReleaseInfoVo> getVersion();

    /**
     * 获取 app 发布通知
     *
     * @return com.siemens.csde.simicas.common.base.BaseResult<com.siemens.csde.simicas.api.pojo.vo.config.sys.AppReleaseNoticeVo>
     * @author z0043y5h
     * @date 2020/3/20 17:48
     **/
    @GetMapping(value = "/sys/listReleaseNotice", produces = MediaType.APPLICATION_JSON_VALUE)
    BaseResult<AppReleaseNoticeVo> listReleaseNotice();
}
