package com.siemens.csde.simicas.api.pojo.vo.config.sys;

import com.siemens.csde.simicas.common.base.BaseVo;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

/**
 * 应用发布信息Vo
 *
 * @author z0043y5h
 * @version 1.0-SNAPSHOT
 * @date 2020/3/20 17:39
 **/
@Slf4j
@Getter
@Setter
public class AppReleaseInfoVo extends BaseVo {

    private static final long serialVersionUID = 8162776015619600493L;

    private String version;

    private String releaseDate;

    private String releaseNote;
}
