package com.siemens.csde.simicas.api.pojo.qo.config.kpi;

import com.siemens.csde.simicas.common.base.BaseQo;
import java.util.List;
import lombok.Getter;
import lombok.Setter;

/**
 * FormulaQo
 *
 * @author z004267r
 * @version 1.0-SNAPSHOT
 * @date 4/12/2020 10:05 PM
 **/
@Setter
@Getter
public class FormulaQo extends BaseQo {

    private static final long serialVersionUID = -4120545906621707028L;

    private String formula;
    private List<String> params;

}
