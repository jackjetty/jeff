package com.siemens.csde.simicas.api.pojo.qo.config.overall;

import com.siemens.csde.simicas.common.base.BaseQo;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

/**
 * OverallLineQo
 *
 * @author z0043y5h
 * @version 1.0-SNAPSHOT
 * @date 2020/2/26 0:54
 **/
@Slf4j
@Getter
@Setter
public class OverallLineQo extends BaseQo {

    private static final long serialVersionUID = 8009896939486167063L;

    private String lineId;

    private String lineName;

    private boolean enable;
}
