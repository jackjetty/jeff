package com.siemens.csde.simicas.api.pojo.to.analyzes;

import com.siemens.csde.simicas.common.base.BaseTo;
import com.siemens.csde.simicas.common.constant.enums.EntityEnum;
import java.util.Date;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
/**
 * 统计数据传递类
 *
 * @author z0043y5h
 * @version 1.0-SNAPSHOT
 * @date 2020/3/23 14:37
 **/
@Slf4j
@Getter
@Setter
public class StatDataTo extends BaseTo {

    private static final long serialVersionUID = -359324299124793249L;
    private EntityEnum entityType;
    private String entityId;
    private String productId;
    private String entityName;
    private String productName;
    private Number dataValue;
    private String dataFormat;
    private String dataUnit;
    private Date statisticTime;
    private Integer particleSize;
    private String type;

}