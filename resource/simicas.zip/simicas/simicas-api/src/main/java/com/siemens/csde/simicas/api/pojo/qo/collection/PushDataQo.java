package com.siemens.csde.simicas.api.pojo.qo.collection;

import com.siemens.csde.simicas.common.base.BaseQo;
import java.util.HashMap;
import java.util.List;
import java.util.Optional;
import lombok.Getter;
import lombok.Setter;
/**
 *  推送第三方数据的接口请求类
 * @author Z0040M9S
 * @version 1.0-SNAPSHOT
 * @date 2/12/2020 4:28 PM
 **/
@Setter
@Getter
public class PushDataQo extends BaseQo {

    private static final long serialVersionUID = -1116665432485472715L;

    private String tenant;

    private String lineId;

    private String stationId;

    private List<PushData> data;

    @Getter
    @Setter
    public static class PushData {
        private String kpi;
        private List<PushDetail> details;
    }

    @Getter
    @Setter
    public static class PushDetail extends HashMap<String,Object> {

        public static final String KEY_CHANGEOVER="ChangeOver";
        public static final String KEY_PRODUCTID="ProductID";
        public static final String KEY_BATCHID="BatchID";
        public static final String KEY_ORDERID="OrderID";
        public static final String KEY_TIME="_time";

        public boolean getChangeOver() {

            return Optional.ofNullable(this.get(KEY_CHANGEOVER)).map(obj->Boolean.parseBoolean(obj.toString())).orElse(false);

        }

        public String getProductId(){

            return  this.getValue(KEY_PRODUCTID);

        }

        public String getBatchId(){

            return  this.getValue(KEY_BATCHID);

        }

        public String getOrderId(){

            return  this.getValue(KEY_ORDERID);

        }

        public String getTime(){

            return  this.getValue(KEY_TIME);

        }

       public String getValue(String key){

            return Optional.ofNullable(this.get(key)).map(obj-> obj.toString()).orElse(null);

        }

    }


}
