package com.siemens.csde.simicas.api.pojo.vo.handle.line;

import com.google.gson.annotations.SerializedName;
import com.siemens.csde.simicas.common.base.BaseVo;
import java.util.List;
import java.util.Map;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

/**
 * 产线指标数据Vo
 *
 * @author z0043y5h
 * @version 1.0-SNAPSHOT
 * @date 2020/3/28 9:20
 **/
@Slf4j
@Getter
@Setter
public class LineKpiVo<T> extends BaseVo {

    private static final long serialVersionUID = -2857103780867496752L;

    private String kpiName;

    private String lineId;

    private String lineName;

    private String productId;

    private String productName;

    private String orderId;

    private String unit;

    private String value;

    private String fpyValue;

    private String defectValue;

    private String runningTime;

    private String downTime;

    private String total;

    private String label;

    private String visual;

    private Integer errorCode;

    private Boolean downtimeCategory;

    @SerializedName("_time")
    private String time;

    private List<T> detail;

    @Getter
    @Setter
    @Builder
    public static class TimeUsageKpiDetail {

        private String value;

        private String name;
    }

    @Getter
    @Setter
    @Builder
    public static class NGReasonKpiDetail {

        private String value;

        private String name;
    }

    @Getter
    @Setter
    @Builder
    public static class OutputKpiDetail {

        @SerializedName("_time")
        private String time;

        private Map<String, String> value;
    }

    @Getter
    @Setter
    @Builder
    public static class EFFKpiDetail {

        @SerializedName("_time")
        private String time;

        private String value;

        private String ict;

        private String act;
    }
}
