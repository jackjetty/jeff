package com.siemens.csde.simicas.api.pojo.to.analyzes;

import com.siemens.csde.simicas.common.base.BaseTo;
import lombok.Getter;
import lombok.Setter;

/**
 * 比较详情To
 *
 * @author z0043y5h
 * @version 1.0-SNAPSHOT
 * @date 2020/3/26 11:58
 **/
@Getter
@Setter
public class CompareDetailTo extends BaseTo {

    private static final long serialVersionUID = -8739059004995268951L;

    private String id;

    private String lineId;

    private String lineName;

    private String productId;

    private String productName;

    private String stationId;

    private String stationName;

    private String startTime;

    private String endTime;

    private String kpi;

    private Boolean active;
}
