package com.siemens.csde.simicas.api.pojo.qo.config.kpi;

import com.siemens.csde.simicas.common.base.BaseQo;
import lombok.Getter;
import lombok.Setter;
/**
 *  KPI 请求类
 * @author Z0040M9S
 * @version 1.0-SNAPSHOT
 * @date 2/12/2020 4:28 PM
 **/
@Setter
@Getter
public class KpiQo extends BaseQo {

    private static final long serialVersionUID = 4877299291043109092L;
    private String parentId;
    private Integer level;
    private String name;
    private String formula;
    private String unit;

}