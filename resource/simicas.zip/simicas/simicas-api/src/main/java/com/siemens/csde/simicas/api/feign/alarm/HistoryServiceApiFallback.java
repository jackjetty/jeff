package com.siemens.csde.simicas.api.feign.alarm;

import com.google.gson.Gson;
import com.siemens.csde.simicas.api.constant.ServiceNameConstant;
import com.siemens.csde.simicas.api.pojo.vo.alarm.AlarmHiVo;
import com.siemens.csde.simicas.common.base.BasePageVo;
import com.siemens.csde.simicas.common.base.BaseResult;
import com.siemens.csde.simicas.common.constant.enums.ResultEnum;
import java.util.Date;
import javax.validation.constraints.Pattern;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

/**
 * HistoryServiceApi 异常处理类
 *
 * @author z0043y5h
 * @version 1.0-SNAPSHOT
 * @date 2020/3/23 11:45
 **/
@Component("alarmHistoryServiceApiFallback")
@Slf4j
public class HistoryServiceApiFallback implements HistoryServiceApi {

    @Override
    public BaseResult deleteAlarm(String lineId, String alarmId) {
        log.error(new Gson().toJson(new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_ALARM + " " + ResultEnum.ERROR.getInfo())));
        return new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_ALARM + " " + ResultEnum.ERROR.getInfo());
    }

    @Override
    public BaseResult<BasePageVo<AlarmHiVo>> listAlarm(String lineId, Date from, Date to, Integer type, Integer index,
            Integer size, String filter, String orderByColumn, @Pattern(regexp = "ASC|DESC") String orderByType) {
        log.error(new Gson().toJson(new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_ALARM + " " + ResultEnum.ERROR.getInfo())));
        return new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_ALARM + " " + ResultEnum.ERROR.getInfo());
    }
}
