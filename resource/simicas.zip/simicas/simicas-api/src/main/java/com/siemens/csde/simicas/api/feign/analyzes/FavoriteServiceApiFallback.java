package com.siemens.csde.simicas.api.feign.analyzes;

import com.google.gson.Gson;
import com.siemens.csde.simicas.api.constant.ServiceNameConstant;
import com.siemens.csde.simicas.api.pojo.qo.analyzes.FavoriteQo;
import com.siemens.csde.simicas.api.pojo.vo.analyzes.FavoriteVo;
import com.siemens.csde.simicas.common.base.BaseResult;
import com.siemens.csde.simicas.common.constant.enums.ResultEnum;
import java.util.List;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

/**
 * 收藏api 异常处理类
 *
 * @author z0043y5h
 * @version 1.0-SNAPSHOT
 * @date 2020/3/23 17:47
 **/
@Component
@Slf4j
public class FavoriteServiceApiFallback implements FavoriteServiceApi {

    @Override
    public BaseResult addFavorite(FavoriteQo favoriteQo) {
        log.error(new Gson().toJson(new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_ANALYZES + " " + ResultEnum.ERROR.getInfo())));
        return new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_ANALYZES + " " + ResultEnum.ERROR.getInfo());
    }

    @Override
    public BaseResult updateFavorite(String id, FavoriteQo favoriteQo) {
        log.error(new Gson().toJson(new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_ANALYZES + " " + ResultEnum.ERROR.getInfo())));
        return new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_ANALYZES + " " + ResultEnum.ERROR.getInfo());
    }

    @Override
    public BaseResult deleteFavorite(String id) {
        log.error(new Gson().toJson(new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_ANALYZES + " " + ResultEnum.ERROR.getInfo())));
        return new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_ANALYZES + " " + ResultEnum.ERROR.getInfo());
    }

    @Override
    public BaseResult<List<FavoriteVo>> listFavorite() {
        log.error(new Gson().toJson(new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_ANALYZES + " " + ResultEnum.ERROR.getInfo())));
        return new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_ANALYZES + " " + ResultEnum.ERROR.getInfo());
    }
}
