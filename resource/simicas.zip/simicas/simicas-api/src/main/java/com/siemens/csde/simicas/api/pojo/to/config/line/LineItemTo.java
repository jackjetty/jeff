package com.siemens.csde.simicas.api.pojo.to.config.line;

import com.siemens.csde.simicas.common.base.BaseTo;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
/**
 *  产线列表传输类
 * @author Z0040M9S
 * @version 1.0-SNAPSHOT
 * @date 2/12/2020 4:28 PM
 **/
@Slf4j
@Getter
@Setter
public class LineItemTo extends BaseTo {

    private static final long serialVersionUID = 8094468141908775644L;

    private String lineId;
    private String lineName;

}