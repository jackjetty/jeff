package com.siemens.csde.simicas.api.feign.alarm;

import com.siemens.csde.simicas.api.constant.ServiceNameConstant;
import com.siemens.csde.simicas.api.pojo.qo.alarm.JudgeAlarmQo;
import com.siemens.csde.simicas.api.pojo.qo.alarm.NotifyPolicyQo;
import com.siemens.csde.simicas.api.pojo.qo.alarm.RuleQo;
import com.siemens.csde.simicas.api.pojo.to.alarm.AlarmCfgKpiTo;
import com.siemens.csde.simicas.api.pojo.to.alarm.AlarmCfgNotifyPolicyTo;
import com.siemens.csde.simicas.api.pojo.to.alarm.AlarmCfgRuleTo;
import com.siemens.csde.simicas.api.pojo.vo.alarm.AlarmDataVo;
import com.siemens.csde.simicas.api.pojo.vo.alarm.JudgeAlarmVo;
import com.siemens.csde.simicas.common.base.BaseResult;
import java.util.Date;
import java.util.List;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

/**
 *  告警api
 * @author Z0040M9S
 * @version 1.0-SNAPSHOT
 * @date 2/12/2020 4:28 PM
 **/
@FeignClient(
        name = ServiceNameConstant.SERVICE_ALARM,
        url = "${service.alarm}",
        fallback = AlarmServiceApiFallback.class)
@Component
public interface AlarmServiceApi {

    /**
     * 判断报警
     * @author Z0040M9S
     * @param kpi :
     * @param judgeAlarmQo :
     * @return : com.siemens.csde.simicas.common.base.BaseResult<com.siemens.csde.simicas.api.pojo.vo.alarm.JudgeAlarmVo>
     * @date   2/12/2020 6:23 PM
     */
     @RequestMapping(value = "/handler/judgeAlarm/kpi/{kpi}", method = RequestMethod.POST)
     BaseResult<JudgeAlarmVo> judgeAlarm(@PathVariable("kpi") String kpi,@RequestBody JudgeAlarmQo judgeAlarmQo);

    /**
     * 新增策略
     * @author Z0040M9S
     * @param notifyPolicyQo :
     * @return : com.siemens.csde.simicas.common.base.BaseResult<String>
     * @date   2/12/2020 6:23 PM
     */
     @RequestMapping(value = "/notifyPolicy/addNotifyPolicy", method = RequestMethod.POST)
     BaseResult<String> addNotifyPolicy(@RequestBody NotifyPolicyQo notifyPolicyQo);

    /**
     * 修改策略
     * @author Z0040M9S
     * @param id :
     * @param notifyPolicyQo :
     * @return : com.siemens.csde.simicas.common.base.BaseResult<String>
     * @date   2/12/2020 6:24 PM
     */
    @RequestMapping(value = "/notifyPolicy/updateNotifyPolicy/{id}", method = RequestMethod.PUT)
    BaseResult<String> updateNotifyPolicy(@PathVariable(value = "id") String id,@RequestBody NotifyPolicyQo notifyPolicyQo);

    /**
     * 删除策略
     * @author Z0040M9S
     * @param id :
     * @return : com.siemens.csde.simicas.common.base.BaseResult<String>
     * @date   2/12/2020 6:24 PM
     */
    @RequestMapping(value = "/notifyPolicy/deleteNotifyPolicy/{id}", method = RequestMethod.DELETE)
    BaseResult<String> deleteNotifyPolicy(@PathVariable(value = "id") String id);

    /**
     * 通知策略列表
     * @author Z0040M9S
     * @param lineId :
     * @return : com.siemens.csde.simicas.common.base.BaseResult<java.util.List<AlarmCfgNotifyPolicyTo>>
     * @date   2/13/2020 3:30 PM
     */
    @RequestMapping(value = "/notifyPolicy/listNotifyPolicy/line/{lineId}", method = RequestMethod.GET)
    BaseResult<List<AlarmCfgNotifyPolicyTo>> listNotifyPolicy(@PathVariable(value = "lineId") String lineId);

    /**
     * 新增报警规则
     * @author Z0040M9S
     * @param ruleQo :
     * @return : com.siemens.csde.simicas.common.base.BaseResult<String>
     * @date   2/13/2020 3:31 PM
     */
    @RequestMapping(value = "/rule/addRule",  method = RequestMethod.POST)
    BaseResult<String> addRule(@RequestBody RuleQo ruleQo);

    /**
     * 修改报警规则
     * @author Z0040M9S
     * @param id :
     * @param ruleQo :
     * @return : com.siemens.csde.simicas.common.base.BaseResult<String>
     * @date   2/13/2020 3:31 PM
     */
    @RequestMapping(value = "/rule/updateRule/{id}", method = RequestMethod.PUT)
    BaseResult<String> updateRule(@PathVariable(value = "id") String id,@RequestBody RuleQo ruleQo);

    /**
     * 删除报警规则
     * @author Z0040M9S
     * @param id :
     * @return : com.siemens.csde.simicas.common.base.BaseResult<String>
     * @date   2/13/2020 3:31 PM
     */
    @RequestMapping(value = "/rule/deleteRule/{id}", method = RequestMethod.DELETE)
    BaseResult<String> deleteRule(@PathVariable(value = "id") String id);

    /**
     * 报警规则列表
     * @author Z0040M9S
     * @param lineId :
     * @return : com.siemens.csde.simicas.common.base.BaseResult<java.util.List<AlarmCfgRuleTo>>
     * @date   2/13/2020 3:31 PM
     */
    @RequestMapping(value = "/rule/listRule/line/{lineId}", method = RequestMethod.GET)
    BaseResult<List<AlarmCfgRuleTo>> listRule(@PathVariable(value = "lineId") String lineId);

    /**
     * 获取kpi列表
     *
     * @param lineId   lineId
     * @return com.siemens.csde.simicas.common.base.BaseResult<java.util.List < java.lang.String>>
     * @author z0043y5h
     * @date 2020/3/23 11:35
     **/
    @RequestMapping(value = "/rule/listKpi/line/{lineId}", method = RequestMethod.GET)
    BaseResult<List<AlarmCfgKpiTo>> listKpi(@PathVariable(value = "lineId") String lineId);

    /**
     * 拉取alarm 记录
     * @author Z0040M9S
     * @param lineId :
     * @param from :
     * @param to :
     * @return : com.siemens.csde.simicas.common.base.BaseResult<com.siemens.csde.simicas.api.pojo.vo.alarm.AlarmDataVo>
     * @date   3/10/2020 3:21 PM
     */
    @RequestMapping(value = "/pullData/alarmList/line/{lineId}", method = RequestMethod.GET)
    BaseResult<AlarmDataVo> alarmList( @PathVariable(value = "lineId") String lineId,
            @RequestParam(value = "from") Date from,
            @RequestParam(value = "to")  Date to);

    /**
     * 拉取notice 记录
     * @author Z0040M9S
     * @param lineId :
     * @param from :
     * @param to :
     * @return : com.siemens.csde.simicas.common.base.BaseResult<com.siemens.csde.simicas.api.pojo.vo.alarm.AlarmDataVo>
     * @date   3/10/2020 3:22 PM
     */
    @RequestMapping(value = "/pullData/noticeList/line/{lineId}", method = RequestMethod.GET)
    BaseResult<AlarmDataVo> noticeList(@PathVariable(value = "lineId") String lineId,
            @RequestParam(value = "from") Date from,
            @RequestParam(value = "to")  Date to);
}
