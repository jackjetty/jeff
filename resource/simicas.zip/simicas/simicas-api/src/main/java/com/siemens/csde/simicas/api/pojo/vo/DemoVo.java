package com.siemens.csde.simicas.api.pojo.vo;

import com.siemens.csde.simicas.api.pojo.to.DemoTo;
import com.siemens.csde.simicas.common.base.BaseVo;
import lombok.Getter;
import lombok.Setter;


@Getter
@Setter
public class DemoVo extends BaseVo {

    private static final long serialVersionUID = 5363342232258180057L;

    private String module;

    private DemoTo data;


}
