package com.siemens.csde.simicas.api.feign.config;

import com.google.gson.Gson;
import com.siemens.csde.simicas.api.constant.ServiceNameConstant;
import com.siemens.csde.simicas.api.pojo.qo.config.product.AddProductsQo;
import com.siemens.csde.simicas.api.pojo.qo.config.product.ProductQo;
import com.siemens.csde.simicas.api.pojo.vo.config.product.ProductItemVo;
import com.siemens.csde.simicas.api.pojo.vo.config.product.ProductVo;
import com.siemens.csde.simicas.common.base.BasePageVo;
import com.siemens.csde.simicas.common.base.BaseResult;
import com.siemens.csde.simicas.common.constant.enums.ResultEnum;
import java.util.List;
import javax.validation.constraints.Pattern;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@Component
@Slf4j
public class ProductServiceApiFallback implements ProductServiceApi {

    @Override
    public BaseResult<String> addProduct(ProductQo productQo) {
        log.error(new Gson().toJson(new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_CONFIG + " " + ResultEnum.ERROR.getInfo())));
        return new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_CONFIG + " " + ResultEnum.ERROR.getInfo());
    }

    @Override
    public BaseResult addProducts(AddProductsQo addProductsQo) {
        log.error(new Gson().toJson(new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_CONFIG + " " + ResultEnum.ERROR.getInfo())));
        return new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_CONFIG + " " + ResultEnum.ERROR.getInfo());
    }

    @Override
    public BaseResult validateProducts(AddProductsQo addProductsQo) {
        log.error(new Gson().toJson(new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_CONFIG + " " + ResultEnum.ERROR.getInfo())));
        return new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_CONFIG + " " + ResultEnum.ERROR.getInfo());
    }

    @Override
    public BaseResult updateProduct(ProductQo productQo) {
        log.error(new Gson().toJson(new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_CONFIG + " " + ResultEnum.ERROR.getInfo())));
        return new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_CONFIG + " " + ResultEnum.ERROR.getInfo());
    }

    @Override
    public BaseResult<ProductVo> getProduct(String productId) {
        log.error(new Gson().toJson(new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_CONFIG + " " + ResultEnum.ERROR.getInfo())));
        return new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_CONFIG + " " + ResultEnum.ERROR.getInfo());
    }

    @Override
    public BaseResult<BasePageVo<ProductVo>> listProduct(Integer index, Integer size, String filter,
            String orderByColumn,
            @Pattern(regexp = "ASC|DESC") String orderByType) {
        log.error(new Gson().toJson(new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_CONFIG + " " + ResultEnum.ERROR.getInfo())));
        return new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_CONFIG + " " + ResultEnum.ERROR.getInfo());
    }

    @Override
    public BaseResult<List<ProductItemVo>> listProductItems(String filter, String orderByColumn,
            @Pattern(regexp = "ASC|DESC") String orderByType) {
        log.error(new Gson().toJson(new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_CONFIG + " " + ResultEnum.ERROR.getInfo())));
        return new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_CONFIG + " " + ResultEnum.ERROR.getInfo());
    }

    @Override
    public BaseResult deleteProduct(String productId) {
        log.error(new Gson().toJson(new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_CONFIG + " " + ResultEnum.ERROR.getInfo())));
        return new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_CONFIG + " " + ResultEnum.ERROR.getInfo());
    }

    @Override
    public BaseResult deleteProducts() {
        log.error(new Gson().toJson(new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_CONFIG + " " + ResultEnum.ERROR.getInfo())));
        return new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_CONFIG + " " + ResultEnum.ERROR.getInfo());
    }
}
