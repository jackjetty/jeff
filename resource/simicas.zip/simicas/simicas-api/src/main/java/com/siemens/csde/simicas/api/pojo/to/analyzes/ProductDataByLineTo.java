package com.siemens.csde.simicas.api.pojo.to.analyzes;

import com.siemens.csde.simicas.common.base.BaseTo;
import java.util.List;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

/**
 * 产品数据 by line To
 *
 * @author z0043y5h
 * @version 1.0-SNAPSHOT
 * @date 2020/3/23 14:37
 **/
@Slf4j
@Builder
@Getter
@Setter
public class ProductDataByLineTo extends BaseTo {

    private static final long serialVersionUID = -9048717807584727238L;

    private String productId;

    private String productName;

    private List<LineDataTo> lines;

    private List<ProductDataDetail> datas;


    @Getter
    @Setter
    @Builder
    public static class ProductDataDetail {

        private Number data;

        private String time;

        private String from;

        private String to;

        private String unit;

        private String format;
    }
}
