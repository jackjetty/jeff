package com.siemens.csde.simicas.api.feign.mindsphere;


import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;
import static org.springframework.web.bind.annotation.RequestMethod.GET;

import com.alibaba.fastjson.JSONObject;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

@FeignClient(
        name = "identity-client",
        url = "${service.advance.identity-management:https://gateway.cn1.mindsphere-in.cn/api/identitymanagement/v3}",
        fallback = IdentityManagementServiceApiFallback.class)
public interface IdentityManagementServiceApi {

    /**
     * 获取TechnicalUser数据
     *
     * @param token token
     * @return com.alibaba.fastjson.JSONObject
     * @author z0043y5h
     * @date 9/16/2019 5:49 PM
     */
    @RequestMapping(value = "/Users", method = RequestMethod.GET)
    JSONObject getUsers(@RequestHeader("Authorization") String token);

    /**
     * 获取TechnicalUser数据
     *
     * @param token      token
     * @param filter     filter
     * @param attributes attributes
     * @return com.alibaba.fastjson.JSONObject
     * @author z0043y5h
     * @date 9/16/2019 5:49 PM
     */
    @RequestMapping(value = "/Users", method = GET, consumes = APPLICATION_JSON_VALUE)
    JSONObject getUsers(@RequestHeader("Authorization") String token, @RequestParam("attributes") String attributes,
            @RequestParam("filter") String filter);
}