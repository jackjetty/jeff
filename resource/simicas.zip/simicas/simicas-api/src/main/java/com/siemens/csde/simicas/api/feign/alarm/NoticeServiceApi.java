package com.siemens.csde.simicas.api.feign.alarm;

import com.siemens.csde.simicas.api.constant.ServiceNameConstant;
import com.siemens.csde.simicas.api.pojo.qo.alarm.MarkAlarmNoticesQo;
import com.siemens.csde.simicas.api.pojo.vo.alarm.NoticeHiVo;
import com.siemens.csde.simicas.common.base.BaseResult;
import java.util.Date;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

/**
 * 通知业务api
 *
 * @author z0043y5h
 * @version 1.0-SNAPSHOT
 * @date 2020/3/23 13:37
 **/
@FeignClient(
        name = ServiceNameConstant.SERVICE_ALARM,
        url = "${service.alarm}",
        fallback = NoticeServiceApiFallback.class)
@Component
public interface NoticeServiceApi {

    /**
     * 标记告警
     *
     * @param markAlarmNoticesQo markAlarmNoticesQo
     * @return com.siemens.csde.simicas.common.base.BaseResult
     * @author z0043y5h
     * @date 2020/3/23 13:54
     **/
    @PutMapping(value = "/notice/markNotice", produces = MediaType.APPLICATION_JSON_VALUE)
    BaseResult markNotice(@RequestBody MarkAlarmNoticesQo markAlarmNoticesQo);

    /**
     * 根据产线id获取告警历史
     *
     * @param lineId lineId
     * @param from   from
     * @param to     to
     * @return com.siemens.csde.simicas.common.base.BaseResult<com.siemens.csde.simicas.api.pojo.vo.alarm.NoticeHiVo>
     * @author z0043y5h
     * @date 2020/3/23 13:54
     **/
    @GetMapping(value = "/notice/listNotice/line/{lineId}", produces = MediaType.APPLICATION_JSON_VALUE)
    BaseResult<NoticeHiVo> listNotice(@PathVariable("lineId") String lineId,
            @RequestParam(value = "from", required = false) Date from,
            @RequestParam(value = "to", required = false) Date to);
}
