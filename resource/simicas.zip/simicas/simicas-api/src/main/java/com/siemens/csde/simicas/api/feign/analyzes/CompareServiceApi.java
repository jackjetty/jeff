package com.siemens.csde.simicas.api.feign.analyzes;

import com.siemens.csde.simicas.api.constant.ServiceNameConstant;
import com.siemens.csde.simicas.api.pojo.qo.analyzes.CompareQo;
import com.siemens.csde.simicas.api.pojo.vo.analyzes.CompareVo;
import com.siemens.csde.simicas.common.base.BaseResult;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

/**
 * 比较api
 *
 * @author z0043y5h
 * @version 1.0-SNAPSHOT
 * @date 2020/3/23 17:47
 **/
@FeignClient(
        name = ServiceNameConstant.SERVICE_ANALYZES,
        url = "${service.analyzes}",
        fallback = CompareServiceApiFallback.class)
@Component
public interface CompareServiceApi {

    /**
     * 添加比较
     *
     * @param compareQo compareQo
     * @return com.siemens.csde.simicas.common.base.BaseResult<java.lang.String>
     * @author z0043y5h
     * @date 2020/3/23 18:15
     **/
    @PostMapping(value = "/compare/addCompare", produces = MediaType.APPLICATION_JSON_VALUE)
    BaseResult addCompare(@RequestBody CompareQo compareQo);

    /**
     * 编辑比较
     *
     * @param id        id
     * @param compareQo compareQo
     * @return com.siemens.csde.simicas.common.base.BaseResult
     * @author z0043y5h
     * @date 2020/3/23 18:15
     **/
    @PutMapping(value = "/compare/updateCompare/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
    BaseResult updateCompare(@PathVariable("id") String id, @RequestBody CompareQo compareQo);

    /**
     * 删除比较
     *
     * @param id id
     * @return com.siemens.csde.simicas.common.base.BaseResult
     * @author z0043y5h
     * @date 2020/3/23 18:15
     **/
    @DeleteMapping(value = "/compare/deleteCompare/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
    BaseResult deleteCompare(@PathVariable("id") String id);

    /**
     * 获取比较
     *
     * @return com.siemens.csde.simicas.common.base.BaseResult<com.siemens.csde.simicas.api.pojo.vo.analyzes.CompareVo>
     * @author z0043y5h
     * @date 2020/3/23 18:15
     **/
    @GetMapping(value = "/compare/getCompare", produces = MediaType.APPLICATION_JSON_VALUE)
    BaseResult<CompareVo> getCompare();
}
