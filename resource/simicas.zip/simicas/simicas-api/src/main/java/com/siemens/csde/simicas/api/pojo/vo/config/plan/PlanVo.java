package com.siemens.csde.simicas.api.pojo.vo.config.plan;

import com.siemens.csde.simicas.common.base.BaseVo;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

/**
 * PlanVo
 *
 * @author z0043y5h
 * @version 1.0-SNAPSHOT
 * @date 2020/2/23 23:31
 **/
@Slf4j
@Getter
@Setter
public class PlanVo extends BaseVo {

    private static final long serialVersionUID = -1476738250030659835L;

    private String id;

    private String planDate;

    private Integer quantity;

    private String productId;

    private String lineId;

    private String productName;
}
