package com.siemens.csde.simicas.api.pojo.qo.config.plan;

import com.siemens.csde.simicas.common.base.BaseQo;
import java.util.Date;
import lombok.Getter;
import lombok.Setter;

/**
 * PlanQo
 *
 * @author z0043y5h
 * @version 1.0-SNAPSHOT
 * @date 2020/2/23 21:43
 **/
@Setter
@Getter
public class PlanQo extends BaseQo {

    private static final long serialVersionUID = 838851205007493392L;

    private String id;

    private Date planDate;

    private Integer quantity;

    private String productId;

    private String lineId;
}
