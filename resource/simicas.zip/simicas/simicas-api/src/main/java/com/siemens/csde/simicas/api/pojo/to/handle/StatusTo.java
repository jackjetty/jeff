package com.siemens.csde.simicas.api.pojo.to.handle;

import com.google.gson.annotations.SerializedName;
import com.siemens.csde.simicas.common.base.BaseTo;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

/**
 * StatusTo
 *
 * @author z004267r
 * @version 1.0-SNAPSHOT
 * @date 3/24/2020 3:23 PM
 **/
@Setter
@Getter
@Builder
public class StatusTo extends BaseTo {

    private static final long serialVersionUID = 1763908419838647828L;

    @SerializedName(value = "Status")
    private String dataValue;

}
