package com.siemens.csde.simicas.api.pojo.qo.config.line;

import com.siemens.csde.simicas.api.pojo.qo.alarm.RuleQo;
import com.siemens.csde.simicas.common.base.BaseQo;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

/**
 * 告警数据分类Qo
 *
 * @author z0043y5h
 * @version 1.0-SNAPSHOT
 * @date 2020/3/22 21:54
 **/
@Slf4j
@Getter
@Setter
public class AlarmCategorySubQo extends BaseQo {

    private static final long serialVersionUID = 1575396900031719432L;

    private String messageType;

    private List<String> emailAddresses;

    private List<RuleQo> alarmRuleSubQos;

}