package com.siemens.csde.simicas.api.feign.cloudfoundry;

import com.google.gson.JsonObject;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@FeignClient(
        name = "cloudfoundry-client",
        url = "https://api.cf.cn1.mindsphere-in.cn/v3/apps")
        //fallback = AppsServiceApiFallback.class)
public interface AppsServiceApi {

    /**
     * 获取TechnicalUser数据
     *
     * @param token token
     * @return java.util.List<com.siemens.csde.macb.common.model.stream.IotTimeSeriesItem>
     * @author z0043y5h
     * @date 8/23/2019 5:49 PM
     */
    @RequestMapping(value = "{appId}/processes", method = RequestMethod.GET)
    JsonObject getAppInfo(@PathVariable("appId") String appId,@RequestHeader("Authorization") String token);
}
