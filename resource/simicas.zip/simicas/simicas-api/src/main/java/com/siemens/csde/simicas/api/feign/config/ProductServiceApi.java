package com.siemens.csde.simicas.api.feign.config;

import com.siemens.csde.simicas.api.constant.ServiceNameConstant;
import com.siemens.csde.simicas.api.pojo.qo.config.product.AddProductsQo;
import com.siemens.csde.simicas.api.pojo.qo.config.product.ProductQo;
import com.siemens.csde.simicas.api.pojo.vo.config.product.ProductItemVo;
import com.siemens.csde.simicas.api.pojo.vo.config.product.ProductVo;
import com.siemens.csde.simicas.common.base.BasePageVo;
import com.siemens.csde.simicas.common.base.BaseResult;
import java.util.List;
import javax.validation.constraints.Pattern;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

@FeignClient(
        name = ServiceNameConstant.SERVICE_CONFIG,
        url = "${service.config}",
        fallback = ProductServiceApiFallback.class)
@Component
public interface ProductServiceApi {

    @PostMapping(value = "/product/addProduct", produces = MediaType.APPLICATION_JSON_VALUE)
    BaseResult<String> addProduct(@RequestBody ProductQo productQo);

    @PostMapping(value = "/product/addProducts", produces = MediaType.APPLICATION_JSON_VALUE)
    BaseResult addProducts(@RequestBody AddProductsQo addProductsQo);

    @PostMapping(value = "/product/validateProducts", produces = MediaType.APPLICATION_JSON_VALUE)
    BaseResult validateProducts(@RequestBody AddProductsQo addProductsQo);

    @PutMapping(value = "/product/updateProduct", produces = MediaType.APPLICATION_JSON_VALUE)
    BaseResult updateProduct(@RequestBody ProductQo productQo);

    @GetMapping(value = "/product/getProduct/{productId}", produces = MediaType.APPLICATION_JSON_VALUE)
    BaseResult<ProductVo> getProduct(@PathVariable(value = "productId") String productId);

    @GetMapping(value = "/product/listProduct", produces = MediaType.APPLICATION_JSON_VALUE)
    BaseResult<BasePageVo<ProductVo>> listProduct(
            @RequestParam(value = "index", required = false) Integer index,
            @RequestParam(value = "size", required = false) Integer size,
            @RequestParam(value = "filter", required = false) String filter,
            @RequestParam(value = "orderByColumn", required = false) String orderByColumn,
            @RequestParam(value = "orderByType", required = false) @Pattern(regexp = "ASC|DESC") String orderByType);

    @GetMapping(value = "/product/listProductItems", produces = MediaType.APPLICATION_JSON_VALUE)
    BaseResult<List<ProductItemVo>> listProductItems(
            @RequestParam(value = "filter", required = false) String filter,
            @RequestParam(value = "orderByColumn", required = false) String orderByColumn,
            @RequestParam(value = "orderByType", required = false) @Pattern(regexp = "ASC|DESC") String orderByType);

    @DeleteMapping(value = "/product/deleteProduct/{productId}", produces = MediaType.APPLICATION_JSON_VALUE)
    BaseResult deleteProduct(@PathVariable(value = "productId") String productId);

    @DeleteMapping(value = "/product/deleteProducts", produces = MediaType.APPLICATION_JSON_VALUE)
    BaseResult deleteProducts();
}
