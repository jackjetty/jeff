package com.siemens.csde.simicas.api.pojo.to.alarm;
import com.siemens.csde.simicas.common.base.BaseDto;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
/**
 *  报警kpi 传输类
 * @author Z0040M9S
 * @version 1.0-SNAPSHOT
 * @date 2/12/2020 4:28 PM
 **/
@Slf4j
@Getter
@Setter
@Builder
public class AlarmCfgKpiTo extends BaseDto {

    private static final long serialVersionUID = 7909620149204852595L;
    private String kpi;
    private String dataType;
}