package com.siemens.csde.simicas.api.pojo.vo.config.product;

import com.siemens.csde.simicas.common.base.BaseVo;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

/**
 * ProductItemVo
 *
 * @author z0043y5h
 * @version 1.0-SNAPSHOT
 * @date 2020/2/23 14:46
 **/
@Getter
@Setter
@Builder
public class ProductItemVo extends BaseVo {

    private static final long serialVersionUID = 451223873257476072L;

    private String productId;

    private String productName;
}
