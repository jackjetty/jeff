package com.siemens.csde.simicas.api.feign.config;

import com.siemens.csde.simicas.api.constant.ServiceNameConstant;
import com.siemens.csde.simicas.api.pojo.qo.config.plan.AddPlansQo;
import com.siemens.csde.simicas.api.pojo.qo.config.plan.PlanQo;
import com.siemens.csde.simicas.api.pojo.vo.config.plan.PlanCountVo;
import com.siemens.csde.simicas.api.pojo.vo.config.plan.PlanVo;
import com.siemens.csde.simicas.common.base.BasePageVo;
import com.siemens.csde.simicas.common.base.BaseResult;
import java.util.Date;
import javax.validation.constraints.Pattern;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

/**
 * 计划配置api
 *
 * @author z0043y5h
 * @version 1.0-SNAPSHOT
 * @date 2020/2/24 0:25
 **/
@FeignClient(
        name = ServiceNameConstant.SERVICE_CONFIG,
        url = "${service.config}",
        fallback = PlanServiceApiFallback.class)
@Component
public interface PlanServiceApi {

    /**
     * 新增计划
     *
     * @param lineId     lineId
     * @param addPlansQo addPlansQo
     * @return com.siemens.csde.simicas.common.base.BaseResult
     * @author z0043y5h
     * @date 2020/2/23 21:46
     **/
    @PostMapping(value = "/plan/addPlan/line/{lineId}", produces = MediaType.APPLICATION_JSON_VALUE)
    BaseResult addPlan(@PathVariable(value = "lineId") String lineId, @RequestBody AddPlansQo addPlansQo);

    /**
     * 校验导入数据是否与数据库有冲突
     *
     * @param lineId     lineId
     * @param addPlansQo addPlansQo
     * @return com.siemens.csde.simicas.common.base.BaseResult
     * @author z0043y5h
     * @date 2020/2/23 22:11
     **/
    @PostMapping(value = "/plan/validatePlan/line/{lineId}", produces = MediaType.APPLICATION_JSON_VALUE)
    BaseResult validatePlan(@PathVariable(value = "lineId") String lineId, @RequestBody AddPlansQo addPlansQo);

    /**
     * 编辑计划根据产线id
     *
     * @param lineId lineId
     * @param id     id
     * @param planQo planQo
     * @return com.siemens.csde.simicas.common.base.BaseResult
     * @author z0043y5h
     * @date 2020/2/23 22:44
     **/
    @PutMapping(value = "/plan/updatePlan/line/{lineId}/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
    BaseResult updatePlan(@PathVariable(value = "lineId") String lineId, @PathVariable(value = "id") String id,
            @RequestBody PlanQo planQo);

    /**
     * 删除计划
     *
     * @param lineId lineId
     * @param planId planId
     * @return com.siemens.csde.simicas.common.base.BaseResult
     * @author z0043y5h
     * @date 2020/2/23 23:26
     **/
    @DeleteMapping(value = "/plan/deletePlan/line/{lineId}/{planId}", produces = MediaType.APPLICATION_JSON_VALUE)
    BaseResult deletePlan(@PathVariable(value = "lineId") String lineId, @PathVariable(value = "planId") String planId);

    /**
     * 分页查询计划
     *
     * @param lineId        lineId
     * @param index         index
     * @param size          size
     * @param planDate      planDate
     * @param filter        filter
     * @param orderByColumn orderByColumn
     * @param orderByType   orderByType
     * @return com.siemens.csde.simicas.common.base.BaseResult<BasePageVo < PlanVo>>
     * @author z0043y5h
     * @date 2020/2/23 23:38
     **/
    @GetMapping(value = "/plan/listPlan/line/{lineId}", produces = MediaType.APPLICATION_JSON_VALUE)
    BaseResult<BasePageVo<PlanVo>> listPlan(@PathVariable(value = "lineId") String lineId,
            @RequestParam(value = "index", required = false) Integer index,
            @RequestParam(value = "size", required = false) Integer size,
            @RequestParam(value = "planDate", required = false) Date planDate,
            @RequestParam(value = "filter", required = false) String filter,
            @RequestParam(value = "orderByColumn", required = false) String orderByColumn,
            @RequestParam(value = "orderByType", required = false) @Pattern(regexp = "ASC|DESC") String orderByType);

    /**
     * 获取计划总数根据产线id
     *
     * @param lineId lineId
     * @param from   from
     * @param to     to
     * @return com.siemens.csde.simicas.common.base.BaseResult<com.siemens.csde.simicas.api.pojo.vo.config.plan.PlanCountVo>
     * @author z0043y5h
     * @date 2020/3/26 17:51
     **/
    @GetMapping(value = "/plan/countQuantity/line/{lineId}", produces = MediaType.APPLICATION_JSON_VALUE)
    BaseResult<PlanCountVo> countQuantity(@PathVariable(value = "lineId", required = false) String lineId,
            @RequestParam(value = "from", required = false) Date from,
            @RequestParam(value = "to", required = false) Date to);
}
