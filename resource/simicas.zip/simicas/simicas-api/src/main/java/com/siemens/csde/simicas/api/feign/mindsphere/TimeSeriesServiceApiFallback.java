package com.siemens.csde.simicas.api.feign.mindsphere;

import com.google.gson.Gson;
import com.siemens.csde.simicas.api.constant.ServiceNameConstant;
import com.siemens.csde.simicas.common.base.BaseResult;
import com.siemens.csde.simicas.common.constant.enums.ResultEnum;
import com.siemens.csde.simicas.common.model.IotTimeSeriesBean;
import java.util.List;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@Component
@Slf4j
public class TimeSeriesServiceApiFallback implements TimeSeriesServiceApi {

    @Override
    public List<IotTimeSeriesBean> getIotTimeSeries(String entity, String propertySetName, String from, String to, Integer limit, String select,
            String token) {
        log.error(new Gson().toJson(new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_MINDSPHERE+" "+ ResultEnum.ERROR.getInfo())));
        return null;
    }

    @Override
    public void putTimeSeries(String entity, String propertySetName, List<IotTimeSeriesBean> timeSeriesItems, String token) {
        log.error(new Gson().toJson(new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_MINDSPHERE+" "+ ResultEnum.ERROR.getInfo())));
    }
}
