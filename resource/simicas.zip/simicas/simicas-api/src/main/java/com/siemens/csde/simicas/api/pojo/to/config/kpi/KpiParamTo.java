package com.siemens.csde.simicas.api.pojo.to.config.kpi;

import com.siemens.csde.simicas.common.base.BaseTo;
import lombok.Getter;
import lombok.Setter;
/**
 *  KPI Param 传输类
 * @author Z0040M9S
 * @version 1.0-SNAPSHOT
 * @date 2/12/2020 4:28 PM
 **/
@Setter
@Getter
public class KpiParamTo extends BaseTo {

    private static final long serialVersionUID = 4452585479021447728L;

    private String paramId;
    private String kpiId;
    private String expression;
    private String name;
    private String script;

}