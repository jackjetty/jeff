package com.siemens.csde.simicas.api.feign.config;

import com.siemens.csde.simicas.api.constant.ServiceNameConstant;
import com.siemens.csde.simicas.api.pojo.qo.config.kpi.KpiQo;
import com.siemens.csde.simicas.api.pojo.to.config.kpi.KpiTo;
import com.siemens.csde.simicas.common.base.BaseResult;
import java.util.List;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 *  产线配置kpi api
 * @author Z0040M9S
 * @version 1.0-SNAPSHOT
 * @date 2/12/2020 4:28 PM
 **/
@FeignClient(
        name = ServiceNameConstant.SERVICE_CONFIG,
        url = "${service.config}",
        fallback = LineKpiServiceApiFallback.class)
@Component
public interface LineKpiServiceApi {

    /**
     * 新增kpi
     * @author Z0040M9S
     * @param lineId :
     * @param kpiQo :
     * @return : com.siemens.csde.simicas.common.base.BaseResult<java.lang.String>
     * @date   3/2/2020 10:05 AM
     */
    @RequestMapping(value = "/lineKpi/addKpi/line/{lineId}", method = RequestMethod.POST)
    BaseResult<String> addKpi(@PathVariable(value = "lineId") String lineId,
            @RequestBody KpiQo kpiQo);

    /**
     * 修改kpi
     * @author Z0040M9S
     * @param lineId :
     * @param kpiId :
     * @param kpiQo :
     * @return : com.siemens.csde.simicas.common.base.BaseResult<java.lang.String>
     * @date   3/2/2020 10:06 AM
     */
    @RequestMapping(value = "/lineKpi/updateKpi/line/{lineId}/{kpiId}", method = RequestMethod.PUT)
    BaseResult<String> updateKpi(@PathVariable(value = "lineId") String lineId,
            @PathVariable(value = "kpiId") String kpiId,
            @RequestBody KpiQo kpiQo);

    /**
     * 获取kpi list
     * @author Z0040M9S
     * @param lineId :
     * @return : com.siemens.csde.simicas.common.base.BaseResult<java.util.List<com.siemens.csde.simicas.api.pojo.to.config.kpi.KpiTo>>
     * @date   3/2/2020 10:06 AM
     */
    @RequestMapping(value = "/lineKpi/listKpi/line/{lineId}", method = RequestMethod.GET)
    BaseResult<List<KpiTo>> listKpi(@PathVariable(value = "lineId") String lineId);

    /**
     * 删除kpi
     * @author Z0040M9S
     * @param lineId :
     * @param kpiId :
     * @return : com.siemens.csde.simicas.common.base.BaseResult<java.lang.String>
     * @date   3/2/2020 10:06 AM
     */
    @RequestMapping(value = "/lineKpi/deleteKpi/line/{lineId}/{kpiId}", method = RequestMethod.DELETE)
    BaseResult<String> deleteKpi(@PathVariable(value = "lineId") String lineId,
            @PathVariable(value = "kpiId") String kpiId) ;
}