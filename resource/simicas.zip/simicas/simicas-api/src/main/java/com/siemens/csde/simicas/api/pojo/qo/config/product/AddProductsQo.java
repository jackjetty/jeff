package com.siemens.csde.simicas.api.pojo.qo.config.product;

import com.siemens.csde.simicas.common.base.BaseQo;
import java.util.List;
import lombok.Getter;
import lombok.Setter;

/**
 * AddProductsQo
 *
 * @author z0043y5h
 * @version 1.0-SNAPSHOT
 * @date 2020/2/22 15:19
 **/
@Getter
@Setter
public class AddProductsQo extends BaseQo {

    private static final long serialVersionUID = 9047306063923203081L;

    private List<ProductQo> products;
}