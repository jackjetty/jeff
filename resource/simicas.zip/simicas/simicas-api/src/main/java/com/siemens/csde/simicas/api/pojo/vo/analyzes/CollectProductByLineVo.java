package com.siemens.csde.simicas.api.pojo.vo.analyzes;

import com.siemens.csde.simicas.api.pojo.to.analyzes.ProductDataByLineTo;
import com.siemens.csde.simicas.api.pojo.to.analyzes.TeferenceLineDataTo;
import com.siemens.csde.simicas.common.base.BaseVo;
import java.util.List;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CollectProductByLineVo extends BaseVo {

    private static final long serialVersionUID = -1448293761711812161L;

    private List<ProductDataByLineTo> products;

    private TeferenceLineDataTo referenceLine;

    private Integer paticleSize;
}