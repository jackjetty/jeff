package com.siemens.csde.simicas.api.feign.alarm;

import com.siemens.csde.simicas.api.constant.ServiceNameConstant;
import com.siemens.csde.simicas.api.pojo.vo.alarm.UsageReportVo;
import com.siemens.csde.simicas.common.base.BaseResult;
import java.util.Date;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

/**
 * UserViewServiceApi 产线、告警统计api
 *
 * @author z0043y5h
 * @version 1.0-SNAPSHOT
 * @date 2020/2/14 16:17
 **/
@FeignClient(
        name = ServiceNameConstant.SERVICE_ALARM,
        url = "${service.alarm}",
        fallback = UserViewServiceApiFallback.class)
@Component
public interface UserViewServiceApi {

    /**
     * 获取用户资源使用报告数据，包括：用户产线使用情况、告警数量统计
     *
     * @param timeZone 时区[-8,8]
     * @param from     查询开始时间（包含该时刻）
     * @param to       查询结束时间（不包含该时刻）
     * @return BaseResult<UsageReportVo>
     * @author z0043y5h
     * @date 2020/2/14 16:10
     **/
    @GetMapping(value = "/userview/usagereport", produces = MediaType.APPLICATION_JSON_VALUE)
    BaseResult<UsageReportVo> usagereport(
            @RequestParam("timeZone") String timeZone,
            @RequestParam("from") Date from,
            @RequestParam("to") Date to);
}
