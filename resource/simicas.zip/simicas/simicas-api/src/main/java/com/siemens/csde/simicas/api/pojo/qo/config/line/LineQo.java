package com.siemens.csde.simicas.api.pojo.qo.config.line;

import com.siemens.csde.simicas.api.pojo.qo.config.line.ConfigLineQo.MSClient;
import com.siemens.csde.simicas.common.base.BaseQo;
import lombok.Getter;
import lombok.Setter;

/**
 * LineQo
 *
 * @author z004267r
 * @version 1.0-SNAPSHOT
 * @date 4/7/2020 1:56 PM
 **/
@Setter
@Getter
public class LineQo extends BaseQo {

    private String assetId;

    private String lineId;

    private String name;

    private String workstationModel;

    private String version;

    private String tenant;

    private MSClient msClientInfo;

}
