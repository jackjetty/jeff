package com.siemens.csde.simicas.api.pojo.qo.config.kpi;

import com.siemens.csde.simicas.common.base.BaseQo;
import lombok.Getter;
import lombok.Setter;
/**
 *  KPI  Param 请求类
 * @author Z0040M9S
 * @version 1.0-SNAPSHOT
 * @date 2/12/2020 4:28 PM
 **/
@Setter
@Getter
public class KpiParamQo extends BaseQo {


    private static final long serialVersionUID = 3104287875883599000L;
    private String name;
    private String expression;
    private String script;
}