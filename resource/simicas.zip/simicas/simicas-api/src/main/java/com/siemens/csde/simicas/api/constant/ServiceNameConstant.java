package com.siemens.csde.simicas.api.constant;

public interface ServiceNameConstant {

    String SERVICE_ALARM = "service-alarm";

    String SERVICE_ANALYZES = "service-analyzes";

    String SERVICE_COLLECTION = "service-collection";

    String SERVICE_CONFIG= "service-config";

    String SERVICE_HANDLE = "service-handle";

    String SERVICE_HUB = "service-hub";

    String SERVICE_INTERACTION = "service-interaction";

    String SERVICE_SUBSCRIPTION = "service-subscription";

    String SERVICE_MINDSPHERE = "service-mindsphere";
}
