package com.siemens.csde.simicas.api.feign.config;

import com.siemens.csde.simicas.api.constant.ServiceNameConstant;
import com.siemens.csde.simicas.api.pojo.qo.config.overall.EditUserLineQo;
import com.siemens.csde.simicas.api.pojo.vo.config.overall.UserLineVo;
import com.siemens.csde.simicas.common.base.BaseResult;
import java.util.List;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

/**
 * 总览业务api
 *
 * @author z0043y5h
 * @version 1.0-SNAPSHOT
 * @date 2020/2/27 1:27
 **/
@FeignClient(
        name = ServiceNameConstant.SERVICE_CONFIG,
        url = "${service.config}",
        fallback = com.siemens.csde.simicas.api.feign.config.OverallServiceApiFallback.class)
@Component("configOverallServiceApi")
public interface OverallServiceApi {

    /**
     * 编辑设置用户关注的产线集合
     *
     * @param editUserLineQo editUserLineQo
     * @return com.siemens.csde.simicas.common.base.BaseResult<java.util.List < com.siemens.csde.simicas.api.pojo.vo.config.overall.UserLineVo>>
     * @author z0043y5h
     * @date 2020/2/27 1:29
     **/
    @PutMapping(value = "/overall/kpiSetting", produces = MediaType.APPLICATION_JSON_VALUE)
    BaseResult<List<UserLineVo>> kpiSetting(@RequestBody EditUserLineQo editUserLineQo);

    /**
     * 对应于首页中的overall ，即当前用户overall 涉及到的产线集合
     *
     * @return com.siemens.csde.simicas.common.base.BaseResult<java.util.List < com.siemens.csde.simicas.api.pojo.vo.config.overall.UserLineVo>>
     * @author z0043y5h
     * @date 2020/2/27 1:30
     **/
    @GetMapping(value = "/overall/listKpiSetting", produces = MediaType.APPLICATION_JSON_VALUE)
    BaseResult<List<UserLineVo>> listKpiSetting();
}
