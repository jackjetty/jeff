package com.siemens.csde.simicas.api.pojo.vo.config.user;

import com.siemens.csde.simicas.api.pojo.dto.TechnicalUserDto;
import com.siemens.csde.simicas.common.base.BaseVo;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

/**
 * 用户统计Vo
 *
 * @author z0043y5h
 * @version 1.0-SNAPSHOT
 * @date 2020/3/30 13:59
 **/
@Getter
@Setter
@Slf4j
public class UserStatisticVo extends BaseVo {

    private static final long serialVersionUID = -5693891896017157416L;

    private List<TechnicalUserDto> resources;

    private int totalElements;

}
