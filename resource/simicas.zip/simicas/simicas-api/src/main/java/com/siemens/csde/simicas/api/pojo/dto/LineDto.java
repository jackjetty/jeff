package com.siemens.csde.simicas.api.pojo.dto;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

/**
 * LineDto
 *
 * @author z004267r
 * @version 1.0-SNAPSHOT
 * @date 3/3/2020 9:50 PM
 **/
@Setter
@Getter
@Builder
public class LineDto {

    private String lineId;

    private String assetId;

    private String lineName;

    private String tenant;

    private Integer index;

}
