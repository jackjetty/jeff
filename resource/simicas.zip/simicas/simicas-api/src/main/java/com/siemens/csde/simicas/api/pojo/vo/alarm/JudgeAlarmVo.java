package com.siemens.csde.simicas.api.pojo.vo.alarm;

import com.siemens.csde.simicas.common.base.BaseVo;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Builder
public class JudgeAlarmVo extends BaseVo {

    private static final long serialVersionUID = -6215570600076147044L;
}