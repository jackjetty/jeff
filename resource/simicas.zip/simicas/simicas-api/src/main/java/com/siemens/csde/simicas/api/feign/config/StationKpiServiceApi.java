package com.siemens.csde.simicas.api.feign.config;

import com.siemens.csde.simicas.api.constant.ServiceNameConstant;
import com.siemens.csde.simicas.api.pojo.qo.config.kpi.KpiQo;
import com.siemens.csde.simicas.api.pojo.to.config.kpi.StationKpiTo;
import com.siemens.csde.simicas.common.base.BaseResult;
import java.util.List;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 *  工站配置kpi api
 * @author Z0040M9S
 * @version 1.0-SNAPSHOT
 * @date 2/12/2020 4:28 PM
 **/
@FeignClient(
        name = ServiceNameConstant.SERVICE_CONFIG,
        url = "${service.config}",
        fallback = StationKpiServiceApiFallback.class)
@Component
public interface StationKpiServiceApi {

    /**
     * 新增工站kpi
     * @author Z0040M9S
     * @param lineId :
     * @param stationId :
     * @param kpiQo :
     * @return : com.siemens.csde.simicas.common.base.BaseResult<java.lang.String>
     * @date   3/2/2020 1:51 PM
     */
    @RequestMapping(value = "/stationKpi/addKpi/line/{lineId}/{stationId}", method = RequestMethod.POST)
    BaseResult<String> addKpi(@PathVariable(value = "lineId") String lineId,
            @PathVariable(value = "stationId") String stationId,
            @RequestBody KpiQo kpiQo);

    /**
     * 修改工站kpi
     * @author Z0040M9S
     * @param lineId :
     * @param stationId :
     * @param kpiId :
     * @param kpiQo :
     * @return : com.siemens.csde.simicas.common.base.BaseResult<java.lang.String>
     * @date   3/2/2020 1:51 PM
     */
    @RequestMapping(value = "/stationKpi/updateKpi/line/{lineId}/station/{stationId}/{kpiId}", method = RequestMethod.PUT)
    BaseResult<String> updateKpi(@PathVariable(value = "lineId") String lineId,
            @PathVariable(value = "stationId") String stationId,
            @PathVariable(value = "kpiId") String kpiId,
            @RequestBody KpiQo kpiQo);

    /**
     * 获取工站kpi list
     * @author Z0040M9S
     * @param lineId :
     * @return : com.siemens.csde.simicas.common.base.BaseResult<java.util.List<com.siemens.csde.simicas.api.pojo.to.config.kpi.StationKpiTo>>
     * @date   3/2/2020 1:51 PM
     */
    @RequestMapping(value = "/stationKpi/listKpi/line/{lineId}", method = RequestMethod.GET)
    BaseResult<List<StationKpiTo>> listKpi( @PathVariable(value = "lineId") String lineId);

    /**
     * 删除工站kpi
     * @author Z0040M9S
     * @param lineId :
     * @param stationId :
     * @param kpiId :
     * @return : com.siemens.csde.simicas.common.base.BaseResult<java.lang.String>
     * @date   3/2/2020 1:51 PM
     */
    @RequestMapping(value = "/stationKpi/deleteKpi/line/{lineId}/station/{stationId}/{kpiId}", method = RequestMethod.DELETE)
    BaseResult<String> deleteKpi(@PathVariable(value = "lineId") String lineId,
            @PathVariable(value = "stationId") String stationId,
            @PathVariable(value = "kpiId") String kpiId);


}