package com.siemens.csde.simicas.api.pojo.vo.config.product;

import com.siemens.csde.simicas.common.base.BaseVo;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

/**
 * ProductVo
 *
 * @author z0043y5h
 * @version 1.0-SNAPSHOT
 * @date 2020/2/22 17:25
 **/
@Slf4j
@Getter
@Setter
@Builder
public class ProductVo extends BaseVo {

    private static final long serialVersionUID = -3824886445837466296L;

    private String id;

    private String productFamily;

    private String productGroup;

    private String productId;

    private String productName;

    private Double ict;
}
