package com.siemens.csde.simicas.api.pojo.to.config.status;

import com.siemens.csde.simicas.common.base.BaseTo;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
/**
 *  产线状态列表传输类
 * @author Z0040M9S
 * @version 1.0-SNAPSHOT
 * @date 2/12/2020 4:28 PM
 **/
@Slf4j
@Getter
@Setter
public class LineStatusTo extends BaseTo {

    private static final long serialVersionUID = -3739674332685570557L;
    private String id;
    private Boolean downtimeCategory;
    private String lineId;
    private String status;
    private String value;
    private String visual;

}