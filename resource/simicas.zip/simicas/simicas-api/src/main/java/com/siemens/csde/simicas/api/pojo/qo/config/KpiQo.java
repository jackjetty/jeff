package com.siemens.csde.simicas.api.pojo.qo.config;

import com.siemens.csde.simicas.api.pojo.qo.config.line.ConfigLineQo.MessageType;
import java.util.List;
import lombok.Getter;
import lombok.Setter;

/**
 * KpiQo
 *
 * @author z004267r
 * @version 1.0-SNAPSHOT
 * @date 4/1/2020 2:58 PM
 **/
@Setter
@Getter
public class KpiQo {

    private String assetId;

    private String lineId;

    private List<MessageType> messageTypes;

}
