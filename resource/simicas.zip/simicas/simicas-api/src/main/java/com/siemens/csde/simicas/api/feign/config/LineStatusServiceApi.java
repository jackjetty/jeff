package com.siemens.csde.simicas.api.feign.config;

import com.siemens.csde.simicas.api.constant.ServiceNameConstant;
import com.siemens.csde.simicas.api.pojo.qo.config.status.LineStatusConfigQo;
import com.siemens.csde.simicas.api.pojo.to.config.status.LineStatusTo;
import com.siemens.csde.simicas.common.base.BaseResult;
import java.util.List;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 *  产线状态配置
 * @author Z0040M9S
 * @version 1.0-SNAPSHOT
 * @date 2/12/2020 4:28 PM
 **/
@FeignClient(
        name = ServiceNameConstant.SERVICE_CONFIG,
        url = "${service.config}",
        fallback = LineStatusServiceApiFallback.class)
@Component
public interface LineStatusServiceApi {

    /**
     * 获取产线status 选项值
     * @author Z0040M9S
     * @param lineId :
     * @return : com.siemens.csde.simicas.common.base.BaseResult<java.util.List<java.lang.String>>
     * @date   2/26/2020 7:37 PM
     */
    @RequestMapping(value = "/lineStatus/listStatusOptions/{lineId}", method = RequestMethod.GET)
    BaseResult<List<String>> listStatusOptions(@PathVariable(value = "lineId") String lineId) ;

    /**
     * 新增产线 status配置
     * @author Z0040M9S
     * @param lineId :
     * @param lineStatusConfigQo :
     * @return : com.siemens.csde.simicas.common.base.BaseResult<java.lang.String>
     * @date   2/26/2020 7:37 PM
     */
    @RequestMapping(value = "/lineStatus/addStatusConfig/line/{lineId}", method = RequestMethod.POST)
    BaseResult<String> addStatusConfig(@PathVariable(value = "lineId") String lineId,
            @RequestBody LineStatusConfigQo lineStatusConfigQo);

    /**
     * 修改产线status配置
     * @author Z0040M9S
     * @param lineId :
     * @param statusId :
     * @param lineStatusConfigQo :
     * @return : com.siemens.csde.simicas.common.base.BaseResult<java.lang.String>
     * @date   2/26/2020 7:37 PM
     */
    @RequestMapping(value = "/lineStatus/updateStatusConfig/line/{lineId}/{statusId}", method = RequestMethod.PUT)
    BaseResult<String> updateStatusConfig(@PathVariable(value = "lineId") String lineId,
            @PathVariable(value = "statusId") String statusId,
            @RequestBody LineStatusConfigQo lineStatusConfigQo);

    /**
     * 获取产线status 配置 list
     * @author Z0040M9S
     * @param lineId :
     * @return : com.siemens.csde.simicas.common.base.BaseResult<java.util.List<com.siemens.csde.simicas.api.pojo.to.config.status.LineStatusTo>>
     * @date   2/26/2020 7:37 PM
     */
    @RequestMapping(value = "/lineStatus/listStatusConfig/line/{lineId}", method = RequestMethod.GET)
    BaseResult<List<LineStatusTo>> listStatusConfig(@PathVariable(value = "lineId") String lineId);

    /**
     * 删除产线status 配置
     * @author Z0040M9S
     * @param lineId :
     * @param statusId :
     * @return : com.siemens.csde.simicas.common.base.BaseResult<java.lang.String>
     * @date   2/26/2020 7:38 PM
     */
    @RequestMapping(value = "/lineStatus/deleteStatusConfig/line/{lineId}/{statusId}", method = RequestMethod.DELETE)
    BaseResult<String> deleteStatusConfig(@PathVariable(value = "lineId") String lineId,
            @PathVariable(value = "statusId") String statusId);

}