package com.siemens.csde.simicas.api.feign.analyzes;

import com.siemens.csde.simicas.api.constant.ServiceNameConstant;
import com.siemens.csde.simicas.api.pojo.qo.analyzes.FavoriteQo;
import com.siemens.csde.simicas.api.pojo.vo.analyzes.FavoriteVo;
import com.siemens.csde.simicas.common.base.BaseResult;
import java.util.List;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

/**
 * 收藏api
 *
 * @author z0043y5h
 * @version 1.0-SNAPSHOT
 * @date 2020/3/23 17:47
 **/
@FeignClient(
        name = ServiceNameConstant.SERVICE_ANALYZES,
        url = "${service.analyzes}",
        fallback = FavoriteServiceApiFallback.class)
@Component
public interface FavoriteServiceApi {

    /**
     * 新增收藏
     *
     * @param favoriteQo favoriteQo
     * @return com.siemens.csde.simicas.common.base.BaseResult
     * @author z0043y5h
     * @date 2020/3/23 18:04
     **/
    @PostMapping(value = "/favorite/addFavorite", produces = MediaType.APPLICATION_JSON_VALUE)
    BaseResult addFavorite(@RequestBody FavoriteQo favoriteQo);

    /**
     * 修改收藏
     *
     * @param favoriteQo favoriteQo
     * @return com.siemens.csde.simicas.common.base.BaseResult
     * @author z0043y5h
     * @date 2020/3/23 18:04
     **/
    @PutMapping(value = "/favorite/updateFavorite/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
    BaseResult updateFavorite(@PathVariable(value = "id") String id, @RequestBody FavoriteQo favoriteQo);

    /**
     * 刪除收藏
     *
     * @param id id
     * @return com.siemens.csde.simicas.common.base.BaseResult
     * @author z0043y5h
     * @date 2020/3/23 18:04
     **/
    @DeleteMapping(value = "/favorite/deleteFavorite/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
    BaseResult deleteFavorite(@PathVariable("id") String id);

    /**
     * v 查詢收藏
     *
     * @return com.siemens.csde.simicas.common.base.BaseResult<java.util.List < com.siemens.csde.simicas.api.pojo.vo.analyzes.FavoriteVo>>
     * @author z0043y5h
     * @date 2020/3/23 18:03
     **/
    @GetMapping(value = "/favorite/listFavorite", produces = MediaType.APPLICATION_JSON_VALUE)
    BaseResult<List<FavoriteVo>> listFavorite();
}
