package com.siemens.csde.simicas.api.pojo.to.handle;

import com.google.gson.annotations.SerializedName;
import com.siemens.csde.simicas.common.base.BaseTo;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

/**
 * 工站指标详情To
 *
 * @author z0043y5h
 * @version 1.0-SNAPSHOT
 * @date 2020/3/27 15:08
 **/
@Slf4j
@Setter
@Getter
public class StationKpiDetailTo extends BaseTo {

    private static final long serialVersionUID = 5787119738421139778L;

    @SerializedName("_time")
    private String time;

    private String kpiName;

    private String value;

    private String unit;

    private String visual;

    private String label;

    private Integer errorCode;
}
