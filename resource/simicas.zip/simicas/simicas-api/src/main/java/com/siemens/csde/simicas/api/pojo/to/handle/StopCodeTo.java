package com.siemens.csde.simicas.api.pojo.to.handle;

import com.google.gson.annotations.SerializedName;
import com.siemens.csde.simicas.common.base.BaseTo;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

/**
 * StopCodeTo
 *
 * @author z004267r
 * @version 1.0-SNAPSHOT
 * @date 3/24/2020 3:26 PM
 **/
@Setter
@Getter
@Builder
public class StopCodeTo extends BaseTo {

    private static final long serialVersionUID = -996974077031548368L;

    @SerializedName(value = "StopCode")
    private String dataValue;



}
