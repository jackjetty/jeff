package com.siemens.csde.simicas.api.pojo.vo.handle.kpi;

import com.google.gson.annotations.SerializedName;
import com.siemens.csde.simicas.common.base.BaseVo;
import lombok.Getter;
import lombok.Setter;

/**
 * CustomKpiVo
 *
 * @author z004267r
 * @version 1.0-SNAPSHOT
 * @date 4/1/2020 4:57 PM
 **/
@Setter
@Getter
public class CustomKpiVo extends BaseVo {

    private String kpiName;
    private String value;
    private String unit;

    @SerializedName(value="_time")
    private String time;

}
