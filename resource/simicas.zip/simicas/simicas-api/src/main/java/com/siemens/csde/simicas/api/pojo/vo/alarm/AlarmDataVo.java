package com.siemens.csde.simicas.api.pojo.vo.alarm;

import com.siemens.csde.simicas.common.base.BaseVo;
import java.util.List;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

/**
 *  ws 交互alarm 信息对象
 * @author Z0040M9S
 * @version 1.0-SNAPSHOT
 * @date 2/12/2020 4:28 PM
 **/
@Getter
@Setter
@Builder
public class AlarmDataVo extends BaseVo {

    private static final long serialVersionUID = -3273692125408666166L;
    public static final String TYPE_ALARM="ALARM";
    public static final String TYPE_NOTICE="NOTICE";
    private String type;
    private String lineId;
    private String lineName;
    private List<Message> data;

    @Getter
    @Setter
    public static class Message {

        private String productId;
        private String productName;
        private String orderId;
        private Detail detail;

    }

    @Getter
    @Setter
    public static class Detail {

        private String value;
        private String rules;
        private boolean highlight;
        private boolean notifyWeb;
        private String messageType;
        private String id;
        private String activeTime;
        private String recoveryTime;
        private String unit;
    }
}