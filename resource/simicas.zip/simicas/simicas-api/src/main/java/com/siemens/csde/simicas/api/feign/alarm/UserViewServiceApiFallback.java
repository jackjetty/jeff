package com.siemens.csde.simicas.api.feign.alarm;


import com.google.gson.Gson;
import com.siemens.csde.simicas.api.constant.ServiceNameConstant;
import com.siemens.csde.simicas.api.pojo.vo.alarm.UsageReportVo;
import com.siemens.csde.simicas.common.base.BaseResult;
import com.siemens.csde.simicas.common.constant.enums.ResultEnum;
import java.util.Date;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

/**
 * UserViewServiceApiFallback 产线、告警统计api的fallback
 *
 * @author z0043y5h
 * @version 1.0-SNAPSHOT
 * @date 2020/2/14 16:17
 **/
@Component
@Slf4j
public class UserViewServiceApiFallback implements UserViewServiceApi {

    @Override
    public BaseResult<UsageReportVo> usagereport(String timeZone, Date from, Date to) {
        log.error(new Gson().toJson(new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_ALARM + " " + ResultEnum.ERROR.getInfo())));
        return new BaseResult<>(ResultEnum.ERROR.getCode(),
                ServiceNameConstant.SERVICE_ALARM + " " + ResultEnum.ERROR.getInfo());
    }
}

