package com.siemens.csde.simicas.api.feign.config;

import com.siemens.csde.simicas.api.constant.ServiceNameConstant;
import com.siemens.csde.simicas.api.pojo.qo.config.tenant.AddTenantQo;
import com.siemens.csde.simicas.api.pojo.vo.config.user.UserStatisticVo;
import com.siemens.csde.simicas.common.base.BaseResult;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

/**
 * 租户api
 *
 * @author z0043y5h
 * @version 1.0-SNAPSHOT
 * @date 2020/3/20 18:06
 **/
@FeignClient(
        name = ServiceNameConstant.SERVICE_CONFIG,
        url = "${service.config}",
        fallback = TenantServiceApiFallBack.class)
@Component
public interface TenantServiceApi {

    /**
     * 新增tenant
     *
     * @param addTenantQo addTenantQo
     * @return com.siemens.csde.simicas.common.base.BaseResult
     * @author z0043y5h
     * @date 2020/3/21 23:13
     **/
    @PostMapping(value = "/tenant/addTenant", produces = MediaType.APPLICATION_JSON_VALUE)
    BaseResult addTenant(@RequestBody AddTenantQo addTenantQo);

    /**
     * 删除tenant
     *
     * @param tenant tenant
     * @return com.siemens.csde.simicas.common.base.BaseResult
     * @author z0043y5h
     * @date 2020/3/21 23:14
     **/
    @DeleteMapping(value = "/tenant/deleteTenant/{tenant}", produces = MediaType.APPLICATION_JSON_VALUE)
    BaseResult deleteTenant(@PathVariable String tenant);

    /**
     * 获取指定tenant下有macb权限的用户
     *
     * @param tenant tenant
     * @return com.siemens.csde.simicas.common.base.BaseResult<com.siemens.csde.simicas.api.pojo.vo.config.user.UserStatisticVo>
     * @author z0043y5h
     * @date 2020/3/21 23:21
     **/
    @GetMapping(value = "/tenant/listUsers/{tenant}", produces = MediaType.APPLICATION_JSON_VALUE)
    BaseResult<UserStatisticVo> listUsers(@PathVariable(value = "tenant") String tenant);

    /**
     * 获取指定tenant下有macb权限的用户
     *
     * @param authorization techToken
     * @param tenant        指定查询的tenant
     * @param user          指定查询的user
     * @return com.siemens.csde.simicas.common.base.BaseResult<java.lang.String>
     * @author z0043y5h
     * @date 2020/3/21 23:24
     **/
    @GetMapping(value = "/tenant/validation", produces = MediaType.APPLICATION_JSON_VALUE)
    BaseResult<String> validation(@RequestParam(value = "Authorization") String authorization,
            @RequestParam(value = "tenant") String tenant,
            @RequestParam(value = "user") String user);
}
