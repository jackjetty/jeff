package com.siemens.csde.simicas.api.pojo.vo.config.line;

import com.siemens.csde.simicas.common.base.BaseVo;
import lombok.Getter;
import lombok.Setter;

/**
 * KpiVariableVo
 *
 * @author z004267r
 * @version 1.0-SNAPSHOT
 * @date 4/9/2020 9:59 PM
 **/
@Getter
@Setter
public class KpiVariableVo extends BaseVo {

    private static final long serialVersionUID = 9029762736953797922L;
    private String name;
    private String dataType;
    private String ranges;

}
