package com.siemens.csde.simicas.api.pojo.vo.alarm;

import com.siemens.csde.simicas.api.pojo.to.userview.LineReportTo;
import com.siemens.csde.simicas.api.pojo.to.userview.NoticeStatisticTo;
import com.siemens.csde.simicas.common.base.BaseVo;
import java.util.List;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UsageReportVo extends BaseVo {

    private static final long serialVersionUID = -739319845990746427L;

    private double lineNum;

    private NoticeStatisticTo notificationData;

    private List<LineReportTo> lineDatas;

}
