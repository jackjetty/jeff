package com.siemens.csde.simicas.api.feign.subscription;

import com.siemens.csde.simicas.api.constant.ServiceNameConstant;
import com.siemens.csde.simicas.common.base.BaseResult;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

/**
 * PublishJobServiceApi 推送任务api
 *
 * @author z0043y5h
 * @version 1.0-SNAPSHOT
 * @date 2020/2/19 13:17
 **/
@FeignClient(
        name = ServiceNameConstant.SERVICE_SUBSCRIPTION,
        url = "${service.subscription}",
        fallback = PublishJobServiceApiFallback.class)
@Component
public interface PublishJobServiceApi {

    /**
     * 从处理中心拉去队列数据并推送至客户端
     *
     * @param subtype subtype
     * @return BaseResult<String>
     * @author z0043y5h
     * @date 2020/2/19 13:17
     **/
    @PostMapping(value = "/publishjob/publish/subtype/{subtype}", produces = MediaType.APPLICATION_JSON_VALUE)
    BaseResult<String> publish(@PathVariable("subtype") String subtype);
}
