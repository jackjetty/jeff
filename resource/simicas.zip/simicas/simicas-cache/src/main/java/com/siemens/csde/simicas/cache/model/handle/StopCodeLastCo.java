package com.siemens.csde.simicas.cache.model.handle;

import java.util.Date;
import lombok.Getter;
import lombok.Setter;

/**
 * OutPutViewCo
 *
 * @author z004267r
 * @version 1.0-SNAPSHOT
 * @date 3/25/2020 11:09 AM
 **/
@Setter
@Getter
public class StopCodeLastCo {

    private String id;

    private String lineId;

    private String stationId;

    private String dataValue;

    private Date dataTime;

    private Date startTime;

    private Date endTime;

}
