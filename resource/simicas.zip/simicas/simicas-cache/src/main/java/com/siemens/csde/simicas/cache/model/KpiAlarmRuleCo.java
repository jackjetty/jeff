package com.siemens.csde.simicas.cache.model;

import java.io.Serializable;
import lombok.Getter;
import lombok.Setter;
/**
 *  kpi alarm rule缓存对象
 * @author Z0040M9S
 * @version 1.0-SNAPSHOT
 * @date 2/12/2020 4:28 PM
 **/
@Setter
@Getter
public class KpiAlarmRuleCo implements Serializable {

    private static final long serialVersionUID = -6953913291739369144L;

    private String id;
    private String alarmLevel;
    private String expression;
    private Boolean highlight;
    private Boolean notifyEmail;
    private Boolean notifyWeb;
    private Boolean notifySms;
    private String kpi;
    private String tenant;
    private String lineId;

}