package com.siemens.csde.simicas.cache.component;

import com.siemens.csde.simicas.cache.model.TenantCo;
import com.siemens.csde.simicas.jpa.constant.DBConstant;
import com.siemens.csde.simicas.jpa.entity.SysTenantEntity;
import com.siemens.csde.simicas.jpa.repository.SysTenantRepository;
import java.util.Objects;
import java.util.concurrent.TimeUnit;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Component;
/**
 * tenant 信息缓存中间组件
 * @author Z0040M9S
 * @version 1.0-SNAPSHOT
 * @date 2/12/2020 4:28 PM
 **/
@Component
@Slf4j
public class TenantMediator{

    public static final String KEY_SIMICAS_TENANT="simicas:tenant:%s";

    @Autowired
    private RedisTemplate redisTemplate;

    @Autowired
    private SysTenantRepository sysTenantRepository;

    /**
     * 获取tenant 信息
     * @author Z0040M9S
     * @param tenant :
     * @return : com.siemens.csde.simicas.cache.model.TenantCo
     * @date   3/12/2020 11:39 AM
     */
    public TenantCo getTenant(String tenant){

        String tenantKey=String.format(KEY_SIMICAS_TENANT,tenant);
        TenantCo tenantCo = (TenantCo) redisTemplate.opsForValue().get(tenantKey);
        if(Objects.nonNull(tenantCo)){
            return tenantCo;
        }
        SysTenantEntity condition;
        condition = new SysTenantEntity();
        condition.setId(tenant);
        condition.setStatus(DBConstant.DB_STATUS_VALID);
        SysTenantEntity sysTenantEntity = sysTenantRepository.findOne(Example.of(condition)).orElse(null);
        if(Objects.isNull(sysTenantEntity)){
            return null;
        }
        tenantCo=new TenantCo();
        tenantCo.setId(sysTenantEntity.getId());
        tenantCo.setClientId(sysTenantEntity.getClientId());
        tenantCo.setSecret(sysTenantEntity.getSecret());
        tenantCo.setToken(sysTenantEntity.getToken());
        tenantCo.setParentTenant(sysTenantEntity.getParentTenant());
        redisTemplate.opsForValue().set(tenantKey, tenantCo, 4L, TimeUnit.HOURS);
        return tenantCo;

    }

    public void deleteTenant(String tenant){
        String productKey=String.format(KEY_SIMICAS_TENANT,tenant);
        if(redisTemplate.hasKey(productKey)){
            redisTemplate.delete(productKey);
        }
    }

}