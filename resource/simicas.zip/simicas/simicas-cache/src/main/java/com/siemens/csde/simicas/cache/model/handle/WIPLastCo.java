package com.siemens.csde.simicas.cache.model.handle;

import java.util.Date;
import lombok.Getter;
import lombok.Setter;

/**
 * OutPutViewCo
 *
 * @author z004267r
 * @version 1.0-SNAPSHOT
 * @date 3/25/2020 11:09 AM
 **/
@Setter
@Getter
public class WIPLastCo {

    private String id;

    private String lineId;

    private String stationId;

    private Date dataTime;

    private Integer dataValue;

    private String productId;

    private String orderId;

    private String batchId;

}
