package com.siemens.csde.simicas.cache.component;

import com.siemens.csde.simicas.cache.model.ProductCo;
import com.siemens.csde.simicas.jpa.constant.DBConstant;
import com.siemens.csde.simicas.jpa.entity.CfgProductEntity;
import com.siemens.csde.simicas.jpa.repository.CfgProductRepository;
import java.util.Collections;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.MapUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Component;
/**
 * product 信息缓存中间组件
 * @author Z0040M9S
 * @version 1.0-SNAPSHOT
 * @date 2/12/2020 4:28 PM
 **/
@Component
@Slf4j
public class ProductMediator{

    private static final String KEY_SIMICAS_PRODUCT="simicas:%s:product:%s";

    private static final String KEY_SIMICAS_PRODUCT_MAP="simicas:%s:productMap";

    @Autowired
    private RedisTemplate redisTemplate;

    @Autowired
    private CfgProductRepository cfgProductRepository;

    /**
     * 获取产品信息
     * @author Z0040M9S
     * @param tenant :
     * @param productId :
     * @return : com.siemens.csde.simicas.cache.model.ProductCo
     * @date   3/12/2020 11:38 AM
     */
    public ProductCo getProduct(String tenant,String productId){

        String productKey=String.format(KEY_SIMICAS_PRODUCT,tenant,productId);
        ProductCo productCo = (ProductCo) redisTemplate.opsForValue().get(productKey);
        if(Objects.nonNull(productCo)){
            return productCo;
        }
        CfgProductEntity condition;
        condition = new CfgProductEntity();
        condition.setProductId(productId);
        condition.setTenantId(tenant);
        condition.setStatus(DBConstant.DB_STATUS_VALID);
        CfgProductEntity cfgProductEntity = Optional.ofNullable(cfgProductRepository.findAll(Example.of(condition)))
                .orElseGet(Collections::emptyList).stream().findFirst().orElse(null);
        if(Objects.isNull(cfgProductEntity)){
            return null;
        }
        productCo=new ProductCo();
        productCo.setTenantId(cfgProductEntity.getTenantId());
        productCo.setProductId(cfgProductEntity.getProductId());
        productCo.setProductName(cfgProductEntity.getProductName());
        productCo.setProductFamily(cfgProductEntity.getProductFamily());
        productCo.setProductGroup(cfgProductEntity.getProductGroup());
        productCo.setIct(cfgProductEntity.getIct());
        redisTemplate.opsForValue().set(productKey, productCo, 4L, TimeUnit.HOURS);
        return productCo;

    }

    /**
     * 删除产品信息
     * @author Z0040M9S
     * @param tenant :
     * @param productId :
     * @return : void
     * @date   3/12/2020 11:38 AM
     */
    public void deleteProduct(String tenant,String productId){

        String productKey=String.format(KEY_SIMICAS_PRODUCT,tenant,productId);
        if(redisTemplate.hasKey(productKey)){
            redisTemplate.delete(productKey);
        }
        String productMapKey=String.format(KEY_SIMICAS_PRODUCT_MAP,tenant);
        if(redisTemplate.hasKey(productMapKey)){
            redisTemplate.delete(productMapKey);
        }

    }


    /**
     * 获取产品 id-name map
     * @author Z0040M9S
     * @param tenant :
     * @return : java.util.Map<java.lang.String,java.lang.String>
     * @date   3/12/2020 11:38 AM
     */
    public Map<String,String> getProductMap(String tenant){

        String productMapKey=String.format(KEY_SIMICAS_PRODUCT_MAP,tenant);
        Map<String,String> productItemMap= redisTemplate.opsForHash().entries(productMapKey);
        if(MapUtils.isNotEmpty(productItemMap)){
            return productItemMap;
        }
        CfgProductEntity condition;
        condition = new CfgProductEntity();
        condition.setTenantId(tenant);
        condition.setStatus(DBConstant.DB_STATUS_VALID);
        productItemMap=Optional.ofNullable(cfgProductRepository.findAll(Example.of(condition)))
                .orElseGet(Collections::emptyList).stream().collect(Collectors.toMap(CfgProductEntity::getProductId, CfgProductEntity::getProductName, (v1, v2) -> v2));
        redisTemplate.opsForHash().putAll(productMapKey,productItemMap);
        redisTemplate.expire(productMapKey, 4L, TimeUnit.HOURS);
        return productItemMap;

    }






}