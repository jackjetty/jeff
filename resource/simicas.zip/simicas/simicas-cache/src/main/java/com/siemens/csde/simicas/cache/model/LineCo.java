package com.siemens.csde.simicas.cache.model;

import java.io.Serializable;
import lombok.Getter;
import lombok.Setter;
/**
 *  line 缓存对象
 * @author Z0040M9S
 * @version 1.0-SNAPSHOT
 * @date 2/12/2020 4:28 PM
 **/
@Setter
@Getter
public class LineCo implements Serializable {

    private static final long serialVersionUID = -1282150304122086944L;

    private String id;
    private String name;
    private String assetId;
    private String workstationModel;
    private String tenant;
    private Integer index;
}