package com.siemens.csde.simicas.cache.model;

import java.io.Serializable;
import lombok.Getter;
import lombok.Setter;
/**
 *  tenant 缓存对象
 * @author Z0040M9S
 * @version 1.0-SNAPSHOT
 * @date 2/12/2020 4:28 PM
 **/
@Setter
@Getter
public class TenantCo implements Serializable {

    private static final long serialVersionUID = 7788882171082346319L;
    private String id;
    private String clientId;
    private String secret;
    private String parentTenant;
    private String token;
}