package com.siemens.csde.simicas.cache.model.handle;

import java.util.Date;
import lombok.Getter;
import lombok.Setter;

/**
 * OutPutLastCo
 *
 * @author z004267r
 * @version 1.0-SNAPSHOT
 * @date 3/25/2020 11:09 AM
 **/
@Setter
@Getter
public class OutPutLastCo {

    private String id;

    private String lineId;

    private String stationId;

    private Integer dataValue;

    private Integer total;

    private String productName;

    private Date dataTime;

    private Date startTime;

    private Date endTime;

    private Date firstTime;

    private String productId;

    private String orderId;

    private String batchId;

}
