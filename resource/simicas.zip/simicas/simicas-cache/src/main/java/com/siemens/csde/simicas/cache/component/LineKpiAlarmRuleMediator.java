package com.siemens.csde.simicas.cache.component;

import com.siemens.csde.simicas.cache.model.KpiAlarmRuleCo;
import com.siemens.csde.simicas.jpa.constant.DBConstant;
import com.siemens.csde.simicas.jpa.entity.AlarmCfgRuleEntity;
import com.siemens.csde.simicas.jpa.repository.AlarmCfgRuleRepository;
import com.siemens.csde.simicas.jpa.repository.CfgKpiRepository;
import com.siemens.csde.simicas.jpa.repository.CfgKpiVariableRepository;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Component;

/**
 * line kpi alarm rule 信息缓存中间组件
 * @author Z0040M9S
 * @version 1.0-SNAPSHOT
 * @date 2/12/2020 4:28 PM
 **/
@Slf4j
@Component
public class LineKpiAlarmRuleMediator{

    private static final String KEY_SIMICAS_LINE_KPI_ALARM_RULES="simicas:%s:line:%s:kpi:%s:alarm:rules";


    @Autowired
    private RedisTemplate redisTemplate;

    @Autowired
    private CfgKpiRepository cfgKpiRepository;

    @Autowired
    private CfgKpiVariableRepository cfgKpiVariableRepository;

    @Autowired
    private AlarmCfgRuleRepository alarmCfgRuleRepository;

    /**
     * 获取产线kpi alarm rules
     * @author Z0040M9S
     * @param tenant :
     * @param lineId :
     * @param kpiName :
     * @return : com.siemens.csde.simicas.cache.model.KpiCo
     * @date   3/12/2020 11:36 AM
     */
    public List<KpiAlarmRuleCo> getAlarmRules(String tenant,String lineId,String kpiName){

        String alarmRulesKey=String.format(KEY_SIMICAS_LINE_KPI_ALARM_RULES,tenant,lineId,kpiName);
        List<KpiAlarmRuleCo> kpiAlarmRuleCos = (List<KpiAlarmRuleCo>) redisTemplate.opsForValue().get(alarmRulesKey);
        if(Objects.nonNull(kpiAlarmRuleCos)){
            return kpiAlarmRuleCos;
        }
        List<AlarmCfgRuleEntity> alarmRuleEntities = alarmCfgRuleRepository.findByLineIdAndKpiAndStatus(lineId, kpiName,DBConstant.DB_STATUS_VALID);
        kpiAlarmRuleCos= Optional.ofNullable(alarmRuleEntities)
                .orElseGet(Collections::emptyList).stream().map(alarmCfgRuleEntity -> {
                    KpiAlarmRuleCo kpiAlarmRuleCo=new KpiAlarmRuleCo();
                    kpiAlarmRuleCo.setId(alarmCfgRuleEntity.getId());
                    kpiAlarmRuleCo.setAlarmLevel(alarmCfgRuleEntity.getAlarmLevel());
                    kpiAlarmRuleCo.setExpression(alarmCfgRuleEntity.getExpression());
                    kpiAlarmRuleCo.setHighlight(alarmCfgRuleEntity.getHighlight());
                    kpiAlarmRuleCo.setNotifyEmail(alarmCfgRuleEntity.getNotifyEmail());
                    kpiAlarmRuleCo.setNotifyWeb(alarmCfgRuleEntity.getNotifyWeb());
                    kpiAlarmRuleCo.setNotifySms(alarmCfgRuleEntity.getNotifySms());
                    kpiAlarmRuleCo.setKpi(alarmCfgRuleEntity.getKpi());
                    kpiAlarmRuleCo.setTenant(alarmCfgRuleEntity.getTenant());
                    kpiAlarmRuleCo.setLineId(alarmCfgRuleEntity.getLineId());
                    return kpiAlarmRuleCo;
                }).collect(Collectors.toList());



        redisTemplate.opsForValue().set(alarmRulesKey, kpiAlarmRuleCos, 4L, TimeUnit.HOURS);
        return kpiAlarmRuleCos;

    }
    /**
     * 删除产线kpi alarm rules
     * @author Z0040M9S
     * @param tenant :
     * @param lineId :
     * @param kpiName :
     * @return : void
     * @date   3/12/2020 11:36 AM
     */
    public void deleteAlarmRules(String tenant,String lineId,String kpiName){

        String alarmRulesKey=String.format(KEY_SIMICAS_LINE_KPI_ALARM_RULES,tenant,lineId,kpiName);
        if(redisTemplate.hasKey(alarmRulesKey)){
            redisTemplate.delete(alarmRulesKey);
        }

    }






}