package com.siemens.csde.simicas.cache.model;

import java.io.Serializable;
import lombok.Getter;
import lombok.Setter;
/**
 *  status 缓存对象
 * @author Z0040M9S
 * @version 1.0-SNAPSHOT
 * @date 2/12/2020 4:28 PM
 **/
@Setter
@Getter
public class StatusCo implements Serializable {

    private static final long serialVersionUID = -3291755965751642444L;
    private String id;
    private boolean downtimeCategory;
    private String label;
    private String visual;
    private String status;


}