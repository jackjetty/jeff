package com.siemens.csde.simicas.cache.component;

import com.siemens.csde.simicas.cache.model.StatusCo;
import com.siemens.csde.simicas.jpa.constant.DBConstant;
import com.siemens.csde.simicas.jpa.entity.CfgLineStatusEntity;
import com.siemens.csde.simicas.jpa.repository.CfgLineStatusRepository;
import java.util.Collections;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.MapUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Component;

/**
 * line status 信息缓存中间组件
 * @author Z0040M9S
 * @version 1.0-SNAPSHOT
 * @date 2/12/2020 4:28 PM
 **/
@Slf4j
@Component
public class LineStatusMediator{

    private static final String KEY_SIMICAS_LINE_STATUS="simicas:%s:line:%s:status:%s";

    private static final String KEY_SIMICAS_LINE_STATUS_MAP="simicas:%s:line:%s:statusMap";

    @Autowired
    private RedisTemplate redisTemplate;

    @Autowired
    private CfgLineStatusRepository cfgLineStatusRepository;

    /**
     * 获取产线status
     * @author Z0040M9S
     * @param tenant :
     * @param lineId :
     * @param status :
     * @return : com.siemens.csde.simicas.cache.model.StatusCo
     * @date   3/12/2020 11:36 AM
     */
    public StatusCo getStatus(String tenant,String lineId,String status){

        String statusKey=String.format(KEY_SIMICAS_LINE_STATUS,tenant,lineId,status);
        StatusCo statusCo = (StatusCo) redisTemplate.opsForValue().get(statusKey);
        if(Objects.nonNull(statusCo)){
            return statusCo;
        }

        CfgLineStatusEntity condition;
        condition = new CfgLineStatusEntity();
        condition.setLineId(lineId);
        condition.setStatus(DBConstant.DB_STATUS_VALID);
        condition.setLineStatus(status);
        CfgLineStatusEntity cfgLineStatusEntity= Optional.ofNullable(cfgLineStatusRepository.findAll(Example.of(condition)))
                .orElseGet(Collections::emptyList).stream().findFirst().orElse(null);

        if(Objects.isNull(cfgLineStatusEntity)){
            return null;
        }
        statusCo=new StatusCo();
        statusCo.setId(cfgLineStatusEntity.getId());
        statusCo.setDowntimeCategory(Optional.ofNullable(cfgLineStatusEntity.getDowntimeCategory()).orElse(false));
        statusCo.setLabel(cfgLineStatusEntity.getLabel());
        statusCo.setVisual(cfgLineStatusEntity.getVisual());
        statusCo.setStatus(cfgLineStatusEntity.getLineStatus());
        redisTemplate.opsForValue().set(statusKey, statusCo, 4L, TimeUnit.HOURS);
        return statusCo;

    }
    /**
     * 删除产线status
     * @author Z0040M9S
     * @param tenant :
     * @param lineId :
     * @param status :
     * @return : void
     * @date   3/12/2020 11:36 AM
     */
    public void deleteStatus(String tenant,String lineId,String status){

        String statusKey=String.format(KEY_SIMICAS_LINE_STATUS,tenant,lineId,status);
        if(redisTemplate.hasKey(statusKey)){
            redisTemplate.delete(statusKey);
        }
        String statusMapKey=String.format(KEY_SIMICAS_LINE_STATUS_MAP,tenant,lineId);
        if(redisTemplate.hasKey(statusMapKey)){
            redisTemplate.delete(statusMapKey);
        }

    }



    /**
     * 获取产线status-downtimecategory map
     * @author Z0040M9S
     * @param tenant :
     * @param lineId :
     * @return : java.util.Map<java.lang.String,java.lang.Boolean>
     * @date   3/12/2020 11:36 AM
     */
    public Map<String,Boolean> getStatusMap(String tenant,String lineId){

        String statusMapKey=String.format(KEY_SIMICAS_LINE_STATUS_MAP,tenant,lineId);
        Map<String,Boolean> statusItemMap= redisTemplate.opsForHash().entries(statusMapKey);
        if(MapUtils.isNotEmpty(statusItemMap)){
            return statusItemMap;
        }
        CfgLineStatusEntity condition;
        condition = new CfgLineStatusEntity();
        condition.setLineId(lineId);
        condition.setStatus(DBConstant.DB_STATUS_VALID);
        statusItemMap=Optional.ofNullable(cfgLineStatusRepository.findAll(Example.of(condition)))
                .orElseGet(Collections::emptyList).stream().collect(
                        Collectors.toMap(CfgLineStatusEntity::getLineStatus, cfgLineStatusEntity -> {return Optional.ofNullable(cfgLineStatusEntity.getDowntimeCategory()).orElse(false);
                        }, (v1, v2) -> v2));
        redisTemplate.opsForHash().putAll(statusMapKey,statusItemMap);
        redisTemplate.expire(statusMapKey, 4L, TimeUnit.HOURS);
        return statusItemMap;

    }

}