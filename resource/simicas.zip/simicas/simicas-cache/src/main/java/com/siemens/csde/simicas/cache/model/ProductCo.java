package com.siemens.csde.simicas.cache.model;

import java.io.Serializable;
import lombok.Getter;
import lombok.Setter;
/**
 *  product 缓存对象
 * @author Z0040M9S
 * @version 1.0-SNAPSHOT
 * @date 2/12/2020 4:28 PM
 **/
@Setter
@Getter
public class ProductCo implements Serializable {

    private static final long serialVersionUID = -6873543516311091137L;
    private String tenantId;
    private String productId;
    private String productName;
    private String productFamily;
    private String productGroup;
    private Double ict;

}