package com.siemens.csde.simicas.cache.component;

import com.google.common.collect.Lists;
import com.siemens.csde.simicas.cache.model.KpiCo;
import com.siemens.csde.simicas.cache.model.KpiCo.InputVariableCo;
import com.siemens.csde.simicas.cache.model.KpiCo.KpiVariableCo;
import com.siemens.csde.simicas.common.constant.enums.EntityEnum;
import com.siemens.csde.simicas.jpa.component.NativeQueryManager;
import com.siemens.csde.simicas.jpa.constant.DBConstant;
import com.siemens.csde.simicas.jpa.entity.CfgDataInputEntity;
import com.siemens.csde.simicas.jpa.entity.CfgKpiEntity;
import com.siemens.csde.simicas.jpa.entity.CfgKpiVariableEntity;
import com.siemens.csde.simicas.jpa.repository.CfgDataInputRepository;
import com.siemens.csde.simicas.jpa.repository.CfgKpiRepository;
import com.siemens.csde.simicas.jpa.repository.CfgKpiVariableRepository;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Component;

/**
 * line kpi 信息缓存中间组件
 * @author Z0040M9S
 * @version 1.0-SNAPSHOT
 * @date 2/12/2020 4:28 PM
 **/
@Slf4j
@Component
public class LineKpiMediator{

    private static final String KEY_SIMICAS_LINE_KPI="simicas:%s:line:%s:kpi:%s";

    private static final String KEY_SIMICAS_LINE_KPI_CHILDREN="simicas:%s:line:%s:kpi:%s:children";

    private static final String KEY_SIMICAS_LINE_KPI_MAP="simicas:%s:line:%s:kpiMap";

    @Autowired
    private RedisTemplate redisTemplate;

    @Autowired
    private CfgKpiRepository cfgKpiRepository;

    @Autowired
    private CfgKpiVariableRepository cfgKpiVariableRepository;

    @Autowired
    private CfgDataInputRepository cfgDataInputRepository;

    @Autowired
    private NativeQueryManager nativeQueryManager;

    /**
     * 获取产线kpi信息
     * @author Z0040M9S
     * @param tenant :
     * @param lineId :
     * @param kpiName :
     * @return : com.siemens.csde.simicas.cache.model.KpiCo
     * @date   3/12/2020 11:36 AM
     */
    public KpiCo getKpi(String tenant,String lineId,String kpiName){

        String kpiKey=String.format(KEY_SIMICAS_LINE_KPI,tenant,lineId,kpiName);
        KpiCo kpiCo = (KpiCo) redisTemplate.opsForValue().get(kpiKey);
        if(Objects.nonNull(kpiCo)){
            return kpiCo;
        }
        CfgKpiEntity condition;
        condition = new CfgKpiEntity();
        condition.setName(kpiName);
        condition.setLineId(lineId);
        condition.setStation(EntityEnum.LINE.getEntityType());
        condition.setStatus(DBConstant.DB_STATUS_VALID);
        CfgKpiEntity cfgKpiEntity = Optional.ofNullable(cfgKpiRepository.findAll(Example.of(condition)))
                .orElseGet(Collections::emptyList).stream().findFirst().orElse(null);
        if(Objects.isNull(cfgKpiEntity)){
            return null;
        }
        kpiCo=new KpiCo();
        kpiCo.setId(cfgKpiEntity.getId());
        kpiCo.setName(cfgKpiEntity.getName());
        kpiCo.setPId(cfgKpiEntity.getPId());
        kpiCo.setType(cfgKpiEntity.getType());
        kpiCo.setLevel(cfgKpiEntity.getLevel());
        kpiCo.setFormula(cfgKpiEntity.getFormula());
        kpiCo.setUnit(cfgKpiEntity.getUnit());
        kpiCo.setLineId(cfgKpiEntity.getLineId());
        kpiCo.setStation(cfgKpiEntity.getStation());
        kpiCo.setDescription(cfgKpiEntity.getDescription());

        CfgKpiVariableEntity cfgKpiVariableCondition;
        cfgKpiVariableCondition = new CfgKpiVariableEntity();
        cfgKpiVariableCondition.setKpiId(cfgKpiEntity.getId());
        cfgKpiVariableCondition.setStatus(DBConstant.DB_STATUS_VALID);
        List<KpiVariableCo> kpiVariableCos=Optional.ofNullable(cfgKpiVariableRepository.findAll(Example.of(cfgKpiVariableCondition)))
                .orElseGet(Collections::emptyList).stream().map(cfgKpiVariableEntity -> {
            KpiVariableCo kpiVariableCo=new KpiVariableCo();
            kpiVariableCo.setId(cfgKpiVariableEntity.getId());
            kpiVariableCo.setName(cfgKpiVariableEntity.getName());
            kpiVariableCo.setDataType(cfgKpiVariableEntity.getDataType());
            kpiVariableCo.setDefaultValue(cfgKpiVariableEntity.getDefaultValue());
            kpiVariableCo.setLength(cfgKpiVariableEntity.getLength());
            kpiVariableCo.setUnit(cfgKpiVariableEntity.getUnit());
            kpiVariableCo.setFormula(cfgKpiVariableEntity.getFormula());
            return kpiVariableCo;
        }).collect(Collectors.toList());
        kpiCo.setKpiVariableCos(kpiVariableCos);

        CfgDataInputEntity cfgDataInputCondition;
        cfgDataInputCondition=new CfgDataInputEntity();
        cfgDataInputCondition.setKpiId(cfgKpiEntity.getId());
        List<InputVariableCo> inputVariableCos=Optional.ofNullable(cfgDataInputRepository.findAll(Example.of(cfgDataInputCondition)))
                .orElseGet(Collections::emptyList).stream().map(cfgDataInputEntity -> {
                    InputVariableCo inputVariableCo=new InputVariableCo();
                    inputVariableCo.setName(cfgDataInputEntity.getName());
                    inputVariableCo.setDataKey(cfgDataInputEntity.getDataKey());
                    inputVariableCo.setDataType(cfgDataInputEntity.getDataType());
                    return inputVariableCo;
                }).collect(Collectors.toList());
        kpiCo.setInputVariableCos(inputVariableCos);

        redisTemplate.opsForValue().set(kpiKey, kpiCo, 4L, TimeUnit.HOURS);
        return kpiCo;

    }

    public List<KpiCo> getChildrenKpi(String tenant,String lineId,String kpiName){

        String kpiKey=String.format(KEY_SIMICAS_LINE_KPI_CHILDREN,tenant,lineId,kpiName);
        List<KpiCo> kpiCoList = (List<KpiCo>) redisTemplate.opsForValue().get(kpiKey);
        if(Objects.nonNull(kpiCoList)){
            return kpiCoList;
        }
        Map<String,Object> params = new HashMap<>();
        params.put("pid",getKpi(tenant,lineId,kpiName).getId());
        params.put("lineId",lineId);
        params.put("station",EntityEnum.LINE.getEntityType());
        List<CfgKpiEntity> cfgKpiEntitys = nativeQueryManager.queryByConditionNQ(CfgKpiEntity.class,cfgKpiRepository.NSQL_ALL_KPI_BY_PID,params);
        if(cfgKpiEntitys.size()==0){
            return new ArrayList<KpiCo>();
        }
        kpiCoList= Lists.newArrayList();
        for (CfgKpiEntity cfgKpiEntity:cfgKpiEntitys) {
            KpiCo kpiCo=new KpiCo();
            kpiCo.setId(cfgKpiEntity.getId());
            kpiCo.setName(cfgKpiEntity.getName());
            kpiCo.setPId(cfgKpiEntity.getPId());
            kpiCo.setType(cfgKpiEntity.getType());
            kpiCo.setLevel(cfgKpiEntity.getLevel());
            kpiCo.setFormula(cfgKpiEntity.getFormula());
            kpiCo.setUnit(cfgKpiEntity.getUnit());
            kpiCo.setLineId(cfgKpiEntity.getLineId());
            kpiCo.setStation(cfgKpiEntity.getStation());
            kpiCo.setDescription(cfgKpiEntity.getDescription());

            CfgKpiVariableEntity cfgKpiVariableCondition = new CfgKpiVariableEntity();
            cfgKpiVariableCondition.setKpiId(cfgKpiEntity.getId());
            cfgKpiVariableCondition.setStatus(DBConstant.DB_STATUS_VALID);
            List<KpiVariableCo> kpiVariableCos=Optional.ofNullable(cfgKpiVariableRepository.findAll(Example.of(cfgKpiVariableCondition)))
                    .orElseGet(Collections::emptyList).stream().map(cfgKpiVariableEntity -> {
                        KpiVariableCo kpiVariableCo=new KpiVariableCo();
                        kpiVariableCo.setId(cfgKpiVariableEntity.getId());
                        kpiVariableCo.setName(cfgKpiVariableEntity.getName());
                        kpiVariableCo.setDataType(cfgKpiVariableEntity.getDataType());
                        kpiVariableCo.setDefaultValue(cfgKpiVariableEntity.getDefaultValue());
                        kpiVariableCo.setLength(cfgKpiVariableEntity.getLength());
                        kpiVariableCo.setUnit(cfgKpiVariableEntity.getUnit());
                        return kpiVariableCo;
                    }).collect(Collectors.toList());
            kpiCo.setKpiVariableCos(kpiVariableCos);

            CfgDataInputEntity cfgDataInputCondition = new CfgDataInputEntity();
            cfgDataInputCondition.setKpiId(cfgKpiEntity.getId());
            List<InputVariableCo> inputVariableCos=Optional.ofNullable(cfgDataInputRepository.findAll(Example.of(cfgDataInputCondition)))
                    .orElseGet(Collections::emptyList).stream().map(cfgDataInputEntity -> {
                        InputVariableCo inputVariableCo=new InputVariableCo();
                        inputVariableCo.setName(cfgDataInputEntity.getName());
                        inputVariableCo.setDataKey(cfgDataInputEntity.getDataKey());
                        inputVariableCo.setDataType(cfgDataInputEntity.getDataType());
                        return inputVariableCo;
                    }).collect(Collectors.toList());
            kpiCo.setInputVariableCos(inputVariableCos);
            kpiCoList.add(kpiCo);
        }
        redisTemplate.opsForValue().set(kpiKey, kpiCoList, 4L, TimeUnit.HOURS);
        return kpiCoList;

    }
    /**
     * 删除产线kpi
     * @author Z0040M9S
     * @param tenant :
     * @param lineId :
     * @param kpiName :
     * @return : void
     * @date   3/12/2020 11:36 AM
     */
    public void deleteKpi(String tenant,String lineId,String kpiName){

        String kpiKey=String.format(KEY_SIMICAS_LINE_KPI,tenant,lineId,kpiName);
        if(redisTemplate.hasKey(kpiKey)){
            redisTemplate.delete(kpiKey);
        }
        String kpiMapKey=String.format(KEY_SIMICAS_LINE_KPI_MAP,tenant,lineId);
        if(redisTemplate.hasKey(kpiMapKey)){
            redisTemplate.delete(kpiMapKey);
        }

    }

    /**
     * 删除指标子KPI
     * @author z004267r
     * @param tenant  tenant
     * @param lineId  lineId
     * @param kpiName  kpiName
     * @return void
     * @date 4/13/2020 1:38 PM
     */
    public void deleteChildrenKpi(String tenant,String lineId,String kpiName){
        String kpiKey=String.format(KEY_SIMICAS_LINE_KPI_CHILDREN,tenant,lineId,kpiName);
        if(redisTemplate.hasKey(kpiKey)){
            redisTemplate.delete(kpiKey);
        }
    }


    /**
     * 获取产线kpi-unit map
     * @author Z0040M9S
     * @param tenant :
     * @param lineId :
     * @return : java.util.Map<java.lang.String,java.lang.String>
     * @date   3/12/2020 11:36 AM
     */
    public Map<String,String> getKpiMap(String tenant,String lineId){

        String kpiMapKey=String.format(KEY_SIMICAS_LINE_KPI_MAP,tenant,lineId);
        Map<String,String> kpiItemMap= redisTemplate.opsForHash().entries(kpiMapKey);
        if(MapUtils.isNotEmpty(kpiItemMap)){
            return kpiItemMap;
        }
        CfgKpiEntity condition;
        condition = new CfgKpiEntity();
        condition.setLineId(lineId);
        condition.setStation(EntityEnum.LINE.getEntityType());
        condition.setStatus(DBConstant.DB_STATUS_VALID);
        kpiItemMap=Optional.ofNullable(cfgKpiRepository.findAll(Example.of(condition)))
                .orElseGet(Collections::emptyList).stream().collect(
                        Collectors.toMap(CfgKpiEntity::getName, cfgKpiEntity -> {return StringUtils.trimToEmpty(cfgKpiEntity.getUnit());
                        }, (v1, v2) -> v2));
        redisTemplate.opsForHash().putAll(kpiMapKey,kpiItemMap);
        redisTemplate.expire(kpiMapKey, 4L, TimeUnit.HOURS);
        return kpiItemMap;

    }



}