package com.siemens.csde.simicas.cache.component;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.gson.Gson;
import com.siemens.csde.simicas.common.model.WorkSpaceModel;
import com.siemens.csde.simicas.common.model.WorkSpaceModel.NodeData;
import com.siemens.csde.simicas.jpa.constant.DBConstant;
import com.siemens.csde.simicas.jpa.entity.CfgLineEntity;
import com.siemens.csde.simicas.jpa.repository.CfgLineRepository;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Component;
/**
 * station 信息缓存中间组件
 * @author Z0040M9S
 * @version 1.0-SNAPSHOT
 * @date 2/12/2020 4:28 PM
 **/
@Component
@Slf4j
public class StationMediator{

    private static final String KEY_SIMICAS_STATION_MAP="simicas:%s:line:%s:stationMap";


    @Autowired
    private RedisTemplate redisTemplate;

    @Autowired
    private CfgLineRepository cfgLineRepository;

    @Autowired
    private Gson gson;



    public void deleteStations(String tenant,String lineId){

        String stationMapKey=String.format(KEY_SIMICAS_STATION_MAP,tenant,lineId);
        if(redisTemplate.hasKey(stationMapKey)){
            redisTemplate.delete(stationMapKey);
        }

    }


    /**
     * station id - name map
     * @author Z0040M9S
     * @param tenant :
     * @param lineId :
     * @return : java.util.Map<java.lang.String,java.lang.String>
     * @date   4/13/2020 10:38 AM
     */
    public Map<String,String> getStationMap(String tenant,String lineId){

        String stationMapKey=String.format(KEY_SIMICAS_STATION_MAP,tenant,lineId);
        Map<String,String> stationItemMap= redisTemplate.opsForHash().entries(stationMapKey);
        if(MapUtils.isNotEmpty(stationItemMap)){
            return stationItemMap;
        }
        CfgLineEntity condition;
        condition = new CfgLineEntity();
        condition.setId(lineId);
        condition.setStatus(DBConstant.DB_STATUS_VALID);
        Optional<CfgLineEntity> cfgLineEntityOptional=cfgLineRepository.findOne(Example.of(condition));
        if(!cfgLineEntityOptional.isPresent()){
            return Maps.newHashMap();
        }
        stationItemMap= Lists.newArrayList(cfgLineEntityOptional.get()).stream()
                .filter(cfgLineEntity -> {
                    return StringUtils.isNotEmpty(cfgLineEntity.getWorkstationModel());
                })
                .flatMap(cfgLineEntity -> {
            String json=cfgLineEntity.getWorkstationModel();
            return gson.fromJson(json, WorkSpaceModel.class).getNodeDataArray().stream();
        }) .filter(nodeData -> (null == nodeData.getIsGroup() ? false : nodeData.getIsGroup()) && StringUtils
                .equalsIgnoreCase("OfGroups", nodeData.getCategory()))
                .collect(Collectors.toMap(NodeData::getKey, nodeData -> {return StringUtils.isNotEmpty(nodeData.getDisText()) ? nodeData.getDisText() : nodeData.getText();
                }, (v1, v2) -> v2));
        redisTemplate.opsForHash().putAll(stationMapKey,stationItemMap);
        redisTemplate.expire(stationMapKey, 4L, TimeUnit.HOURS);
        return stationItemMap;

    }

}