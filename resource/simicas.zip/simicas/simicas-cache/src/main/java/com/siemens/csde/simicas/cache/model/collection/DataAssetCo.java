package com.siemens.csde.simicas.cache.model.collection;

import java.time.Instant;
import lombok.Getter;
import lombok.Setter;

/**
 * DataAssetCo
 *
 * @author z004267r
 * @version 1.0-SNAPSHOT
 * @date 3/27/2020 11:33 AM
 **/
@Setter
@Getter
public class DataAssetCo {

    private String id;

    private String aspectName;

    private String assetId;

    private Integer part;

    private String tenantId;

    private Instant lastProcessTime;

    private Integer status;

    private String collectionType;

    private String collectionMethod;

    private String url;

    private String userName;

    private String password;

    private String lineId;

    private String lineName;

    private Integer createIndex;

}
