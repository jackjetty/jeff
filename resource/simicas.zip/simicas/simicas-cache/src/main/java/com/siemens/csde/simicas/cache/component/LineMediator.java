package com.siemens.csde.simicas.cache.component;

import com.siemens.csde.simicas.cache.model.LineCo;
import com.siemens.csde.simicas.jpa.constant.DBConstant;
import com.siemens.csde.simicas.jpa.entity.CfgLineEntity;
import com.siemens.csde.simicas.jpa.repository.CfgLineRepository;
import java.util.Collections;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.MapUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Component;
/**
 * line 信息缓存中间组件
 * @author Z0040M9S
 * @version 1.0-SNAPSHOT
 * @date 2/12/2020 4:28 PM
 **/
@Component
@Slf4j
public class LineMediator{

    private static final String KEY_SIMICAS_LINE="simicas:line:%s";

    private static final String KEY_SIMICAS_LINE_MAP="simicas:%s:lineMap";

    @Autowired
    private RedisTemplate redisTemplate;

    @Autowired
    private CfgLineRepository cfgLineRepository;

    /**
     * 获取产线信息
     * @author Z0040M9S
     * @param lineId :
     * @return : com.siemens.csde.simicas.cache.model.LineCo
     * @date   3/12/2020 11:37 AM
     */
    public LineCo getLine(String lineId){

        String lineKey=String.format(KEY_SIMICAS_LINE,lineId);
        LineCo lineCo = (LineCo) redisTemplate.opsForValue().get(lineKey);
        if(Objects.nonNull(lineCo)){
            return lineCo;
        }
        CfgLineEntity condition;
        condition = new CfgLineEntity();
        condition.setId(lineId);
        condition.setStatus(DBConstant.DB_STATUS_VALID);
        CfgLineEntity cfgLineEntity = cfgLineRepository.findOne(Example.of(condition)).orElse(null);
        if(Objects.isNull(cfgLineEntity)){
            return null;
        }
        lineCo=new LineCo();
        lineCo.setId(cfgLineEntity.getId());
        lineCo.setName(cfgLineEntity.getName());
        lineCo.setAssetId(cfgLineEntity.getAssetId());
        lineCo.setWorkstationModel(cfgLineEntity.getWorkstationModel());
        lineCo.setTenant(cfgLineEntity.getTenant());
        lineCo.setIndex(cfgLineEntity.getIndex());
        redisTemplate.opsForValue().set(lineKey, lineCo, 4L, TimeUnit.HOURS);
        return lineCo;

    }

    /**
     * 删除产线信息
     * @author Z0040M9S
     * @param tenant :
     * @param lineId :
     * @return : void
     * @date   3/12/2020 11:37 AM
     */
    public void deleteLine(String tenant,String lineId){

        String lineKey=String.format(KEY_SIMICAS_LINE,lineId);
        if(redisTemplate.hasKey(lineKey)){
            redisTemplate.delete(lineKey);
        }
        String lineMapKey=String.format(KEY_SIMICAS_LINE_MAP,tenant);
        if(redisTemplate.hasKey(lineMapKey)){
            redisTemplate.delete(lineMapKey);
        }

    }


    /**
     * 获取tenant 下 产线 id-name map
     * @author Z0040M9S
     * @param tenant :
     * @return : java.util.Map<java.lang.String,java.lang.String>
     * @date   3/12/2020 11:37 AM
     */
    public Map<String,String> getLineMap(String tenant){

        String lineMapKey=String.format(KEY_SIMICAS_LINE_MAP,tenant);
        Map<String,String> lineItemMap= redisTemplate.opsForHash().entries(lineMapKey);
        if(MapUtils.isNotEmpty(lineItemMap)){
            return lineItemMap;
        }
        CfgLineEntity condition;
        condition = new CfgLineEntity();
        condition.setTenant(tenant);
        condition.setStatus(DBConstant.DB_STATUS_VALID);
        lineItemMap= Optional.ofNullable(cfgLineRepository.findAll(Example.of(condition)))
                .orElseGet(Collections::emptyList).stream().collect(
                        Collectors.toMap(CfgLineEntity::getId, CfgLineEntity::getName, (v1, v2) -> v2));
        redisTemplate.opsForHash().putAll(lineMapKey,lineItemMap);
        redisTemplate.expire(lineMapKey, 4L, TimeUnit.HOURS);
        return lineItemMap;

    }



}