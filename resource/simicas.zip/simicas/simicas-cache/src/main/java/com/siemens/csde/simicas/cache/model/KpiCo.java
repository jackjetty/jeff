package com.siemens.csde.simicas.cache.model;

import java.io.Serializable;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
/**
 *  kpi 缓存对象
 * @author Z0040M9S
 * @version 1.0-SNAPSHOT
 * @date 2/12/2020 4:28 PM
 **/
@Setter
@Getter
public class KpiCo implements Serializable {

    private static final long serialVersionUID = -4227269013788265686L;
    private String id;
    private String name;
    private String pId;
    private Integer type;
    private Integer level;
    private String formula;
    private String unit;
    private String lineId;
    private String station;
    private String description;
    private List<KpiVariableCo> kpiVariableCos;
    private List<InputVariableCo> inputVariableCos;

    @Setter
    @Getter
    public static class InputVariableCo implements Serializable {

        private static final long serialVersionUID = -2795379914231528908L;
        private String name;
        private String dataKey;
        private String dataType;
    }


    @Setter
    @Getter
    public static class KpiVariableCo implements Serializable {

        private static final long serialVersionUID = -9169964609180670391L;
        private String id;
        private String name;
        private String dataType;
        private String defaultValue;
        private Integer length;
        private String unit;
        private String formula;

    }
}