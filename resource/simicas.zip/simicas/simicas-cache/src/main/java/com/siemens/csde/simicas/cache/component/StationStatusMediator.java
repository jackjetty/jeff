package com.siemens.csde.simicas.cache.component;

import com.siemens.csde.simicas.cache.model.StatusCo;
import com.siemens.csde.simicas.jpa.constant.DBConstant;
import com.siemens.csde.simicas.jpa.entity.CfgWorkstationStatusEntity;
import com.siemens.csde.simicas.jpa.repository.CfgWorkstationStatusRepository;
import java.util.Collections;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.MapUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Component;

/**
 * station status 信息缓存中间组件
 * @author Z0040M9S
 * @version 1.0-SNAPSHOT
 * @date 2/12/2020 4:28 PM
 **/
@Slf4j
@Component
public class StationStatusMediator{

    private static final String KEY_SIMICAS_LINE_STATION_STATUS="simicas:%s:line:%s:station:%s:status:%s";

    private static final String KEY_SIMICAS_LINE_STATION_STATUS_MAP="simicas:%s:line:%s:station:%s:statusMap";

    @Autowired
    private RedisTemplate redisTemplate;

    @Autowired
    private CfgWorkstationStatusRepository cfgWorkstationStatusRepository;


    /**
     * 获取产线statuses
     * @author Z0040M9S
     * @param tenant :
     * @param lineId :
     * @param status :
     * @return : com.siemens.csde.simicas.cache.model.StatusCo
     * @date   3/12/2020 11:36 AM
     */
    public StatusCo getStatus(String tenant,String lineId,String stationId,String status){

        String statusKey=String.format(KEY_SIMICAS_LINE_STATION_STATUS,tenant,lineId,stationId,status);
        StatusCo statusCo = (StatusCo) redisTemplate.opsForValue().get(statusKey);
        if(Objects.nonNull(statusCo)){
            return statusCo;
        }

        CfgWorkstationStatusEntity condition;
        condition = new CfgWorkstationStatusEntity();
        condition.setLineId(lineId);
        condition.setStatus(DBConstant.DB_STATUS_VALID);
        condition.setStationId(stationId);
        condition.setStationStatus(status);
        CfgWorkstationStatusEntity cfgWorkstationStatusEntity=  Optional.ofNullable(cfgWorkstationStatusRepository.findAll(Example.of(condition)))
                .orElseGet(Collections::emptyList).stream().findFirst().orElse(null);
        if(Objects.isNull(cfgWorkstationStatusEntity)){
            return null;
        }
        statusCo=new StatusCo();
        statusCo.setId(cfgWorkstationStatusEntity.getId());
        statusCo.setDowntimeCategory(Optional.ofNullable(cfgWorkstationStatusEntity.getDowntimeCategory()).orElse(false));
        statusCo.setLabel(cfgWorkstationStatusEntity.getLabel());
        statusCo.setVisual(cfgWorkstationStatusEntity.getVisual());
        statusCo.setStatus(cfgWorkstationStatusEntity.getStationStatus());
        redisTemplate.opsForValue().set(statusKey, statusCo, 4L, TimeUnit.HOURS);
        return statusCo;

    }
    /**
     * 删除产线status
     * @author Z0040M9S
     * @param tenant :
     * @param lineId :
     * @param status :
     * @return : void
     * @date   3/12/2020 11:36 AM
     */
    public void deleteStatus(String tenant,String lineId,String stationId,String status){

        String statusKey=String.format(KEY_SIMICAS_LINE_STATION_STATUS,tenant,lineId,stationId,status);
        if(redisTemplate.hasKey(statusKey)){
            redisTemplate.delete(statusKey);
        }
        String statusMapKey=String.format(KEY_SIMICAS_LINE_STATION_STATUS_MAP,tenant,lineId,stationId);
        if(redisTemplate.hasKey(statusMapKey)){
            redisTemplate.delete(statusMapKey);
        }

    }

    /**
     * 获取产线status-downtimecategory map
     * @author Z0040M9S
     * @param tenant :
     * @param lineId :
     * @return : java.util.Map<java.lang.String,java.lang.Boolean>
     * @date   3/12/2020 11:36 AM
     */
    public Map<String,Boolean> getStatusMap(String tenant,String lineId,String stationId){

        String statusMapKey=String.format(KEY_SIMICAS_LINE_STATION_STATUS_MAP,tenant,lineId,stationId);
        Map<String,Boolean> statusItemMap= redisTemplate.opsForHash().entries(statusMapKey);
        if(MapUtils.isNotEmpty(statusItemMap)){
            return statusItemMap;
        }
        CfgWorkstationStatusEntity condition;
        condition = new CfgWorkstationStatusEntity();
        condition.setLineId(lineId);
        condition.setStatus(DBConstant.DB_STATUS_VALID);
        condition.setStationId(stationId);
        statusItemMap=Optional.ofNullable(cfgWorkstationStatusRepository.findAll(Example.of(condition)))
                .orElseGet(Collections::emptyList).stream().collect(
                        Collectors.toMap(CfgWorkstationStatusEntity::getStationStatus, cfgWorkstationStatusEntity -> {return Optional.ofNullable(cfgWorkstationStatusEntity.getDowntimeCategory()).orElse(false);
                        }, (v1, v2) -> v2));
        redisTemplate.opsForHash().putAll(statusMapKey,statusItemMap);
        redisTemplate.expire(statusMapKey, 4L, TimeUnit.HOURS);
        return statusItemMap;

    }


}