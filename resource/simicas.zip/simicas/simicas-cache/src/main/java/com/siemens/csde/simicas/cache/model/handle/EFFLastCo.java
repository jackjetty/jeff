package com.siemens.csde.simicas.cache.model.handle;

import java.util.Date;
import lombok.Getter;
import lombok.Setter;

/**
 * OutPutViewCo
 *
 * @author z004267r
 * @version 1.0-SNAPSHOT
 * @date 3/25/2020 11:09 AM
 **/
@Setter
@Getter
public class EFFLastCo {

    private String id;

    private String lineId;

    private String stationId;

    private Double dataValue;

    private Double ict;

    private Double act;

    private String dataUnit;

    private Integer errorCode;

    private Date dataTime;

    private String productId;

    private String orderId;

    private String batchId;

}
