package com.siemens.csde.simicas.cache.component.handle;

import com.siemens.csde.simicas.cache.model.handle.NGReasonLastCo;
import com.siemens.csde.simicas.common.util.RedisUtil;
import com.siemens.csde.simicas.jpa.component.NativeQueryManager;
import com.siemens.csde.simicas.jpa.entity.DataHandleNGReasonEntity;
import com.siemens.csde.simicas.jpa.repository.DataHandleNGReasonRepository;
import java.util.Objects;
import java.util.Optional;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * NGReasonMediator ngreason缓存
 * @author z004267r
 * @version 1.0-SNAPSHOT
 * @date 3/25/2020 11:01 AM
 **/
@Slf4j
@Component
public class NGReasonMediator {

    private static final String KEY_SIMICAS_LINE_KPI_LAST="simicas:%s:line:%s:station:%s:kpi:%s:last";

    @Autowired
    private RedisUtil redisUtil;

    @Autowired
    private DataHandleNGReasonRepository ngReasonRepository;

    @Autowired
    private NativeQueryManager nativeQueryManager;

    /**
     * 查询缓存
     * @author z004267r
     * @param tenant  tenant
     * @param lineId  lineId
     * @param station  station
     * @param kpiName  kpiName
     * @return com.siemens.csde.simicas.cache.model.handle.OutPutLastCo
     * @date 3/25/2020 1:33 PM
     */
    public NGReasonLastCo getLastData(String tenant,String lineId,String station,String kpiName){
        String kpiKey=String.format(KEY_SIMICAS_LINE_KPI_LAST,tenant,lineId,station,kpiName);
        NGReasonLastCo ngReasonLastCo = (NGReasonLastCo) redisUtil.get(kpiKey);
        if(Objects.nonNull(ngReasonLastCo)){
            return ngReasonLastCo;
        }
        Optional<DataHandleNGReasonEntity> ngReasonEntityOptional = ngReasonRepository.findLastEntity(lineId,station);
        if(!ngReasonEntityOptional.isPresent()){
            return null;
        }
        BeanUtils.copyProperties(ngReasonEntityOptional.get(), ngReasonLastCo);
        redisUtil.set(kpiKey, ngReasonLastCo, 4L);
        return ngReasonLastCo;
    }

    /**
     * 删除缓存
     * @author z004267r
     * @param tenant  tenant
     * @param lineId  lineId
     * @param station  station
     * @param kpiName  kpiName
     * @return void
     * @date 3/25/2020 2:14 PM
     */
    public void deleteLastData(String tenant,String lineId,String station,String kpiName){

        String kpiKey=String.format(KEY_SIMICAS_LINE_KPI_LAST,tenant,lineId,kpiName);
        if(redisUtil.hasKey(kpiKey)){
            redisUtil.del(kpiKey);
        }
    }

   /**
    * 更新缓存
    * @author z004267r
    * @param tenant  tenant
    * @param lineId  lineId
    * @param station  station
    * @param kpiName  kpiName
    * @return void
    * @date 3/25/2020 2:14 PM
    */
    public void updateLastData(String tenant,String lineId,String station,String kpiName,NGReasonLastCo outPutLastCo){
        String kpiKey=String.format(KEY_SIMICAS_LINE_KPI_LAST,tenant,lineId,station,kpiName);
        redisUtil.set(kpiKey, outPutLastCo, 4L);
    }



}