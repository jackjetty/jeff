package com.siemens.csde.simicas.cache.component.collection;

import com.google.common.collect.Lists;
import com.siemens.csde.simicas.cache.model.collection.DataAssetCo;
import com.siemens.csde.simicas.common.util.RedisUtil;
import com.siemens.csde.simicas.jpa.component.NativeQueryManager;
import com.siemens.csde.simicas.jpa.entity.CfgDataAssetEntity;
import com.siemens.csde.simicas.jpa.repository.CfgDataAssetRepository;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * DataAssetMediator dataAsset缓存信息
 *
 * @author z004267r
 * @version 1.0-SNAPSHOT
 * @date 3/27/2020 11:26 AM
 **/
@Component
public class DataAssetMediator {

    private static final String KEY_SIMICAS_ASSET = "simicas:%s:dataAsset:%s";

    @Autowired
    private RedisUtil redisUtil;

    @Autowired
    private NativeQueryManager nativeQueryManager;

    @Autowired
    private CfgDataAssetRepository cfgDataAssetRepository;

    /**
     * 初始化缓存信息
     *
     * @param
     * @return void
     * @author z004267r
     * @date 3/29/2020 4:34 PM
     */
    public void initDataAssetCache() {
        List<CfgDataAssetEntity> dataAssetEntities = nativeQueryManager
                .queryByConditionNQ(CfgDataAssetEntity.class, CfgDataAssetRepository.SQL_DATAASSETS, null);

        Optional.ofNullable(dataAssetEntities)
                .orElseGet(Collections::emptyList)
                .forEach(cfgDataAssetEntity -> {
                    String assetKey = String.format(KEY_SIMICAS_ASSET, cfgDataAssetEntity.getTenantId(), cfgDataAssetEntity.getTenantId());
                    DataAssetCo dataAssetCo = new DataAssetCo();
                    dataAssetCo.setTenantId(cfgDataAssetEntity.getTenantId());
                    dataAssetCo.setAssetId(cfgDataAssetEntity.getAssetId());
                    dataAssetCo.setId(cfgDataAssetEntity.getId());
                    dataAssetCo.setAspectName(cfgDataAssetEntity.getAspectName());
                    dataAssetCo.setCollectionMethod(cfgDataAssetEntity.getCollectionMethod());
                    dataAssetCo.setCollectionType(cfgDataAssetEntity.getCollectionType());
                    dataAssetCo.setLastProcessTime(cfgDataAssetEntity.getLastProcessTime());
                    dataAssetCo.setLineId(cfgDataAssetEntity.getLineId());
                    dataAssetCo.setLineName(cfgDataAssetEntity.getLineName());
                    dataAssetCo.setCreateIndex(cfgDataAssetEntity.getCreateIndex());
                    dataAssetCo.setUserName(cfgDataAssetEntity.getUserName());
                    dataAssetCo.setPassword(cfgDataAssetEntity.getPassword());
                    dataAssetCo.setUrl(cfgDataAssetEntity.getUrl());
                    redisUtil.hset(assetKey, dataAssetCo.getAspectName(), dataAssetCo, 4L);
                });
    }

    /**
     * 根据tenant和asset获取缓存信息
     *
     * @param tenant  tenant
     * @param assetId assetId
     * @return com.siemens.csde.simicas.cache.model.ProductCo
     * @author z004267r
     * @date 3/27/2020 11:30 AM
     */
    public List<DataAssetCo> getDataAsset(String tenant, String assetId) {
        String assetKey = String.format(KEY_SIMICAS_ASSET, tenant, assetId);
        List<DataAssetCo> dataAssetCos = Lists.newArrayList();
        Map<Object, Object> map = redisUtil.hmget(assetKey);
        for (Map.Entry<Object, Object> entry : map.entrySet()) {
            dataAssetCos.add((DataAssetCo) entry.getValue());
        }
        if (dataAssetCos.size() > 0) {
            return dataAssetCos;
        }

        List<CfgDataAssetEntity> dataAssetEntities = nativeQueryManager
                .queryByConditionNQ(CfgDataAssetEntity.class, CfgDataAssetRepository.SQL_DATAASSETS, null);

        dataAssetCos = Optional.ofNullable(dataAssetEntities)
                .orElseGet(Collections::emptyList).stream()
                .filter(cfgDataAssetEntity ->
                        StringUtils.equals(tenant, cfgDataAssetEntity.getTenantId())
                                && StringUtils.equals(assetId, cfgDataAssetEntity.getAssetId()))
                .map(cfgDataAssetEntity -> {
                    DataAssetCo dataAssetCo = new DataAssetCo();
                    dataAssetCo.setTenantId(cfgDataAssetEntity.getTenantId());
                    dataAssetCo.setAssetId(cfgDataAssetEntity.getAssetId());
                    dataAssetCo.setId(cfgDataAssetEntity.getId());
                    dataAssetCo.setAspectName(cfgDataAssetEntity.getAspectName());
                    dataAssetCo.setCollectionMethod(cfgDataAssetEntity.getCollectionMethod());
                    dataAssetCo.setCollectionType(cfgDataAssetEntity.getCollectionType());
                    dataAssetCo.setLastProcessTime(cfgDataAssetEntity.getLastProcessTime());
                    dataAssetCo.setLineId(cfgDataAssetEntity.getLineId());
                    dataAssetCo.setLineName(cfgDataAssetEntity.getLineName());
                    dataAssetCo.setCreateIndex(cfgDataAssetEntity.getCreateIndex());
                    dataAssetCo.setUserName(cfgDataAssetEntity.getUserName());
                    dataAssetCo.setPassword(cfgDataAssetEntity.getPassword());
                    dataAssetCo.setUrl(cfgDataAssetEntity.getUrl());
                    redisUtil.hset(assetKey, dataAssetCo.getAspectName(), dataAssetCo, 4L);
                    return dataAssetCo;
                }).collect(Collectors.toList());

        return dataAssetCos;

    }

    /**
     * 删除缓存
     *
     * @param tenant  tenant
     * @param assetId assetId
     * @return void
     * @author z004267r
     * @date 3/27/2020 12:10 PM
     */
    public void deleteDataAsset(String tenant, String assetId) {
        String productKey = String.format(KEY_SIMICAS_ASSET, tenant, assetId);
        if (redisUtil.hasKey(productKey)) {
            redisUtil.del(productKey);
        }
    }

    /**
     * 更新缓存
     *
     * @param cfgDataAssetEntity cfgDataAssetEntity
     * @return void
     * @author z004267r
     * @date 3/28/2020 10:42 PM
     */
    public void updateDataAsset(CfgDataAssetEntity cfgDataAssetEntity) {
        String assetKey = String.format(KEY_SIMICAS_ASSET, cfgDataAssetEntity.getTenantId(), cfgDataAssetEntity.getAssetId());
        DataAssetCo dataAssetCo = new DataAssetCo();
        BeanUtils.copyProperties(cfgDataAssetEntity, dataAssetCo);
        redisUtil.hset(assetKey, cfgDataAssetEntity.getAspectName(), dataAssetCo);
    }


}
