
import os

import requests
from robobrowser import RoboBrowser


class deploy:

    def get_passcode(self):
        url = "https://login.cf.cn1.mindsphere-in.cn/passcode"
        session = requests.Session()
        user_agent = 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2171.71 Safari/537.36'
        browser = RoboBrowser(session=session, parser='html.parser', history=False, timeout=120, user_agent=user_agent,allow_redirects = True)
        browser.open(url=url)
        redirect_form=browser.get_form()
        browser.submit_form(form=redirect_form)

        mdsp_user_name='ke.zong.ext@siemens.com'
        mdsp_password = 'qazwsx@EDCRFV1029'

        login_form=browser.get_form(id='Login')
        login_form['emailAddress'] = mdsp_user_name
        login_form['passLogin'] = mdsp_password
        browser.submit_form(login_form)

        saml_form=browser.get_form()
        browser.submit_form(saml_form)
        pass_code=browser.select('div[class="island"] > h2')[0].text
        print(pass_code)
        return pass_code




if __name__ == "__main__":
    deploy().get_passcode()
