package com.csde.demo.receiver.test;

import lombok.extern.slf4j.Slf4j;
import org.zeromq.SocketType;
import org.zeromq.ZMQ;
import org.zeromq.ZMQ.Context;
import org.zeromq.ZMQ.Socket;

/**
 * @author huangjianfeng
 * @version 1.0
 * @ClassName Client
 * @Desciption []
 * @date 2020/5/18
 */
@Slf4j
public class Client {

    public static  final String CLIENT_PUBLICKEY="Lr(kur>e]YJX[w7I3X2U-lRWnwSIRYgaDbZ}J:F<";
    public static  final String CLIENT_SECRECTKEY="BS]*ylPi>0=IQbdtB2XGHt1={WDW8yADB=Gm::SD";

    public static void main(String[] args) throws Exception{


        Context ctx= ZMQ.context(1);
        Socket socket = ctx.socket(SocketType.DEALER);
        /*socket.setCurvePublicKey(client_cert.getPublicKey());
        socket.setCurveSecretKey(client_cert.getSecretKey());
        socket.setCurveServerKey(server_cert.getPublicKey());*/
        socket.setCurvePublicKey(CLIENT_PUBLICKEY.getBytes());
        socket.setCurveSecretKey(CLIENT_SECRECTKEY.getBytes());
        socket.setCurveServerKey(Server.SEVER_PUBLICKEY.getBytes());
        socket.connect("tcp://127.0.0.1:5555");
        socket.sendMore("head");
        byte[] data = "body".getBytes();
        socket.send(data);
        //rc = push.send(data, 0, data.length - 1, 0);
        log.info("获取消息{}",socket.recv());


        socket.close();
        ctx.term();
    }

}
