package com.csde.demo.receiver.test;

import java.net.URISyntaxException;
import java.sql.Time;
import java.util.concurrent.TimeUnit;
import lombok.extern.slf4j.Slf4j;
import org.fusesource.mqtt.client.BlockingConnection;
import org.fusesource.mqtt.client.MQTT;
import org.fusesource.mqtt.client.Message;
import org.fusesource.mqtt.client.QoS;
import org.fusesource.mqtt.client.Topic;
@Slf4j
public class MQTTTest{

    public static void main(String[] args) throws Exception{

        MQTTConnection mqttConnection=new MQTTConnection();
        mqttConnection.connect();
        while(true){

            if(!mqttConnection.isConnected()){
                log.info("进行重连" );
                mqttConnection.connect();
            }else{
                log.info("connect status:{}",mqttConnection.isConnected());
            }
            TimeUnit.SECONDS.sleep(10L);
        }

    }

}