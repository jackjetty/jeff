package com.csde.demo.receiver.test;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintStream;
import java.net.SocketException;

import org.apache.commons.net.telnet.TelnetClient;


public class TelnetThread extends Thread{

    private TelnetClient telnet = new TelnetClient();
    private InputStream in;
    private PrintStream out;
    private String ip;
    private int port;
    private char prompt = '$';
    private String user="pi";
    private String password="raspberry";
    public TelnetThread(String ip,int port){
        this.ip=ip;
        this.port=port;
    }
    public void run() {
        try {
            telnet.connect(ip, port);
            in = telnet.getInputStream();
            out = new PrintStream(telnet.getOutputStream());
            System.out.println("success12 " +ip+" port "+port);
            // 根据root用户设置结束符
            //this.prompt = user.equals("root") ? '#' : '$';
            //login(user, password);
            //System.out.println("success " +ip);
        }catch(Exception ex){
            //System.out.println("fail "+ip);
        }
    }


    public void login(String user, String password) {
        String result="";
        readUntil("login:");
        write(user);
        readUntil("Password:");
        write(password);
        result=readUntil(prompt + " ");
        System.out.println("登录结果"+result);
    }


    /** * 读取分析结果 * * @param pattern * @return */
    public String readUntil(String pattern) {
        try {
            char lastChar = pattern.charAt(pattern.length() - 1);
            StringBuffer sb = new StringBuffer();
            char ch = (char) in.read();
            while (true) {
                sb.append(ch);
                if (ch == lastChar) {
                    if (sb.toString().endsWith(pattern)) {
                        return sb.toString();
                    }
                }
                ch = (char) in.read();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    /** * 写操作 * * @param value */
    public void write(String value) {
        try {
            out.println(value);
            out.flush();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}