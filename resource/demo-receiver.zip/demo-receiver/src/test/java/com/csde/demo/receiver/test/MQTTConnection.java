package com.csde.demo.receiver.test;

import java.net.SocketException;
import java.net.URISyntaxException;
import java.time.Instant;
import lombok.extern.slf4j.Slf4j;
import org.fusesource.mqtt.client.BlockingConnection;
import org.fusesource.mqtt.client.MQTT;
import org.fusesource.mqtt.client.Message;
import org.fusesource.mqtt.client.QoS;
import org.fusesource.mqtt.client.Topic;

@Slf4j
public class MQTTConnection {

    private BlockingConnection connection;

    private String host="tcp://47.96.237.133:61613";
    private String userName="admin";
    private String password="password";
    private String topic="t_config/000000078";
    private MQTT mqtt = new MQTT();
    private Boolean init;
    public MQTTConnection(){
        init=false;
        try {
            // MQTT服务端地址
            mqtt.setHost(host);
        } catch (URISyntaxException e) {
            throw new RuntimeException(e.getMessage());
        }
        // 用户名
        mqtt.setUserName(userName);
        // 密码
        mqtt.setPassword(password);
        // MQTT服务器将持久化客户端会话的主体订阅和ACK位置
        mqtt.setCleanSession(true);
        //在客户端首次尝试连接到服务器时，在将错误报告给客户端之前，尝试重新连接的最大次数。设置为-1以使用无限尝试。默认为-1
        mqtt.setConnectAttemptsMax(2);
        // 客户端已经连接到服务器，但因某种原因连接断开时的最大重试次数，超出该次数客户端将返回错误。-1意为无重试上限
        mqtt.setReconnectAttemptsMax(-1);
        //-1
        // 首次重连接间隔毫秒数
        mqtt.setReconnectDelay(30000);
        // 重连接间隔毫秒数
        mqtt.setReconnectDelayMax(30000);
        // 定义客户端传来消息的最大时间间隔秒数，服务器可以据此判断与客户端的连接是否已经断开，从而避免TCP/IP超时的长时间等待
        mqtt.setKeepAlive((short) 30);
        // 设置socket发送缓冲区大小
        mqtt.setSendBufferSize(2 * 1024 * 1024);
        mqtt.setWillTopic("t_will/000000078");
        mqtt.setWillQos(QoS.AT_LEAST_ONCE);
        mqtt.setWillRetain(true);
        //connection = mqtt.futureConnection();
        //connection.connect();
        connection = mqtt.blockingConnection();
    }

    public void connect(){
        if(init)
            return;
        try {
            connection.connect();
            init=true;
        } catch ( Exception e) {
            System.out.println(Instant.now().toString());
            e.printStackTrace();
            //断开 再连
            if(e instanceof  IllegalStateException){
                log.info("自动 重连");
               /* try {
                    connection.disconnect();
                    connection.kill();
                    log.info("重连....");
                    connection = mqtt.blockingConnection();

                } catch (Exception exception) {
                    exception.printStackTrace();
                }*/
            }

        }
    }
    //java.lang.IllegalStateException: Already connected
    //java.net.SocketException: Network is unreachable: no further information


    public boolean isConnected(){
        return connection.isConnected();
    }

    public BlockingConnection getConnection(){
        return connection;
    }




}