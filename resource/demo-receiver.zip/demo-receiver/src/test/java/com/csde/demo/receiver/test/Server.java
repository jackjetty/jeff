package com.csde.demo.receiver.test;

import lombok.extern.slf4j.Slf4j;
import org.zeromq.SocketType;
import org.zeromq.ZMQ;
import org.zeromq.ZMQ.Context;
import org.zeromq.ZMQ.Socket;

/**
 * @author huangjianfeng
 * @version 1.0
 * @ClassName Server
 * @Desciption []
 * @date 2020/5/18
 */
@Slf4j
public class Server {

    public static  final String SEVER_PUBLICKEY="IIC!ZBG.8i7Zm0->g^w>C$LJ+3-}Mu]BIbykfy-m";
    public static  final String SEVER_SECRTECKEY="jQ5EgQ<4%lF-V1uB7.1ld*X0x0&K<?fmkkXAm+N9";
    public static void main(String[] args) throws Exception{



        Context ctx= ZMQ.context(1);
        Socket socket = ctx.socket(SocketType.DEALER);
        socket.setCurveServer(true);
        /*socket.setCurvePublicKey(server_cert.getPublicKey());
        socket.setCurveSecretKey(server_cert.getSecretKey());*/
        socket.setCurvePublicKey(SEVER_PUBLICKEY.getBytes());
        socket.setCurveSecretKey(SEVER_SECRTECKEY.getBytes());
        int port=5555;
        socket.bind("tcp://*:" + port);

        ;
        log.info("服务端开启:{}",socket.getLastEndpoint());
        Socket client;
        while (true) {
            //接收到消息
            //,"UTF-8"
            String head = new String(socket.recv(0));
            //String body = new String(socket.recv(0));
            String body=new String(socket.recv(0));
            log.info("server head:{},body:{}",head,body);
            socket.send("服务端发送"+head,0);
            if (head.equals("send end......")) {
                break;
            }
            //对消息进行send

        }
        socket.close();

        ctx.term();
    }
}
