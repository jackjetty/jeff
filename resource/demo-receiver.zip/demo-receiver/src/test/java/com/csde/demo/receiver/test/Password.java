package com.csde.demo.receiver.test;
//import org.jasig.cas.authentication.handler.DefaultPasswordEncoder;
/**
 * @author huangjianfeng
 * @version 1.0
 * @ClassName Password
 * @Desciption []
 * @date 2020/5/19
 */
public class Password {

    public static void main(String[] args) throws Exception{
        for(int i=0;i<1000;i++){
            System.out.println(i);
        }
        //DefaultPasswordEncoder defaultPasswordEncoder=new DefaultPasswordEncoder("MD5");
        //System.out.println(defaultPasswordEncoder.encode("123456"));
    }
}
