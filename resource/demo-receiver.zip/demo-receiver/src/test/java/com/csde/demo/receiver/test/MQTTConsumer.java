package com.csde.demo.receiver.test;

import java.net.URISyntaxException;
import java.util.concurrent.TimeUnit;
import lombok.extern.slf4j.Slf4j;
import org.fusesource.mqtt.client.BlockingConnection;
import org.fusesource.mqtt.client.MQTT;
import org.fusesource.mqtt.client.Message;
import org.fusesource.mqtt.client.QoS;
import org.fusesource.mqtt.client.Topic;

@Slf4j
public class MQTTConsumer {



   /* public void publish() throws Exception{
        for (int i=0;i<10;i++){
            connection.publish("foo", "Hello".getBytes(), QoS.AT_LEAST_ONCE, false);
        }
    }*/

    /*public void subscribe() throws Exception {
        Topic[] topics = {new Topic("foo", QoS.AT_LEAST_ONCE)};
        byte[] qoses = connection.subscribe(topics);

        Message message = connection.receive();
        System.out.println(message.getTopic());
        byte[] payload = message.getPayload();
        log.info("message:{}",new String(payload));
        message.ack();
    }
*/

    public static void main(String[] args) throws Exception{

        MQTTConnection mqttConnection=new MQTTConnection();
        mqttConnection.connect();
        log.info("connect status:{}",mqttConnection.isConnected());
        BlockingConnection blockingConnection=mqttConnection.getConnection();
        Topic[] topics = {new Topic("foo", QoS.AT_LEAST_ONCE)};
        byte[] qoses = blockingConnection.subscribe(topics);
        while(true){
            Message message = blockingConnection.receive();
            System.out.println(message.getTopic());
            byte[] payload = message.getPayload();
            log.info("message:{}",new String(payload));
            message.ack();
            TimeUnit.SECONDS.sleep(10L);
        }

        // mqttNet.subscribe();
        //blockingConnection.unsubscribe(new String[]{"foo"});
       // blockingConnection.disconnect();
        /*
        while(true){
            log.info("当前连接状态:{}",mqttNet.isConnected());
            if(!mqttNet.isConnected()){
                mqttNet.connect();
                log.info("进行重新连接" );
            }
            TimeUnit.SECONDS.sleep(10L);
        }*/

    }

}