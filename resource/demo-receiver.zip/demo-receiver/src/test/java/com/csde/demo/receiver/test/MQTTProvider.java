package com.csde.demo.receiver.test;
import java.net.URISyntaxException;
import lombok.extern.slf4j.Slf4j;
import org.fusesource.mqtt.client.BlockingConnection;
import org.fusesource.mqtt.client.MQTT;
import org.fusesource.mqtt.client.Message;
import org.fusesource.mqtt.client.QoS;
import org.fusesource.mqtt.client.Topic;
@Slf4j
public class MQTTProvider {

    public static void main(String[] args) throws Exception{

        MQTTConnection mqttConnection=new MQTTConnection();
        mqttConnection.connect();
        log.info("connect status:{}",mqttConnection.isConnected());
        BlockingConnection blockingConnection=mqttConnection.getConnection();
        for (int i=0;i<10;i++){
            blockingConnection.publish("foo", ("Hello"+i).getBytes(), QoS.AT_LEAST_ONCE, false);
        }
        // mqttNet.subscribe();
        //blockingConnection.unsubscribe(new String[]{"foo"});
        blockingConnection.disconnect();
        /*
        while(true){
            log.info("当前连接状态:{}",mqttNet.isConnected());
            if(!mqttNet.isConnected()){
                mqttNet.connect();
                log.info("进行重新连接" );
            }
            TimeUnit.SECONDS.sleep(10L);
        }*/

    }

}