package com.csde.demo.receiver.base;

import java.io.Serializable;

public class BaseVo implements Serializable{

    private static final long serialVersionUID = -8142394123845411902L;

}