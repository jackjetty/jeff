package com.digitalpetri.modbus.codec;

import com.digitalpetri.modbus.FunctionCode;
import com.digitalpetri.modbus.ModbusPdu;
import com.digitalpetri.modbus.UnsupportedPdu;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.ByteBufUtil;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.ByteToMessageCodec;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

public class MyModbusTcpCodec extends ByteToMessageCodec<ModbusTcpPayload> {
    private static final int HeaderLength = 7;
    private static final int HeaderSize = 6;
    private static final int LengthFieldIndex = 4;
    private final Logger logger = LoggerFactory.getLogger(this.getClass());
    private final ModbusPduEncoder encoder;
    private final ModbusPduDecoder decoder;
    public MyModbusTcpCodec(ModbusPduEncoder encoder, ModbusPduDecoder decoder) {
        this.encoder = encoder;
        this.decoder = decoder;
    }
    @Override
    protected void encode(ChannelHandlerContext ctx, ModbusTcpPayload payload, ByteBuf buffer) throws Exception {
        // 写地址码
        buffer.writeByte(payload.getUnitId());
        // 写功能码\起始地址\数据长度
        encoder.encode(payload.getModbusPdu(), buffer);
        // 写CRC码
        byte[] body = new byte[buffer.readableBytes()];
        buffer.readBytes(body);
        byte[] crc16 = CRC16.intToBytes(CRC16.calcCrc16(body));
        buffer.writeBytes(body).writeBytes(crc16);
        // 打印生成的和串口服务器通讯的指令
        logger.info(ctx.toString());
        logger.info("unitid :{} sendMessage:{}" ,payload.getUnitId(), ByteBufUtil.hexDump(buffer));
    }
    @Override
    protected void decode(ChannelHandlerContext ctx, ByteBuf buffer, List<Object> out) throws Exception {
        // 打印串口服务器的响应
        String receiveMessage =ByteBufUtil.hexDump(buffer);
        logger.info("receiveMessage:{}", receiveMessage);
        int startIndex = buffer.readerIndex();
        byte[] b = new byte[buffer.readableBytes()];
        buffer.getBytes(0, b);
        if (FunctionCode.isExceptionCode(b[1] & 0xff)) {
            throw new  Exception(String.format("receiveMessage:%s 错误码：%s ",receiveMessage ,(b[2] & 0xff - 0x80)));
        }

        while (buffer.readableBytes() >= 3 && buffer.readableBytes() >= getLength(buffer, startIndex) + 5) {
            try {
                byte[] body = new byte[getLength(buffer, startIndex) + 3];
                buffer.getBytes(0, body);
                short unitIdAndtransactionId = buffer.readUnsignedByte();
//                MbapHeader mbapHeader = new MbapHeader(unitIdAndtransactionId, 0, getLength(buffer, startIndex) + 3, unitIdAndtransactionId);

                ModbusPdu modbusPdu = decoder.decode(buffer);
                // 读取CRC
                byte[] crc = new byte[2];
                buffer.readBytes(crc);
                // 计算CRC
                byte[] crcNew = CRC16.intToBytes(CRC16.calcCrc16(body));
                if (!ByteBufUtil.hexDump(crc).equals(ByteBufUtil.hexDump(crcNew))) {
                    throw new RuntimeException("unitid "+unitIdAndtransactionId+" crc error");
                }
                if (modbusPdu instanceof UnsupportedPdu) {
                    // Advance past any bytes we should have read but didn't...
                    int endIndex = startIndex + getLength(buffer, startIndex) + 5;
                    buffer.readerIndex(endIndex);
                }

                out.add(new ModbusTcpPayload(unitIdAndtransactionId, unitIdAndtransactionId, modbusPdu));
//                out.add(new ModbusTcpPayload(mbapHeader.getTransactionId(), mbapHeader.getUnitId(), modbusPdu));

            } catch (Throwable t) {
                throw new Exception("error decoding header/pdu/crc" +t.getMessage(), t);
            }
            startIndex = buffer.readerIndex();
        }

    }

    private int getLength(ByteBuf in, int startIndex) {
        return in.getUnsignedByte(startIndex + 2);
    }
}